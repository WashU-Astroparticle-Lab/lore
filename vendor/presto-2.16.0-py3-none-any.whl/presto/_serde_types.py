# Copyright (c) Facebook, Inc. and its affiliates
# SPDX-License-Identifier: MIT OR Apache-2.0

import numpy as np
from dataclasses import dataclass
import typing
from typing import Union


class SerializationError(ValueError):
    """Error raised during Serialization"""

    pass


class DeserializationError(ValueError):
    """Error raised during Deserialization"""

    pass


@dataclass(init=False)
class uint128:
    high: np.uint64
    low: np.uint64

    def __init__(self, num):
        self.high = np.uint64(num >> 64)
        self.low = np.uint64(num & 0xFFFFFFFFFFFFFFFF)

    def __int__(self):
        return (int(self.high) << 64) | int(self.low)


@dataclass(init=False)
class int128:
    high: np.int64
    low: np.uint64

    def __init__(self, num):
        self.high = np.int64(num >> 64)
        self.low = np.uint64(num & 0xFFFFFFFFFFFFFFFF)

    def __int__(self):
        return (int(self.high) << 64) | int(self.low)


@dataclass(init=False)
class char:
    value: str

    def __init__(self, s):
        if len(s) != 1:
            raise ValueError("`char` expects a single unicode character")
        self.value = s

    def __str__(self):
        return self.value


unit = typing.Type[None]

bool = bool
int8 = Union[np.int8, int]
int16 = Union[np.int16, int]
int32 = Union[np.int32, int]
int64 = Union[np.int64, int]

uint8 = Union[np.uint8, int]
uint16 = Union[np.uint16, int]
uint32 = Union[np.uint32, int]
uint64 = Union[np.uint64, int]

float32 = Union[np.float32, float]
float64 = Union[np.float64, float]
