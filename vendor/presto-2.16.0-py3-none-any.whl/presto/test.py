# -*- coding: utf-8 -*-
# copyright © 2018-2024 intermodulation products ab. all rights reserved.
from __future__ import annotations

from typing import List, Optional, Union

import numpy as np
from numpy.typing import ArrayLike

from . import _commands as cmd
from .hardware import AdcFSample, AdcMode, DacFSample, DacMode, Hardware
from .version import version_fpga as VERSION

FSAMPLE = 1e9  # Hz

VARIANT = 5

_DMA_MIN = 16 * 4  # bytes
_DMA_MUL = 16  # bytes


class Test:
    def __init__(
        self,
        ext_ref_clk: Union[None, bool, int, float] = False,
        address: Optional[str] = None,
        port: Optional[int] = None,
        force_reload: bool = False,
        dry_run: bool = False,
        adc_mode: Union[AdcMode, List[AdcMode]] = AdcMode.Direct,
        adc_fsample: Union[AdcFSample, List[AdcFSample]] = AdcFSample.G2,
        dac_mode: Union[DacMode, List[DacMode]] = DacMode.Direct,
        dac_fsample: Union[DacFSample, List[DacFSample]] = DacFSample.G4,
        force_config: bool = False,
    ):
        self._freqs: List[float] = [0.0] * 16
        self.dry_run: bool = dry_run
        self.hardware: Hardware = Hardware(
            address,
            port,
            dry_run,
            adc_bus_width=8,
            adc_fab_rate=250.0,
        )

        adc_mode, adc_fsample, dac_mode, dac_fsample = self.hardware.validate_config(
            adc_mode, adc_fsample, dac_mode, dac_fsample, force_config=force_config
        )
        if self.hardware.will_autoconfig():
            raise NotImplementedError("ADC/DAC autoconfig is not yet implemented for Test")

        try:
            if not self.dry_run:
                if force_reload:
                    self.hardware.reset()
                self.hardware.init_clock(ext_ref_clk)
                self.hardware.load_firmware(f"presto_{VARIANT:d}_{VERSION:d}.bin")
                self.hardware.init_presto()
                self.hardware.init_rfdc()

                var, ver = self.hardware.get_var_ver()
                if var != VARIANT:
                    raise RuntimeError(
                        f"The loaded firmware variant {var} does not match the expected {VARIANT}."
                        " This should not happen, please contact Intermodulation Products for support."
                    )
                if ver != VERSION:
                    raise RuntimeError(
                        "The version of the firmware running on the hardware is not compatible with the current API:"
                        f" got {ver}, expected {VERSION}. Have you updated both the API on the computer and the"
                        " software/firmware on the Vivace/Presto hardware?"
                    )

            # set user-requested configuration for the data converters
            self.hardware.setup_config()
            self.hardware.assert_errors()

            self.hardware.intr_clr()
            _ = self.hardware.get_intr_status()  # the first after MTS is polluted
            self.hardware.check_adc_intr_status()

            self.adc_direct = adc_mode[0] == AdcMode.Direct
            self.dac_direct = dac_mode[0] == DacMode.Direct
        except (Exception, KeyboardInterrupt):
            self.close()
            raise

    def __enter__(self):  # for use with 'with' statement
        return self

    def __exit__(self, exc_type, exc_value, traceback):  # pyright: ignore
        self.close()

    def close(self):
        self.hardware.close()

    def get_fs(self, which: str = "adc") -> float:
        if which == "adc":
            if self.adc_direct:
                return 2 * FSAMPLE
            else:
                return FSAMPLE
        elif which == "dac":
            if self.dac_direct:
                return 2 * FSAMPLE
            else:
                return FSAMPLE
        else:
            raise ValueError(f'which can be "adc" or "dac", got {which}')

    def get_dt(self, which: str = "adc") -> float:
        return 1 / self.get_fs(which=which)

    def blank_output(self, ports: ArrayLike, state: bool):
        ports = np.atleast_1d(ports).astype(np.int64)
        for port in ports:
            channel = port - 1
            self.hardware._send_command(cmd.Msg__TestBlank((channel, state)))

    def set_frequency(self, ports: ArrayLike, freq: float):
        ports = np.atleast_1d(ports).astype(np.int64)
        freq = float(freq)
        for port in ports:
            channel = port - 1
            self._freqs[channel] = freq
            self.hardware._send_command(cmd.Msg__TestFrequency((channel, freq)))

    def set_scale(self, ports: ArrayLike, scale_i: float, scale_q: Optional[float] = None):
        ports = np.atleast_1d(ports).astype(np.int64)
        scale_i = float(scale_i)
        if self.dac_direct:
            if scale_q is not None:
                raise ValueError("setting scale_q not allowed in direct mode.")
            scale_q = scale_i
        else:
            if scale_q is None:
                raise ValueError("scale_q must be set in mixed mode.")
            scale_q = float(scale_q)
        for port in ports:
            channel = port - 1
            self.hardware._send_command(cmd.Msg__TestScale((channel, scale_i, scale_q)))

    def set_phase(self, ports: ArrayLike, phase_i: float, phase_q: Optional[float] = None):
        ports = np.atleast_1d(ports).astype(np.int64)
        phase_i = float(phase_i)
        if self.dac_direct:
            if phase_q is not None:
                raise ValueError("setting phase_q not allowed in direct mode.")
        else:
            if phase_q is None:
                raise ValueError("phase_q must be set in mixed mode.")
            phase_q = float(phase_q)
        for port in ports:
            channel = port - 1
            if self.dac_direct:
                phase_q = phase_i + 2 * np.pi * self._freqs[channel] / self.get_fs("dac")
            self.hardware._send_command(cmd.Msg__TestPhase((channel, phase_i, phase_q)))  # pyright: ignore[reportArgumentType]

    def set_dither(self, ports: ArrayLike, state: bool):
        ports = np.atleast_1d(ports).astype(np.int64)
        for port in ports:
            channel = port - 1
            self.hardware._send_command(cmd.Msg__TestDither((channel, state)))

    def set_dma_source(self, port: int):
        dma_idx = 0
        port = int(port)
        channel = port - 1
        self.hardware._send_command(cmd.Msg__TestDmaSrc((dma_idx, channel)))

    def start_dma(self, nr_samples: int, nr_cycles: int = 1):
        nr_samples = int(nr_samples)
        nr_cycles = int(nr_cycles)
        if not self.adc_direct:
            nr_samples *= 2  # for I and Q
        nr_bytes = nr_samples * 2  # int16
        dma_idx = 0

        if nr_bytes < _DMA_MIN:
            nr_bytes = _DMA_MIN
        rem = nr_bytes % _DMA_MUL
        if rem > 0:
            nr_bytes += _DMA_MUL - rem
        self.hardware.start_dma(dma_idx, nr_bytes, nr_cycles=nr_cycles)

    def wait_for_dma(self, wait: bool = True):
        dma_idx = 0
        self.hardware.wait_for_dma(dma_idx, wait=wait)

    def stop_dma(self):
        dma_idx = 0
        self.hardware.stop_dma(dma_idx)

    def get_dma_data(self, nr_samples: int) -> np.ndarray:
        nr_samples = int(nr_samples)
        if not self.adc_direct:
            nr_samples *= 2  # for I and Q
        nr_bytes = nr_samples * 2  # int16
        reply = self.hardware.get_dma_data(nr_bytes)
        dtype = np.dtype(np.int16).newbyteorder("<")
        data = np.frombuffer(reply, dtype=dtype)
        return data
