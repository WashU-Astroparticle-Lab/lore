# -*- coding: utf-8 -*-
# Copyright © 2018-2024 Intermodulation Products AB. All Rights Reserved.
"""
Pulse-based experiment design and measurement.

Detailed information is provided in the documentation for each class.

.. autosummary::
    :nosignatures:

    Pulsed
    FlatPulse
    Event
    Template
    Match
    MeasurementHandle
    MeasurementStatus
    # NextFreq
    # NextScale
    # ResetPhase
    # SelFreq
    # SelScale
    # Store

**Module constants**:

  .. autodata:: MAX_LUT_ENTRIES
  .. autodata:: MAX_COMMANDS
  .. autodata:: MAX_STORE_LEN
  .. autodata:: MAX_TEMPLATE_LEN
  .. autodata:: MAX_THRESHOLD
"""

from __future__ import annotations

import copy
from datetime import datetime, timedelta
import enum
import functools
import math
import threading
import time
from typing import List, Optional, Sequence, Tuple, Union
import warnings
import weakref
from weakref import ReferenceType

import numpy as np
import numpy.typing as npt
from numpy.typing import ArrayLike

from . import _commands as cmd
from .hardware import AdcFSample, AdcMode, DacFSample, DacMode, Hardware, TriggerSource
from .utils import asarray, as_flat_list, format_sec, eprint_error
from .version import version_fpga

VARIANT: int = 6

OUT_TMPL_PER_CH: int = 16
OUT_TMPL_PER_GRP: int = OUT_TMPL_PER_CH // 2
NR_MATCH_GROUPS: int = 16
MATCH_TMPL_PER_GRP: int = 8
NR_COMPARATORS: int = NR_MATCH_GROUPS * MATCH_TMPL_PER_GRP // 2
NR_CONDITIONERS: int = 8
GRPS_PER_CMD: int = 4
MAX_LUT_ENTRIES: int = 512
"""maximum length of frequency/phase and scale look-up tables"""
MAX_STORE_LEN: int = 1_048_576
"""maximum number of samples in a contiguous acquisition window (:meth:`~Pulsed.store`)"""
SMPLS_PER_CLK: int = 4
MAX_TEMPLATE_LEN: int = 2048 - SMPLS_PER_CLK
"""maximum number of data points in a single template slot in direct mode. See also
:meth:`~Pulsed.get_max_template_len`"""
AVERAGING_RATE: float = 1e9  # S/s

# Internally we use int64 to represent the threshold and the match results
# In the API we use float64 scaled by 32767**2 so that a perfect match
# of a full-scale cosine gives 0.5 * T
_THRESHOLD_SCALE: int = 32767**2
# In Theory MAX_THRESHOLD could be (2**63 - 1) / _THRESHOLD_SCALE
# but we only have 52 bit precision, so we lose 11 bits
MAX_THRESHOLD: float = (2**63 - 2**11 - 1) / _THRESHOLD_SCALE
"""maximum threshold/result value for a template :meth:`~Pulsed.match`"""
_STORE_TO_MATCH_LATENCY: int = -3
"""clock cycles between a store and a match event"""
_DLY_DIG_OUT: int = 0
"""delay ``DigitalOut`` event to align with ``Template`` output"""

_DMA_MIN: int = 16 * 4  # bytes
_DMA_MUL: int = 16  # bytes
_DMA_MAX: int = 2_147_483_648  # 2 GBytes
_BYTES_PER_STORE_SAMPLE: int = 4  # when averaging
_BYTES_PER_MATCH: int = 8
_OCM_DATA_LEN: int = 21_472  # NOTE: keep in sync with rustws/ocm/src/lib.rs
MAX_COMMANDS: int = _OCM_DATA_LEN // 2  # 2x64bit words per command
"""maximum number of commands (trigger events) in an experiment sequence"""
_WRAPPING_TIME: int = 1 << 24  # clk cycles

# NOTE: keep in sync with rustws/ocm/src/lib.rs
_NR_OUTPUT_FIFOS = 32  # two groups per channel
_FIFO_MATCH_BASE: int = 32  # encode match command in 16 <= channel < 32
_NR_MATCH_FIFOS = 16
_FIFO_DIGOUT: int = 48  # encode store command as channel 32
_FIFO_STORE: int = 49  # encode store command as channel 33
_NR_FIFOS: int = 50
_MAX_TIME_OCM_CLK: int = 0x0000FFFFFFFFFFFF  # OCM stores time as 48 bits

_T_ZERO: datetime = datetime.fromtimestamp(0)

_ADD_DUMMIES: bool = True
_MAX_DUMMY_DELAY: int = 2**24 - 1


def no_after_run(meth):
    @functools.wraps(meth)
    def wrapper(self, *args, **kwargs):
        if self._status is not MeasurementStatus.IDLE:
            raise RuntimeError(f"method {meth.__name__}() can't be called after run()")
        return meth(self, *args, **kwargs)

    return wrapper


class Pulsed:
    def __init__(
        self,
        ext_ref_clk: Union[None, bool, int, float] = False,
        force_reload: bool = False,
        dry_run: bool = False,
        address: Optional[str] = None,
        port: Optional[int] = None,
        adc_mode: Union[AdcMode, List[AdcMode]] = AdcMode.Direct,
        adc_fsample: Optional[Union[AdcFSample, List[AdcFSample]]] = None,
        dac_mode: Union[DacMode, List[DacMode]] = DacMode.Direct,
        dac_fsample: Optional[Union[DacFSample, List[DacFSample]]] = None,
        force_config: bool = False,
        downsampling: int = 1,
    ):
        r"""Use the hardware in *pulsed* mode.

        Warning:
            Create only one instance at a time. Use each instance for only one measurement. This
            class is designed to be instantiated with Python's :ref:`with statement <python:with>`,
            see Examples section.

        Args:
            ext_ref_clk: if :obj:`None` or :obj:`False` use internal reference clock; if
                :obj:`True` use external reference clock (10 MHz); if :class:`float` or
                :class:`int` use external reference clock at ``ext_ref_clk`` Hz
            force_reload: if :obj:`True` re-configure clock and reload firmware even if there's no
                change from the previous settings.
            dry_run: if :obj:`True` don't connect to hardware, for testing only.
            address: IP address or hostname of the hardware. If :obj:`None`, use factory default
                ``"192.168.42.50"``.
            port: port number of the server running on the hardware. If :obj:`None`, use factory
                default ``7878``.
            adc_mode (AdcMode or list): configure the inputs to sample in direct mode (default), or
                to use the digital mixers for downconversion. See Notes.
            adc_fsample (AdcFSample or list): configure the inputs sampling rate. If :obj:`None`
                (default), choose optimal rate automatically. See Notes.
            dac_mode (DacMode or list): configure the outputs to work in direct mode (default), or
                to use the digital mixers for upconversion. See Notes.
            dac_fsample (DacFSample or list): configure the outputs sampling rate. If :obj:`None`
                (default), choose optimal rate automatically. See Notes.
            force_config: if :obj:`True` skip checks on ``DacMode``\ s not recommended for high DAC
                sampling rates.
            downsampling: reduce the intermediate-frequency sampling rate by this factor. Must be
                an integer >= 1. When ``downsampling=1`` (default), the IF sampling rate is 2 GS/s
                in real/direct mode and 1 GS/s in complex/mixed mode.

        Raises:
            ValueError: if ``adc_mode`` or ``dac_mode`` are not valid :ref:`converter modes`;
                if ``adc_fsample`` or ``dac_fsample`` are not valid :ref:`converter rates`.

        Notes:
            In all the Examples, it is assumed that the imports ``import numpy as np`` and
            ``from presto import pulsed`` have been performed, and that this class has been
            instantiated in the form ``pls = pulsed.Pulsed()``, or, **much much better**, using the
            ``with pulsed.Pulsed() as pls`` construct as below.

            For an introduction to ``adc_mode`` and ``dac_mode``, see :doc:`../special/direct_mixed`.
            For valid values of ``adc_mode`` and ``dac_mode``, see :ref:`converter modes`. For
            valid values of ``adc_fsample`` and ``dac_fsample``, see :ref:`converter rates`. For
            advanced configuration, e.g. different converter rates on different ports, see
            :ref:`adv tile`.

        Examples:
            Output a 2 ns pulse on output port 1 every 100 μs, and sample 1 μs of data from input
            port 1. Repeat 10 times, average 10k times.

            >>> from presto import pulsed
            >>> with pulsed.Pulsed() as pls:
            >>>     pls.setup_store(1, 1e-6)
            >>>     pulse = pls.setup_template(
            >>>         output_port=1,
            >>>         group=0,
            >>>         template=np.ones(4),
            >>>     )
            >>>     pls.output_pulse(0.0, pulse)
            >>>     pls.store(0.0)
            >>>     pls.run(
            >>>         period=100e-6,
            >>>         repeat_count=10,
            >>>         num_averages=10_000,
            >>>         print_time=True,
            >>>     )
            >>>     t_arr, data = pls.get_store_data()
            connecting to 192.168.42.50 port 7878
            Expected runtime: 10.0s
            Total time: 10.2s
            Transfering data: 3.0ms
        """
        self._status = MeasurementStatus.IDLE
        self._time_start = _T_ZERO
        self._time_end = _T_ZERO

        self.dry_run = bool(dry_run)
        self.thread = None
        # override Hardware.adc_fab_rate and Hardware.dac_fab_rate later on
        self.hardware: Hardware = Hardware(address, port, dry_run)
        """interface to hardware features common to all modes of operation"""

        (adc_mode, adc_fsample, dac_mode, dac_fsample) = self.hardware.validate_config(
            adc_mode, adc_fsample, dac_mode, dac_fsample, force_config=force_config
        )
        self.adc_direct = adc_mode[0] == AdcMode.Direct
        self.dac_direct = dac_mode[0] == DacMode.Direct

        downsampling = int(downsampling)
        if downsampling < 1:
            raise ValueError(f"downsampling must be an integer >= 1, got {downsampling}")
        if adc_fsample[0] == AdcFSample.G3_2:
            self.CLK_T = 2.5e-9 * downsampling
            self.CLK_F = 400e6 / downsampling
            self.hardware.adc_fab_rate = 400.0 / downsampling
            self.hardware.dac_fab_rate = 400.0 / downsampling
        else:
            self.CLK_T = 2e-9 * downsampling
            self.CLK_F = 500e6 / downsampling
            self.hardware.adc_fab_rate = 500.0 / downsampling
            self.hardware.dac_fab_rate = 500.0 / downsampling

        try:
            if not self.dry_run:
                if force_reload:
                    self.hardware.reset()
                self.hardware.init_clock(ext_ref_clk)
                self.hardware.load_firmware(f"presto_{VARIANT:d}_{version_fpga:d}.bin")
                self.hardware.init_presto()
                self.hardware.init_rfdc()

                var, ver = self.hardware.get_var_ver()
                if var != VARIANT:
                    raise RuntimeError(
                        f"The loaded firmware variant {var} does not match the expected {VARIANT}."
                        " This should not happen, please contact Intermodulation Products for support."
                    )
                self.hardware._check_version_fw(ver)
                self.hardware._check_version_rpu()

            if not self.hardware.dac_autoconfig:
                # set user-requested configuration for the data converters
                self.hardware.setup_config()
                self.hardware.assert_errors()
                self.hardware.intr_clr()
                _ = self.hardware.get_intr_status()  # the first after MTS is polluted
                self.hardware.check_adc_intr_status()

        except (Exception, KeyboardInterrupt):
            self.close()
            raise

        self.store_channels: List[int] = []
        self.store_len = 0
        self.saves = []
        self.used_templates: List[List[int]] = [[0] * 2 for _ in range(self.hardware.nr_ports)]
        self._match_mux: List[Optional[int]] = [None] * NR_MATCH_GROUPS
        self._match_next_port: List[bool] = [False] * NR_MATCH_GROUPS
        self._match_used_templates: List[int] = [0] * NR_MATCH_GROUPS
        self.templates: List[List[Optional[npt.NDArray[np.float64]]]] = [
            [None] * OUT_TMPL_PER_CH for _ in range(self.hardware.nr_ports)
        ]
        self.match_templates: List[List[Optional[npt.NDArray[np.float64]]]] = [
            [None] * MATCH_TMPL_PER_GRP for _ in range(NR_MATCH_GROUPS)
        ]
        self.scale_luts: List[List[Optional[npt.NDArray[np.float64]]]] = [
            [None] * 2 for _ in range(self.hardware.nr_ports)
        ]
        self.freq_luts: List[List[Optional[npt.NDArray[np.float64]]]] = [
            [None] * 2 for _ in range(self.hardware.nr_ports)
        ]
        self.phase_i_luts: List[List[Optional[npt.NDArray[np.float64]]]] = [
            [None] * 2 for _ in range(self.hardware.nr_ports)
        ]
        self.phase_q_luts: List[List[Optional[npt.NDArray[np.float64]]]] = [
            [None] * 2 for _ in range(self.hardware.nr_ports)
        ]
        self._scale_loop_count: List[List[int]] = [[1] * 2 for _ in range(self.hardware.nr_ports)]
        self._freq_loop_count: List[List[int]] = [[1] * 2 for _ in range(self.hardware.nr_ports)]
        self._scale_axis: List[List[int]] = [[0] * 2 for _ in range(self.hardware.nr_ports)]
        self._freq_axis: List[List[int]] = [[0] * 2 for _ in range(self.hardware.nr_ports)]
        self.modulate: List[int] = [0] * self.hardware.nr_ports
        self.seq = []

        self._tot_repeats = 0  # updated by _check()
        self._num_averages = 0  # updated by _check()
        self._dma_len_store = 0  # updated by _check()
        self._dma_len_match = 0  # updated by _check()
        self._nr_matches = 0  # updated by _check()
        self._print_time = False  # updated by _check()

        self._reply_matches = None  # updated by _run() reset by get_template_matching_data
        self._match_data = None  # updated by get_template_matching_data, reset by _run
        self._match_tags = None  # updated by get_template_matching_data, reset by _run

        self.used_conditioners = 0
        self.comparator_thresholds = [
            0
        ] * NR_COMPARATORS  # 64bit thresholds, one per comparator (compare_constant)
        self.comparator_crossport = 0  # 64bits, one bit per comparator (compare_iq)
        self.conditional = (
            0  # 256 bits, one bit per output template, 1 means conditional (default_mask)
        )
        self.conditional_false = (
            0  # 256 bits, one bit per output template, 1 means inverted (invert_condition)
        )
        self.conditioner_inputs = [0] * NR_CONDITIONERS
        # one bit per comparator (64bit words), 1 means don't use this comparison (condition_mask)
        self.conditioner_outputs = [0] * NR_CONDITIONERS
        # 256bit words, 1 bit per output template, 1 means control this output template (user_mask)

        self._histogram_matches: List[RawMatch] = []
        self._histogram_dim: int = 0  # 0 no histogram, 1 1D, 2 2D
        self._histogram_res_b: int = 18  # nr of bits, res = 1 << res_b

    def __enter__(self):  # for use with 'with' statement
        return self

    def __exit__(self, *_):  # for use with 'with' statement
        self.close()

    def time_to_clk(self, t: float) -> int:
        """Convert ``t`` to an integer number of clock cycles, raising an :class:`Exception` if
        rounding is needed.

        Args:
            t: time in seconds

        Returns:
            number of clock cycles

        Raises:
            ValueError: if ``t`` is not an integer multiple of :meth:`get_clk_T`;
                if ``t`` is negative.

        See also:
            :meth:`round_time`
            :meth:`get_clk_T`
        """
        t = float(t)
        c = int(round(t * self.CLK_F))
        if c < 0:
            raise ValueError("t must be nonnegative")
        if abs(c * self.CLK_T - t) > self.CLK_T / 100:
            raise ValueError(f"t={t} is not a multiple of the clock period {self.CLK_T}")
        return c

    def round_time(self, t: float) -> float:
        """Round ``t`` to a multiple of the clock period.

        Args:
            t: time in seconds

        Returns:
            the multiple of :meth:`get_clk_T` that is closest to ``t``

        See also:
            :meth:`get_clk_T`
            :meth:`time_to_clk`
        """
        t = float(t)
        c = int(round(t * self.CLK_F))
        return c * self.CLK_T

    def close(self):
        """Gracely disconnect from the hardware.

        Call this method if the class was instantiated without a
        :ref:`with statement <python:with>`. This method is called automatically when exiting a
        ``with`` block and before the object is destructed.
        """
        self.hardware.close()

    def get_clk_f(self) -> float:
        """Frequency of the programmable logic clock in Hz."""
        return self.CLK_F

    def get_clk_T(self) -> float:
        """Period of the programmable logic clock in seconds.

        This is also the granularity of the time grid for defining events in the experiment
        sequence.
        """
        return self.CLK_T

    def get_fs(self, which: str) -> float:
        """Get sampling frequency for ``which`` converter in Hz.

        Args:
            which: ``"adc"`` for input and ``"dac"`` for output.

        Raises:
            ValueError: if ``which`` is unknown.
        """
        if which == "adc":
            if self.adc_direct:
                return 4 * self.get_clk_f()
            else:
                return 2 * self.get_clk_f()
        elif which == "dac":
            if self.dac_direct:
                return 4 * self.get_clk_f()
            else:
                return 2 * self.get_clk_f()
        else:
            raise ValueError(f'which can be "adc" or "dac", got {which}')

    def get_nr_ports(self) -> int:
        """The number of available input/output ports in the hardware."""
        return self.hardware.nr_ports

    def get_max_template_len(self) -> int:
        """Maximum number of data points in a single template slot.

        Equal to :const:`MAX_TEMPLATE_LEN` when in direct mode (``dac_mode`` is
        :class:`DacMode.Direct <.DacMode>`), and half of it when using digital upconversion
        (``dac_mode`` is one of :class:`DacMode.Mixedxx <.DacMode>`).
        """
        if self.dac_direct:
            return MAX_TEMPLATE_LEN
        else:
            return MAX_TEMPLATE_LEN // 2

    @no_after_run
    def setup_store(self, input_ports, duration: float):
        r"""Set input port(s) and duration for all store events (data acquisition).

        Args:
            input_ports (int or list of int): Valid ports are in the interval
                [1, :meth:`get_nr_ports`\ ].
            duration: Duration in seconds. Must be a multiple of :meth:`get_clk_T`

        Raises:
            ValueError:
                if any of ``input_ports`` is out of [1, :meth:`get_nr_ports`\ ];
                if ``duration`` is not a multiple of :meth:`get_clk_T`;
                if a store ``duration`` on all ``input_ports`` results in an acquisition window
                with more than :const:`MAX_STORE_LEN` samples.

        See also:
            :meth:`store`
        """
        input_ports = np.atleast_1d(input_ports).astype(np.int64)
        if input_ports.min() < 1 or input_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid input ports are 1-{self.hardware.nr_ports}")

        clk_cyc = self.time_to_clk(duration)
        nr_samples = clk_cyc * SMPLS_PER_CLK

        self.store_channels = input_ports - 1
        self.store_len = nr_samples

    @no_after_run
    def set_store_ports(self, input_ports):
        """
        .. deprecated:: 2.13.0
            Use :meth:`setup_store` instead.
        """
        warnings.warn(
            message="set_store_ports is deprecated since version 2.13.0, use setup_store instead.",
            category=DeprecationWarning,
            stacklevel=2,
        )
        input_ports = np.atleast_1d(input_ports).astype(np.int64)
        if input_ports.min() < 1 or input_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid input ports are 1-{self.hardware.nr_ports}")
        self.store_channels = input_ports - 1

    @no_after_run
    def set_store_duration(self, T: float):
        """
        .. deprecated:: 2.13.0
            Use :meth:`setup_store` instead.
        """
        warnings.warn(
            message="set_store_duration is deprecated since version 2.13.0, use setup_store instead.",
            category=DeprecationWarning,
            stacklevel=2,
        )
        if len(self.store_channels) == 0:
            raise RuntimeError("did you forget to run set_store_ports?")
        clk_cyc = self.time_to_clk(T)
        nr_samples = clk_cyc * SMPLS_PER_CLK
        nr_channels = len(self.store_channels)
        tot_samples = nr_channels * nr_samples
        if tot_samples > MAX_STORE_LEN or tot_samples <= 0:
            raise ValueError(
                f"T = {1e9 * T:.0f} ns on {nr_channels} channels results in {tot_samples} samples, "
                f"but maximum is {MAX_STORE_LEN}"
            )
        self.store_len = nr_samples

    @no_after_run
    def store(self, at_time: float):
        """Program hardware to acquire data from the input ports at given time.

        Args:
            at_time: at what time in seconds the acquisition should start. Must be a multiple of
                :meth:`get_clk_T`

        Raises:
            ValueError: if ``at_time`` is not a multiple of :meth:`get_clk_T`;
            RuntimeError: if the store duration and the input ports have not been set up.

        Notes:
            The input ports and the duration of the acquisition are set up separately, see section
            *See also* below.

        See also:
            :meth:`setup_store`
        """
        if self.store_len == 0 or len(self.store_channels) == 0:
            raise RuntimeError("did you forget to run setup_store?")

        duration = self.store_len // SMPLS_PER_CLK
        time_clk = self.time_to_clk(at_time)
        for channel in self.store_channels:
            store = Store(channel=channel, duration=duration)
            self.seq.append([time_clk, store])
            self.saves.append((channel, self.store_len))

    @no_after_run
    def setup_scale_lut(
        self,
        output_ports: ArrayLike,
        group: int,
        scales: ArrayLike,
        axis: int = -1,
    ):
        r"""Setup look-up table for global output scale.

        Args:
            output_ports (int or array_like): Valid ports are in the interval
                [1, :meth:`get_nr_ports`\ ].
            group: Valid groups are in the interval [0, 1].
            scales (float or array_like): Output scale in ratio of full scale.
            axis: For multi-dimensional parameter sweeps, axis over which :meth:`next_scale` should
                increment scale index. If not given, the last (innermost) axis is used.
                Multi-dimensional parameter sweeps are *experimental* and the API might be fine
                tuned in a future release.

        Raises:
            ValueError: If any of ``output_ports`` is out of [1, :meth:`get_nr_ports`\ ]; if any
                of ``scales`` is out of [-1.0, +1.0]; if the LUT is longer than
                :const:`MAX_LUT_ENTRIES`; if ``group`` is out of [0, 1].

        See also:
            :meth:`next_scale`
            :meth:`select_scale`
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")

        group = int(group)
        if group not in range(2):
            raise ValueError("valid groups are 0-1")

        scales = np.atleast_1d(scales).astype(np.float64)
        if len(scales) > MAX_LUT_ENTRIES:
            raise ValueError(f"scales can contain at most {MAX_LUT_ENTRIES:d} elements")
        if np.any(np.abs(scales) > 1.0):
            raise ValueError("scale must be in [-1.0; +1.0]")

        for port in output_ports:
            channel = port - 1
            self.scale_luts[channel][group] = scales.copy()
            self._scale_axis[channel][group] = axis

    @no_after_run
    def setup_freq_lut(
        self,
        output_ports: ArrayLike,
        group: int,
        frequencies: ArrayLike,
        phases: ArrayLike,
        phases_q: Optional[ArrayLike] = None,
        axis: int = -1,
    ):
        r"""Setup look-up table for frequency generator.

        Args:
            output_ports (int or array_like): valid ports are in the interval
                [1, :meth:`get_nr_ports`\ ].
            group: valid groups are in the interval [0, 1].
            frequencies (float or array_like): frequency/ies in Hz for the generator.
            phases (float or array_like): phase(s) in radians for the generator. Must be same
                length as ``frequencies``. When ``dac_mode`` is not
                :class:`DacMode.Direct <.DacMode>`, this are the phases of the I quadrature to the
                upconversion digital mixer.
            phases_q (float or array_like): phase(s) in radians for Q quadrature to the
                upconversion digital mixer. Must be specified if and only if ``dac_mode`` is not
                :class:`DacMode.Direct <.DacMode>`.
            axis: For multi-dimensional parameter sweeps, axis over which :meth:`next_frequency`
                should increment frequency/phase index. If not given, the last (innermost) axis is
                used. Multi-dimensional parameter sweeps are *experimental* and the API might be
                fine tuned in a future release.

        Raises:
            ValueError: If any of ``output_ports`` is out of [1, :meth:`get_nr_ports`\ ];
                if any of ``frequencies`` is out of [0.0, :meth:`get_fs("dac") <get_fs>`\ );
                if ``group`` is out of [0, 1];
                if ``phases`` doesn't have the same shape as ``frequencies``;
                if the LUTs are longer than :const:`MAX_LUT_ENTRIES`;
                if ``phases_q`` is specified when not using the digital upconversion mixer
                (``dac_mode=DacMode.Direct``); if ``phases_q`` is not specified when using the
                digital upconversion mixer (``dac_mode=DacMode.Mixedxx``).

        See also:
            :meth:`next_frequency`
            :meth:`select_frequency`
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")

        group = int(group)
        if group not in range(2):
            raise ValueError("valid groups are 0-1")

        freq_lut = np.atleast_1d(frequencies).astype(np.float64)
        phase_i_lut = np.atleast_1d(phases).astype(np.float64)

        if len(phase_i_lut) != len(freq_lut):
            raise ValueError("frequency_lut and phase_lut must have the same dimensions")
        if len(freq_lut) > MAX_LUT_ENTRIES:
            raise ValueError(f"frequency_lut can contain at most {MAX_LUT_ENTRIES} elements")
        if np.any(freq_lut >= self.get_fs("dac") / 2) or np.any(freq_lut < 0):
            raise ValueError("Invalid frequency")

        if self.dac_direct:
            if phases_q is not None:
                raise ValueError("phases_q can't be specified when the DAC is in Direct mode")
            phase_q_lut = phase_i_lut + 2 * np.pi * freq_lut / self.get_fs("dac")
        else:
            if phases_q is None:
                raise ValueError("phases_q must be specified when the DAC is in Mixed mode")
            phase_q_lut = np.atleast_1d(phases_q).astype(np.float64)
            if len(phase_q_lut) != len(phase_i_lut):
                raise ValueError("phases and phases_q must have the same dimensions")

        for port in output_ports:
            channel = port - 1
            self.freq_luts[channel][group] = freq_lut.copy()
            self.phase_i_luts[channel][group] = phase_i_lut.copy()
            self.phase_q_luts[channel][group] = phase_q_lut.copy()
            self._freq_axis[channel][group] = axis

    @no_after_run
    def next_frequency(
        self,
        at_time: float,
        output_ports: ArrayLike,
        group: Optional[ArrayLike] = None,
    ):
        r"""Program the hardware to move to the next frequency/phase at given time.

        Args:
            at_time: At what time in seconds the change should happen. Must be a multiple of
                :meth:`get_clk_T`
            output_ports (int or array_like): What output ports should be affected by the change.
                Valid ports are in the interval [1, :meth:`get_nr_ports`\ ].
            group (int or array_like): Valid groups are in the interval [0, 1]. If :obj:`None`,
                move the carrier for both groups to the next entry.

        Raises:
            ValueError: if ``at_time`` is not a multiple of :meth:`get_clk_T`;
                if any of ``output_ports`` is out of [1, :meth:`get_nr_ports`\ ];
                if ``group`` is out of [0, 1].

        See also:
            :meth:`setup_freq_lut`
            :meth:`select_frequency`
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")

        if group is None:
            group = [0, 1]
        group = np.atleast_1d(group).astype(np.int64)
        if group.min() < 0 or group.max() > 1:
            raise ValueError("valid groups are [0, 1]")

        time_clk = self.time_to_clk(at_time)
        for port in output_ports:
            for grp in group:
                self.seq.append([time_clk, NextFreq(channel=port - 1, group=grp)])

    @no_after_run
    def next_scale(
        self,
        at_time: float,
        output_ports: ArrayLike,
        group: Optional[ArrayLike] = None,
    ):
        r"""Program the hardware to move to the next output scale at given time.

        Args:
            at_time: At what time in seconds the change should happen. Must be a multiple of
                :meth:`get_clk_T`
            output_ports (int or array_like): What output ports should be affected by the change.
                Valid ports are in the interval [1, :meth:`get_nr_ports`\ ].
            group (int or array_like): Valid groups are in the interval [0, 1]. If :obj:`None`,
                move both groups to the next entry.

        Raises:
            ValueError: if ``at_time`` is not a multiple of :meth:`get_clk_T`;
                if any of ``output_ports`` is out of [1, :meth:`get_nr_ports`\ ];
                if ``group`` is out of [0, 1].

        See also:
            :meth:`setup_scale_lut`
            :meth:`select_scale`
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")

        if group is None:
            group = [0, 1]
        group = np.atleast_1d(group).astype(np.int64)
        if group.min() < 0 or group.max() > 1:
            raise ValueError("valid groups are [0, 1]")

        time_clk = self.time_to_clk(at_time)
        for port in output_ports:
            for grp in group:
                self.seq.append([time_clk, NextScale(channel=port - 1, group=grp)])

    @no_after_run
    def reset_phase(
        self,
        at_time: float,
        output_ports: ArrayLike,
        group: Optional[ArrayLike] = None,
    ):
        r"""Program the hardware to reset the phase of ``group`` at given time.

        The phase will be reset to the current entry of the frequency/phase look-up table.

        Args:
            at_time: at what time in seconds the pulse(s) should be output. Must be a multiple of
                :meth:`get_clk_T`
            output_ports (int or array_like): what output ports should be affected by the reset.
                Valid ports are in the interval [1, :meth:`get_nr_ports`\ ].
            group (int or array_like): valid groups are in the interval [0, 1]. If ``None``,
                reset the phase of both groups.

        Raises:
            ValueError: if ``at_time`` is not a multiple of :meth:`get_clk_T`;
                if any of ``output_ports`` is out of [1, :meth:`get_nr_ports`\ ];
                if ``index`` is out of [0, :const:`MAX_LUT_ENTRIES` - 1];
                if ``group`` is out of [0, 1].

        See also:
            :meth:`setup_freq_lut`
            :meth:`next_frequency`
            :meth:`select_frequency`
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")

        if group is None:
            group = [0, 1]
        group = np.atleast_1d(group).astype(np.int64)
        if group.min() < 0 or group.max() > 1:
            raise ValueError("valid groups are range(2)")

        time_clk = self.time_to_clk(at_time)
        for port in output_ports:
            for grp in group:
                self.seq.append([time_clk, ResetPhase(channel=port - 1, group=grp)])

    @no_after_run
    def select_frequency(
        self,
        at_time: float,
        index: int,
        output_ports: ArrayLike,
        group: Optional[ArrayLike] = None,
    ):
        r"""Program the hardware to select a frequency/phase at given time.

        Args:
            at_time: At what time in seconds the change should happen. Must be a multiple of
                :meth:`get_clk_T`
            index: Zero-based index in look-up table to select. Valid indexes are in the interval
                [0, :const:`MAX_LUT_ENTRIES` - 1].
            output_ports (int or array_like): What output ports should be affected by the change.
                Valid ports are in the interval [1, :meth:`get_nr_ports`\ ].
            group (int or array_like): Valid groups are in the interval [0, 1]. If ``None``,
                select new frequency/phase on both groups.

        Raises:
            ValueError: if ``at_time`` is not a multiple of :meth:`get_clk_T`;
                f any of ``output_ports`` is out of [1, :meth:`get_nr_ports`\ ];
                if ``index`` is out of [0, :const:`MAX_LUT_ENTRIES` - 1];
                if ``group`` is out of [0, 1].

        See also:
            :meth:`setup_freq_lut`
            :meth:`next_frequency`
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")

        index = int(index)
        if index < 0 or index >= MAX_LUT_ENTRIES:
            raise ValueError(f"valid look-up table indexes are 0-{MAX_LUT_ENTRIES - 1}")

        if group is None:
            group = [0, 1]
        group = np.atleast_1d(group).astype(np.int64)
        if group.min() < 0 or group.max() > 1:
            raise ValueError("valid groups are [0, 1]")

        time_clk = self.time_to_clk(at_time)
        for port in output_ports:
            for grp in group:
                self.seq.append([time_clk, SelFreq(channel=port - 1, group=grp, index=index)])

    @no_after_run
    def select_scale(
        self,
        at_time: float,
        index: int,
        output_ports: ArrayLike,
        group: Optional[ArrayLike] = None,
    ):
        r"""Program the hardware to select an output scale at given time.

        Args:
            at_time: At what time in seconds the change should happen. Must be a multiple of
                :meth:`get_clk_T`
            index: Zero-based index in look-up table to select. Valid indexes are in the interval
                [0, :const:`MAX_LUT_ENTRIES` - 1].
            output_ports (int or array_like): What output ports should be affected by the change.
                Valid ports are in the interval [1, :meth:`get_nr_ports`\ ].
            group (int or array_like): Valid groups are in the interval [0, 1]. If ``None``,
                select new scale on both groups.

        Raises:
            ValueError: if ``at_time`` is not a multiple of :meth:`get_clk_T`;
                if any of ``output_ports`` is out of [1, :meth:`get_nr_ports`\ ];
                if ``index`` is out of [0, :const:`MAX_LUT_ENTRIES` - 1];
                if ``group`` is out of [0, 1].

        See also:
            :meth:`setup_scale_lut`
            :meth:`next_scale`
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")

        index = int(index)
        if index < 0 or index >= MAX_LUT_ENTRIES:
            raise ValueError(f"valid look-up table indexes are 0-{MAX_LUT_ENTRIES - 1}")

        if group is None:
            group = [0, 1]
        group = np.atleast_1d(group).astype(np.int64)
        if group.min() < 0 or group.max() > 1:
            raise ValueError("valid groups are [1, 2]")

        time_clk = self.time_to_clk(at_time)
        for port in output_ports:
            for grp in group:
                self.seq.append([time_clk, SelScale(channel=port - 1, group=grp, index=index)])

    @no_after_run
    def setup_long_drive(
        self,
        output_port: ArrayLike,
        group: int,
        duration: float,
        *,
        amplitude: Union[float, complex] = 1.0,
        amplitude_q: Optional[float] = None,
        rise_time: float = 0.0,
        fall_time: float = 0.0,
        envelope: bool = True,
        output_marker: Optional[int] = None,
    ) -> FlatPulse:
        r"""Create a long output pulse with constant amplitude, useful for using fewer templates.

        .. deprecated:: 2.14.0
            New code should use :meth:`setup_flat_pulse` instead. When migrating to the new method,
            pay attention to the change in defaults for parameters ``amplitude`` and ``envelope``:

            * ``envelope`` default value changes from ``True`` to ``False``;
            * ``amplitude`` default value changes from ``1+0j`` to ``1+1j`` when using digital
              upconversion.

        Args:
            output_port (int or array_like): valid ports are in the interval
                [1, :meth:`get_nr_ports`\ ].
            group: the group to use for this pulse, valid group are in the interval [0, 1].
            duration: total length of the pulse in seconds. Must be a multiple of :meth:`get_clk_T`
            amplitude: amplitude of the flat part of the pulse. Should be real when ``dac_mode`` is
                :class:`DacMode.Direct <.DacMode>`, and complex when using digital upconversion
                (:class:`DacMode.Mixedxx <.DacMode>`). Alternatively, use parameter ``amplitude_q``.
            amplitude_q: amplitude of the Q quadrature of the flat part of the pulse. Only used
                when ``dac_mode`` is one of :class:`DacMode.Mixedxx <.DacMode>`. Alternatively, use
                a complex value for the ``amplitude`` argument.
            rise_time: smoothen the initial ``rise_time`` seconds of the pulse. Must be a multiple
                of :meth:`get_clk_T`. See Notes.
            fall_time: smoothen the final ``fall_time`` seconds of the pulse. Must be a multiple of
                :meth:`get_clk_T`. See Notes.
            envelope: If :obj:`True` (default) set up an envelope instead of a template: the
                envelope will be multiplied by the carrier in ``group``. If :obj:`False`, set up a
                template: the template will be output as is. In both cases, the resulting waveform
                will be scaled by the scaler in ``group``.
            output_marker: output a high value from digital output number ``output_marker`` for the
                duration of the pulse. If :obj:`None` (default), no marker is output. Valid ports
                are in [1, 4].

        Returns:
            the newly created :class:`FlatPulse` object

        Raises:
            RuntimeError: If there are not enough templates available for the pair
                ``output_port``-``group``.
            ValueError: if ``output_port`` is out of [1, :meth:`get_nr_ports`\ ];
                if ``group`` is out of [0, 1];
                if ``amplitude`` is out of [-1.0, +1.0];
                if ``duration``, ``rise_time`` or ``fall_time`` are invalid.

        Notes:
            Regardless of ``duration``, only one template is consumed for a flat long drive.

            The amplitude of the pulse is affected by the group scaler configured with
            :meth:`setup_scale_lut`. The parameter ``amplitude`` is applied "in series".

            When ``rise_time`` and/or ``fall_time`` are nonzero, one additional template is used
            for each rise and fall segments. The rise and fall times are subtracted from the flat
            time, so that the total duration of the pulse including transients is ``duration``. The
            rise and fall shapes are :math:`\sin(\frac{\pi}{2}x)^2` and
            :math:`\cos(\frac{\pi}{2}x)^2`, respectively, with :math:`x \in [0, 1)`. The segments
            ``rise_time`` and ``fall_time`` are limited to 1022 ns (one template slot each).

        See also:

            * :meth:`setup_flat_pulse` : recommended for new code.
            * :meth:`setup_template` : create a custom template/envelope.
            * :meth:`output_pulse` : program hardware to output the generated pulse.
        """
        warnings.warn(
            message="setup_long_drive is deprecated since version 2.14.0, use setup_flat_pulse instead.",
            category=DeprecationWarning,
            stacklevel=2,
        )
        # use old code from setup_long_drive to check amplitude
        amplitude = complex(amplitude)
        if self.dac_direct:
            if amplitude.imag != 0.0:
                raise ValueError(
                    f"amplitude must be real when DAC is in Direct mode, got {amplitude}"
                )
            if amplitude_q is not None:
                raise ValueError("amplitude_q cannot be specified when DAC is in Direct mode")
        else:
            if amplitude_q is not None:
                if amplitude.imag != 0.0:
                    raise ValueError(
                        f"amplitude={amplitude} is complex AND amplitude_q={amplitude_q} is specified: choose one!"
                    )
                else:
                    amplitude += 1j * float(amplitude_q)

        return self.setup_flat_pulse(
            output_port=output_port,
            group=group,
            duration=duration,
            amplitude=amplitude,
            rise_time=rise_time,
            fall_time=fall_time,
            envelope=envelope,
            output_marker=output_marker,
        )

    @no_after_run
    def setup_flat_pulse(
        self,
        output_port: ArrayLike,
        group: int,
        duration: float,
        amplitude: Optional[Union[float, complex]] = None,
        *,
        rise_time: float = 0.0,
        fall_time: float = 0.0,
        envelope: bool = False,
        output_marker: Optional[int] = None,
    ) -> FlatPulse:
        r"""Create an output pulse with constant amplitude and optional rise/fall segments.

        Useful for using fewer templates with very long pulses, and for dynamically changing the
        duration of the pulse.

        Args:
            output_port (int or array_like): valid ports are in the interval
                [1, :meth:`get_nr_ports`\ ].
            group: the group to use for this pulse, valid group are in the interval [0, 1].
            duration: total length of the pulse in seconds. Must be a multiple of :meth:`get_clk_T`
            amplitude: amplitude of the flat part of the pulse. Should be real when ``dac_mode`` is
                :class:`DacMode.Direct <.DacMode>`, and complex when using digital upconversion
                (:class:`DacMode.Mixedxx <.DacMode>`). If no value is passed, use ``1.0`` in direct
                mode and ``1+1j`` in mixed mode.
            rise_time: smoothen the initial ``rise_time`` seconds of the pulse. Must be a multiple
                of :meth:`get_clk_T`. See Notes.
            fall_time: smoothen the final ``fall_time`` seconds of the pulse. Must be a multiple of
                :meth:`get_clk_T`. See Notes.
            envelope: set to :obj:`True` to set up an envelope instead of a template: the envelope
                will be multiplied by the carrier in ``group``. If :obj:`False` (default), set up a
                template: the template will be output as is. In both cases, the resulting waveform
                will be scaled by the scaler in ``group``.
            output_marker: output a high value from digital output number ``output_marker`` for the
                duration of the pulse. If :obj:`None` (default), no marker is output. Valid ports
                are in [1, 4].

        Returns:
            the newly created :class:`FlatPulse` object

        Raises:
            RuntimeError: If there are not enough templates available for the pair
                ``output_port``-``group``.
            ValueError: if ``output_port`` is out of [1, :meth:`get_nr_ports`\ ];
                if ``group`` is out of [0, 1];
                if ``amplitude`` is out of [-1.0, +1.0];
                if ``duration``, ``rise_time`` or ``fall_time`` are invalid.

        Notes:
            Regardless of ``duration``, only one template is consumed for a flat pulse.

            The ``duration`` of the pulse can be changed dynamically by using the methods
            :meth:`~FlatPulse.set_total_duration` and :meth:`~FlatPulse.set_flat_duration` on the
            returned :class:`FlatPulse` object.

            The amplitude of the pulse is affected by the group scaler configured with
            :meth:`setup_scale_lut`. The parameter ``amplitude`` is applied "in series".

            When ``rise_time`` and/or ``fall_time`` are nonzero, one additional template is used
            for each rise and fall segments. The rise and fall times are subtracted from the flat
            time, so that the total duration of the pulse including transients is ``duration``. The
            rise and fall shapes are :math:`\sin(\frac{\pi}{2}x)^2` and
            :math:`\cos(\frac{\pi}{2}x)^2`, respectively, with :math:`x \in [0, 1)`. The segments
            ``rise_time`` and ``fall_time`` are limited to 1022 ns (one template slot each).

        See also:
            :meth:`setup_template` : create a custom template/envelope.
            :meth:`output_pulse` : program hardware to output the generated pulse.
        """
        output_ports = np.atleast_1d(output_port).astype(np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")

        group = int(group)
        if group not in range(2):
            raise ValueError(f"Valid group are 0-1, got {group}")

        envelope = bool(envelope)

        if output_marker is not None:
            output_marker = int(output_marker)
            if output_marker < 1 or output_marker > 4:
                raise ValueError(f"Invalid output_marker, expected 1-4, got {output_marker}")

        templates_needed = 1
        if rise_time:
            templates_needed += 1
        if fall_time:
            templates_needed += 1

        # check we have enough templates on all ports
        for port in output_ports:
            port: int
            channel = port - 1
            used_templates = self.used_templates[channel][group]
            available_templates = OUT_TMPL_PER_GRP - used_templates
            if templates_needed > available_templates:
                raise RuntimeError(
                    f"Not enough template slots available on"
                    f" output {port} group {group}."
                    f" Need {templates_needed}, but {available_templates}"
                    f"/{OUT_TMPL_PER_GRP} are available."
                )

        total_clk = self.time_to_clk(duration)
        rise_clk = self.time_to_clk(rise_time)
        fall_clk = self.time_to_clk(fall_time)
        flat_clk = total_clk - rise_clk - fall_clk

        max_rise_fall_clk = MAX_TEMPLATE_LEN // SMPLS_PER_CLK
        max_rise_fall_time = max_rise_fall_clk * self.get_clk_T()
        if rise_clk > max_rise_fall_clk:
            raise ValueError(f"rise_time should be no larger than {max_rise_fall_time*1e9:.0f} ns")
        if fall_clk > max_rise_fall_clk:
            raise ValueError(f"fall_time should be no larger than {max_rise_fall_time*1e9:.0f} ns")
        if rise_clk + fall_clk > total_clk:
            raise ValueError("rise_time + fall_time can't be longer than duration")

        if amplitude is None:
            if self.dac_direct:
                amplitude = 1.0
            else:
                amplitude = 1 + 1j
        else:
            amplitude = complex(amplitude)
            if self.dac_direct:
                if amplitude.imag != 0.0:
                    raise ValueError(
                        f"amplitude must be real when DAC is in Direct mode, got {amplitude}"
                    )
                amplitude = amplitude.real

        if (abs(amplitude.real) > 1.0) or (abs(amplitude.imag) > 1.0):
            raise ValueError(
                f"real and imaginary parts of amplitude must be in [-1.0; +1.0], got {amplitude}"
            )

        if rise_clk:
            ns = SMPLS_PER_CLK * rise_clk
            if not self.dac_direct:
                ns //= 2
            x = np.linspace(0.0, 1.0, ns, endpoint=False)
            rise_template = amplitude.real * np.sin(np.pi / 2 * x) ** 2
            if self.dac_direct:
                rise_template_q = None
            else:
                rise_template_q = amplitude.imag * np.sin(np.pi / 2 * x) ** 2
            rise_pulse = self.setup_template(
                output_ports, group, rise_template, rise_template_q, envelope=envelope
            )
            rise_pulse = rise_pulse.get_templates()
        else:
            rise_pulse = []

        if self.dac_direct:
            flat_template = amplitude.real * np.ones(4 * SMPLS_PER_CLK)
            flat_template_q = None
        else:
            flat_template = amplitude.real * np.ones(2 * SMPLS_PER_CLK)
            flat_template_q = amplitude.imag * np.ones(2 * SMPLS_PER_CLK)
        flat_pulse = self.setup_template(
            output_ports, group, flat_template, flat_template_q, envelope=envelope
        )
        flat_pulse = flat_pulse.get_templates()
        for _p in flat_pulse:
            _p.duration = flat_clk
            _p.offset = rise_clk

        if fall_clk:
            ns = SMPLS_PER_CLK * fall_clk
            if not self.dac_direct:
                ns //= 2
            x = np.linspace(0.0, 1.0, ns, endpoint=False)
            fall_template = amplitude.real * np.cos(np.pi / 2 * x) ** 2
            if self.dac_direct:
                fall_template_q = None
            else:
                fall_template_q = amplitude.imag * np.cos(np.pi / 2 * x) ** 2
            fall_pulse = self.setup_template(
                output_ports, group, fall_template, fall_template_q, envelope=envelope
            )
            fall_pulse = fall_pulse.get_templates()
            for _p in fall_pulse:
                _p.offset = rise_clk + flat_clk
        else:
            fall_pulse = []

        pulse = FlatPulse(
            rise=rise_pulse,
            flat=flat_pulse,
            fall=fall_pulse,
            dig_out=output_marker - 1 if output_marker is not None else None,
            pls=weakref.ref(self),
        )

        return pulse

    @no_after_run
    def setup_template(
        self,
        output_port: ArrayLike,
        group: int,
        template: ArrayLike,
        template_q: Optional[ArrayLike] = None,
        *,
        envelope: bool = False,
        output_marker: Optional[int] = None,
    ) -> Template:
        r"""Create an output template or envelope.

        Args:
            output_port (int or array_like): Valid ports are in the interval
                [1, :meth:`get_nr_ports`\ ].
            group: The group to use for this pulse, valid group are in the interval [0, 1].
            template (array_like of float or complex): Data points for the template/envelope with
                :meth:`get_fs("dac") <get_fs>` sampling rate. Valid range is [-1.0, +1.0]. Array
                elements should be real when ``dac_mode`` is :class:`DacMode.Direct <.DacMode>`,
                and complex when using digital upconversion (:class:`DacMode.Mixedxx <.DacMode>`).
                Alternatively, use parameter ``template_q``.
            template_q (array_like of float): data points for the Q quadrature to the digital
                upconversion mixer. Only used when ``dac_mode`` is one of
                :class:`DacMode.Mixedxx <.DacMode>`. Alternatively, use elements with complex value
                for the ``template`` argument.
            envelope: If :obj:`True` set up an envelope instead of a template: the envelope will be
                multiplied by the carrier in ``group``. If :obj:`False` (default), set up a
                template: the template will be output as is. In both cases, the resulting waveform
                will be scaled by the scaler in ``group``.
            output_marker: Output a high value from digital output number ``output_marker`` for the
                duration of the pulse. If :obj:`None` (default), no marker is output. Valid ports
                are in [1, 4].

        Returns:
            the newly created :class:`Template` object.

        Raises:
            RuntimeError: If there are not enough templates available for the pair
                ``output_port``-``group``.
            ValueError: If any of ``output_port`` is out of [1, :meth:`get_nr_ports`\ ];
                if any sample in ``template`` is out of [-1.0, +1.0];
                if ``group`` is out of [0, 1].

        Notes:
            If the length of the pulse is longer than a single template slot
            (:meth:`get_max_template_len` samples), the pulse is automatically split into multiple
            segments of appropriate length. Therefore, the pulse might use more than one template
            slot.

        See also:
            :meth:`setup_flat_pulse`: create a (long) flat pulse using fewer templates.
            :meth:`output_pulse`: program hardware to output the generated template.
        """
        group = int(group)
        if group not in range(2):
            raise ValueError(f"Invalid group, expected 0-1, got {group}")

        envelope = bool(envelope)

        output_ports = asarray(output_port, np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")
        channels = output_ports - 1

        if output_marker is not None:
            output_marker = int(output_marker)
            if output_marker < 1 or output_marker > 4:
                raise ValueError(f"Invalid output_marker, expected 1-4, got {output_marker}")

        # make sure template is a complex np array
        template = np.atleast_1d(template).astype(np.complex128)

        if self.dac_direct:
            if np.any(np.imag(template) != 0.0):
                raise ValueError("template must be real when DAC is in Direct mode")
            if template_q is not None:
                raise ValueError("template_q cannot be specified when the DAC is in Direct mode")
        else:
            if template_q is not None:
                if np.any(np.imag(template) != 0.0):
                    raise ValueError(
                        "template is complex AND template_q is specified: choose one!"
                    )
                else:
                    template_q = np.atleast_1d(template_q).astype(np.float64)
                    template.imag = template_q

        if (np.max(np.abs(np.real(template))) > 1.0) or (np.max(np.abs(np.imag(template))) > 1.0):
            raise ValueError("all template values must be in [-1.0; +1.0]")

        if self.dac_direct:
            # discard imaginary part
            template = np.real(template)
        else:
            # we represent templates as IQ sequences
            template = np.frombuffer(template, np.float64)  # double the length!

        # template must be a multiple of SMPLS_PER_CLK samples
        if template.shape[0] % SMPLS_PER_CLK > 0:
            template = np.concatenate(
                (template, np.zeros(SMPLS_PER_CLK - template.shape[0] % SMPLS_PER_CLK))
            )

        # load templates and store template trigger information
        ret = Template(
            channels=channels.tolist(),  # pyright: ignore[reportArgumentType]
            group=group,
            envelope=envelope,
            events=[],  # set in the loop below
            pls=weakref.ref(self),
        )
        if output_marker is not None:
            ret.append(
                DigitalOut(
                    channel=output_marker - 1,
                    duration=template.shape[0] // SMPLS_PER_CLK,
                )
            )

        # check that there's enough template slots available
        templates_needed = math.ceil(template.shape[0] / MAX_TEMPLATE_LEN)
        for channel in channels:
            used_templates = self.used_templates[channel][group]
            available_templates = OUT_TMPL_PER_GRP - used_templates
            if templates_needed > available_templates:
                raise RuntimeError(
                    f"Not enough template slots available on"
                    f" output {channel+1} group {group}."
                    f" Need {templates_needed}, but {available_templates}"
                    f"/{OUT_TMPL_PER_GRP} are available."
                )

        offset = 0
        _zeros = [0] * SMPLS_PER_CLK
        while template.shape[0] > 0:
            subtempl_len = min(MAX_TEMPLATE_LEN, template.shape[0])
            for channel in channels:
                if self.used_templates[channel][group] >= OUT_TMPL_PER_GRP:
                    # this should not happen because we check above
                    raise RuntimeError(f"Not enough templates on output {channel+1} group {group}")
                index = self.used_templates[channel][group] + group * OUT_TMPL_PER_GRP
                ret.append(
                    RawTemplate(
                        channel=int(channel),
                        group=int(group),
                        index=int(index),
                        duration=int(subtempl_len // SMPLS_PER_CLK),
                        offset=int(offset),
                        envelope=bool(envelope),
                        inverted=None,  # set by setup_condition
                        pls=weakref.ref(self),
                    )
                )

                self.templates[channel][index] = np.r_[_zeros, template[:subtempl_len]]
                if envelope:
                    self.modulate[channel] |= 1 << index
                self.used_templates[channel][group] += 1
            offset += subtempl_len // SMPLS_PER_CLK
            template = template[subtempl_len:]

        return ret

    @no_after_run
    def setup_template_matching_pair(
        self,
        input_port: int,
        template1: npt.NDArray,
        template2: Optional[npt.NDArray] = None,
        threshold: float = 0.0,
        compare_next_port: bool = False,
    ) -> List[Match]:
        r"""Create a pair of input templates for template matching.

        The result of template matching can be obtained after the measurement with
        :meth:`get_template_matching_data`. The matching also defines a condition that can be used
        to mask one or more output templates during the measurement with :meth:`setup_condition`.
        The template-matching condition is True if the match with ``template1`` plus the match with
        ``template2`` is greater or equal than ``threshold``, False otherwise.

        Args:
            input_port: valid ports are in the interval [1, :meth:`get_nr_ports`\ ]. If
                ``compare_next_port=True``, it must be odd.
            template1 (array_like of float or complex)
            template2 (array_like of float or complex): data points for the templates with
                :meth:`get_fs("adc") <get_fs>` sampling rate. Valid range is [-1.0, +1.0]. If
                ``template2`` is not provided, it will be set to all zeros. ``dtype`` is
                :class:`float` when ``adc_mode=AdcMode.Direct`` and :class:`complex` when
                ``adc_mode=AdcMode.Mixed`` (when using digital downconversion).
            threshold: level for discrimination between a successful and failed comparison. The
                scale is such that a perfect match of a full-scale cosine over ``N`` data samples
                results in ``0.5 * N``.
            compare_next_port: if ``True``, match ``template1`` from ``input_port`` and
                ``template2`` from ``input_port+1``. If ``False``, match both from ``input_port``.

        Returns:
            a list of newly created :class:`Match` objects

        Raises:
            RuntimeError: if there are not enough templates available for ``input_port``.
            ValueError: if ``input_port`` is out of [1, :meth:`get_nr_ports`\ ];
                if any sample in the templates is out of [-1.0, +1.0];
                if ``abs(threshold)`` is bigger than :const:`MAX_THRESHOLD`.
            NotImplementedError: if the templates have different length.

        Notes:
            To evaluate a match, the input data acquired from port ``input_port`` is first
            multiplied with each template element-wise, and then summed. If the match using
            ``template1`` plus the match using ``template2`` is greater than or equal to
            ``threshold``, the match is considered successful.

            Each memory slot for reference templates can store up to :meth:`get_max_template_len`
            data points. If ``template1`` and ``template2`` are longer than that, they will be
            split into multiple sub-templates spanning multiple memory slots.

        See also:
            :meth:`setup_flat_matching_pair`
            :meth:`setup_condition`
            :meth:`match`
            :meth:`get_template_matching_data`
        """
        input_port = int(input_port)
        if input_port < 1 or input_port > self.hardware.nr_ports:
            raise ValueError(
                f"Invalid input_port, expected 1-{self.hardware.nr_ports}, got {input_port}"
            )
        compare_next_port = bool(compare_next_port)
        if compare_next_port and input_port % 2 != 1:
            raise ValueError("With compare_next_port=True, input_port must be odd.")

        # make sure template is a np array
        if self.adc_direct:
            template1 = np.atleast_1d(template1)
            if np.any(np.imag(template1) != 0.0):
                raise ValueError("template1 must be real when adc_mode=AdcMode.Direct")
            template1 = template1.astype(np.float64)
        else:
            template1 = np.atleast_1d(template1).astype(np.complex128)
            template1 = np.frombuffer(template1, np.float64)  # double the length!
        if (template1.max() > 1.0) or (template1.min() < -1.0):
            raise ValueError("all template values must be in [-1.0; +1.0]")

        if template2 is None:
            template2 = np.zeros_like(template1)
        else:
            if self.adc_direct:
                template2 = np.atleast_1d(template2)
                if np.any(np.imag(template2) != 0.0):
                    raise ValueError("template2 must be real when adc_mode=AdcMode.Direct")
                template2 = template2.astype(np.float64)
            else:
                template2 = np.atleast_1d(template2).astype(np.complex128)
                template2 = np.frombuffer(template2, np.float64)  # double the length!
            if len(template2) != len(template1):
                raise NotImplementedError("templates must have same length")
            if (template2.max() > 1.0) or (template2.min() < -1.0):
                raise ValueError("all template values must be in [-1.0; +1.0]")

        threshold = float(threshold)
        if abs(threshold) > MAX_THRESHOLD:
            raise ValueError(f"Maximum value for threshold is {MAX_THRESHOLD}, got {threshold}")

        # NOTE: from now on, we assume template1 and template2 have same length

        # template must be a multiple of SMPLS_PER_CLK samples
        tmpl_len = len(template1)
        if tmpl_len % SMPLS_PER_CLK > 0:
            template1 = np.r_[template1, np.zeros(SMPLS_PER_CLK - tmpl_len % SMPLS_PER_CLK)]
            template2 = np.r_[template2, np.zeros(SMPLS_PER_CLK - tmpl_len % SMPLS_PER_CLK)]
            tmpl_len = len(template1)

        _zeros = [0] * SMPLS_PER_CLK
        match1 = Match(
            threshold=int(round(threshold * _THRESHOLD_SCALE)),
            cross_group=compare_next_port,
            pls=weakref.ref(self),
            events=[],
        )
        match2 = Match(
            threshold=int(round(threshold * _THRESHOLD_SCALE)),
            cross_group=compare_next_port,
            pls=weakref.ref(self),
            events=[],
        )
        offset = 0
        while len(template1) > 0:
            # find where to put the (sub-)templates
            grp_idx = self._find_match_group_index(input_port, compare_next_port)
            if grp_idx is None:
                raise RuntimeError(
                    f"No available slots for reference templates on input port {input_port}"
                )
            grp1, idx1 = grp_idx
            if compare_next_port:
                grp2 = grp1 + 1
                idx2 = idx1
            else:
                grp2 = grp1
                idx2 = idx1 + 1

            subtempl_len = min(MAX_TEMPLATE_LEN, template1.shape[0])
            match1.append(
                RawMatch(
                    group=grp1,
                    index=idx1,
                    duration=subtempl_len // SMPLS_PER_CLK,
                    offset=offset,
                    pls=weakref.ref(self),
                )
            )
            match2.append(
                RawMatch(
                    group=grp2,
                    index=idx2,
                    duration=subtempl_len // SMPLS_PER_CLK,
                    offset=offset,
                    pls=weakref.ref(self),
                )
            )

            self.match_templates[grp1][idx1] = np.r_[_zeros, template1[:subtempl_len]]
            self.match_templates[grp2][idx2] = np.r_[_zeros, template2[:subtempl_len]]  # pyright: ignore[reportOptionalSubscript]

            offset += subtempl_len // SMPLS_PER_CLK
            template1 = template1[subtempl_len:]
            template2 = template2[subtempl_len:]  # pyright: ignore[reportOptionalSubscript]

        return [match1, match2]

    @no_after_run
    def setup_flat_matching_pair(
        self,
        input_port: int,
        duration: float,
        weight1: Union[float, complex],
        weight2: Optional[Union[float, complex]] = None,
        *,
        threshold: float = 0.0,
        compare_next_port: bool = False,
    ) -> List[Match]:
        r"""Create a pair of constant input templates for template matching with given ``duration``.

        The reference templates created with this method are flat, i.e. have a constant weight, and
        use a single memory slot each regardless of ``duration``.
        See :meth:`setup_template_matching_pair` for reference templates with arbitrary shape.

        The result of template matching can be obtained after the measurement with
        :meth:`get_template_matching_data`. The matching also defines a condition that can be used
        to mask one or more output templates during the measurement with :meth:`setup_condition`.
        The template-matching condition is True if the match with ``weight1`` plus the match with
        ``weight2`` is greater or equal than ``threshold``, False otherwise.

        Args:
            input_port: valid ports are in the interval [1, :meth:`get_nr_ports`\ ]. If
                ``compare_next_port=True``, it must be odd.
            duration: length of the template matching in seconds.
                Must be a multiple of :meth:`get_clk_T`.
            weight1
            weight2: amplitudes for the reference templates for template matching. Valid range is
                [-1.0, +1.0] for both real and imaginary part. If ``weight2`` is not provided, it
                is set to zero. Type is :class:`float` when ``adc_mode=AdcMode.Direct`` and
                :class:`complex` when ``adc_mode=AdcMode.Mixed`` (when using digital downconversion).
            threshold: level for discrimination between a successful and failed comparison. The
                scale is such that a perfect match of a full-scale cosine over ``N`` data samples
                results in ``0.5 * N``.
            compare_next_port: if ``True``, match ``weight1`` from ``input_port`` and ``weight2``
                from ``input_port+1``. If ``False``, match both from ``input_port``.

        Returns:
            a list of newly created :class:`Match` objects

        Raises:
            RuntimeError: if there are not enough templates available for ``input_port``.
            ValueError: if ``input_port`` is out of [1, :meth:`get_nr_ports`\ ];
                if the real or imaginary parts of ``weight1`` or ``weight2`` are not in [-1.0, +1.0];
                if ``abs(threshold)`` is bigger than :const:`MAX_THRESHOLD`.

        Notes:
            To evaluate a match, the input data acquired from port ``input_port`` is first
            multiplied with each template element-wise, and then summed. If the match using
            ``weight1`` plus the match using ``weight2`` is greater than or equal to ``threshold``,
            the match is considered successful.

        See also:
            :meth:`setup_template_matching_pair`
            :meth:`setup_condition`
            :meth:`match`
            :meth:`get_template_matching_data`
        """
        # only check duration and weights here,
        # let setup_template_matching_pair check the rest
        duration_clk = self.time_to_clk(duration)

        weight1 = complex(weight1)
        if self.adc_direct:
            if weight1.imag != 0:
                raise ValueError("weight1 must be real when adc_mode=AdcMode.Direct")
            weight1 = weight1.real
        if (abs(weight1.real) > 1.0) or (abs(weight1.imag) > 1.0):
            raise ValueError(
                f"real and imaginary parts of weight1 must be in [-1.0; +1.0], got {weight1}"
            )

        if weight2 is None:
            weight2 = 0.0 if self.adc_direct else 0j
        else:
            weight2 = complex(weight2)
            if self.adc_direct:
                if weight2.imag != 0:
                    raise ValueError("weight2 must be real when adc_mode=AdcMode.Direct")
                weight2 = weight2.real
            if (abs(weight2.real) > 1.0) or (abs(weight2.imag) > 1.0):
                raise ValueError(
                    f"real and imaginary parts of weight2 must be in [-1.0; +1.0], got {weight2}"
                )

        if self.adc_direct:
            template1 = np.full(4 * SMPLS_PER_CLK, weight1)
            template2 = np.full(4 * SMPLS_PER_CLK, weight2)
        else:
            template1 = np.full(2 * SMPLS_PER_CLK, weight1)
            template2 = np.full(2 * SMPLS_PER_CLK, weight2)

        match1, match2 = self.setup_template_matching_pair(
            input_port=input_port,
            template1=template1,
            template2=template2,
            threshold=threshold,
            compare_next_port=compare_next_port,
        )
        raw1 = match1.get_single()
        raw2 = match2.get_single()
        assert raw1 is not None
        assert raw2 is not None
        raw1.duration = duration_clk
        raw2.duration = duration_clk

        return [match1, match2]

    def _find_match_group_index(
        self, input_port: int, compare_next_port: bool
    ) -> Optional[Tuple[int, int]]:
        # assume we want space for 2 templates
        # either in the same group if not compare_next_port
        # or in adjacent groups if compare_next_port
        channel = input_port - 1
        if not compare_next_port:
            for grp in range(NR_MATCH_GROUPS):
                if self._match_mux[grp] is None:
                    self._match_mux[grp] = channel
                    self._match_next_port[grp] = False
                    self._match_used_templates[grp] = 2
                    return (grp, 0)
                elif (
                    self._match_mux[grp] == channel
                    and not self._match_next_port[grp]
                    and self._match_used_templates[grp] + 2 <= MATCH_TMPL_PER_GRP
                ):
                    idx = self._match_used_templates[grp]
                    self._match_used_templates[grp] += 2
                    return (grp, idx)
        else:
            for grp in range(0, NR_MATCH_GROUPS, 2):
                if self._match_mux[grp] is None:
                    assert self._match_mux[grp + 1] is None
                    self._match_mux[grp] = channel
                    self._match_mux[grp + 1] = channel + 1
                    self._match_next_port[grp] = True
                    self._match_next_port[grp + 1] = True
                    self._match_used_templates[grp] = 1
                    self._match_used_templates[grp + 1] = 1
                    return (grp, 0)
                elif (
                    self._match_mux[grp] == channel
                    and self._match_next_port[grp]
                    and self._match_used_templates[grp] + 1 <= MATCH_TMPL_PER_GRP
                    and self._match_mux[grp + 1] == channel + 1
                    and self._match_next_port[grp + 1]
                    and self._match_used_templates[grp + 1] + 1 <= MATCH_TMPL_PER_GRP
                ):
                    idx = self._match_used_templates[grp]
                    assert idx == self._match_used_templates[grp + 1]
                    self._match_used_templates[grp] += 1
                    self._match_used_templates[grp + 1] += 1
                    return (grp, idx)
        return None

    @no_after_run
    def match(self, at_time: float, match_info: Union[Match, List[Match]]):
        """Program hardware to perform template matching at given time.

        Args:
            at_time: At what time in seconds the template(s) should be matched. Must be a multiple
                of :meth:`get_clk_T`
            template_info: The information about one or more template-matching pairs as obtained
                from :meth:`setup_template_matching_pair`.

        Raises:
            ValueError: if ``at_time`` is not a multiple of :meth:`get_clk_T`
            TypeError: if ``template_info`` contains unrecognized objects.

        See also:
            :meth:`setup_template_matching_pair`
        """
        matches = as_flat_list(match_info)
        time_clk = self.time_to_clk(at_time)
        for match in matches:
            if not isinstance(match, Match):
                raise TypeError("{} is not a valid Match event!".format(match))
            for sub_tmpl in match.get_events():
                self.seq.append([time_clk, sub_tmpl])

    @no_after_run
    def output_pulse(
        self,
        at_time: float,
        pulse_info: Union[Template, FlatPulse, List[Union[Template, FlatPulse]]],
    ):
        """Program hardware to output pulse(s) at given time.

        Args:
            at_time: at what time in seconds the pulse(s) should be output. Must be a multiple of
                :meth:`get_clk_T`
            pulse_info: information about one or more pulses as obtained from
                :meth:`setup_template` or :meth:`setup_flat_pulse`

        Raises:
            ValueError: if ``at_time`` is not a multiple of :meth:`get_clk_T`
            TypeError: if ``pulse_info`` contains unrecognized objects
        """
        templates = as_flat_list(pulse_info)
        time_clk = self.time_to_clk(at_time)
        for template in templates:
            if isinstance(template, (Template, FlatPulse)):
                for partial_event in template.get_events():
                    self.seq.append([time_clk, partial_event])
            else:
                raise TypeError(f"Not a valid pulse: {template}")

    @no_after_run
    def output_digital_marker(self, at_time: float, duration: float, ports: ArrayLike):
        """Program hardware to output a digital marker at given time.

        Args:
            at_time: at what time in seconds the marker should be output. Must be a multiple of
                :meth:`get_clk_T`
            duration: for how long in seconds the marker should be output. Must be a multiple of
                :meth:`get_clk_T`
            port (int or array_like): digital output port(s) the marker should be output from.
                Valid values are in [1, 4]

        Raises:
            ValueError: if ``ports`` is out of range;
                if ``at_time`` is not a multiple of :meth:`get_clk_T`
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        if ports.min() < 1 or ports.max() > 4:
            raise ValueError("valid output ports are 1-4")
        time_clk = self.time_to_clk(at_time)
        duration_clk = self.time_to_clk(duration)

        for port in ports:
            dig_out = DigitalOut(
                channel=port - 1,
                duration=duration_clk,
            )
            self.seq.append([time_clk, dig_out])

    @no_after_run
    def output_dc_bias(self, at_time: float, bias: float, port: ArrayLike):
        """Program hardware to output a DC bias at given time.

        Args:
            at_time: at what time in seconds the bias should be output. Must be a multiple of
                :meth:`get_clk_T`
            bias: DC bias value in volts.
            port (int or array_like): output port(s) the DC bias should be output from. Valid
                values are in [1, 16]. See Notes for behavior when more than one port is addressed.

        Notes:
            It is not possible to change the DC *range* during an experimental sequence. Only the
            bias *value* can be changed. It is required to use :meth:`.Hardware.set_dc_bias` to
            configure the range and the initial DC-bias value for ``port`` **before** programming
            the experimental sequence. It is also recommended to use :meth:`.Hardware.set_dc_bias`
            to reset the value to zero after the experiment terminated, *i.e.* after a call to
            :meth:`run`.

            Updating the DC bias on one port takes 1 μs, during which no other DC bias event should
            be scheduled. Updating the bias on ``n`` ports takes ``n`` μs, and all ports will
            switch to the new value simultaneously.

        Raises:
            ValueError: if ``port`` is out of range;
                if ``at_time`` is not a multiple of :meth:`get_clk_T`;
                if ``bias`` is larger than the current setting for DC-bias range on ``port``.
            RuntimeError: if the DC range for ``port`` was not set.
        """
        if self.hardware.board == "zcu111":
            max_port = 8
        else:
            max_port = 16

        time_clk = self.time_to_clk(at_time)
        bias = float(bias)
        port_arr = np.atleast_1d(port).astype(np.int64)
        if np.any(port_arr < 1) or np.any(port_arr > max_port):
            raise ValueError(f"port must be in [1, {max_port}]")

        seq_temp = []
        for port_ in port_arr:
            port_: int
            try:
                (min_bias, max_bias) = self.hardware.last_dc_range(port_)
            except KeyError:
                raise RuntimeError(
                    f"no current range found for port {port_}, "
                    "have you run hardware.set_dc_bias to set the initial configuration?"
                ) from None
            if bias < min_bias or bias > max_bias:
                raise ValueError(
                    f"bias {bias} is not within the current DC-bias range "
                    f"{min_bias:.2f},{max_bias:.2f}] for port {port_}"
                )
            # switch to full-scale units
            bias_fs = bias / max_bias

            if min_bias == 0.0:
                # positive-only range
                bias_code = int(round(bias_fs * 65535))
            else:
                # bipolar range
                ni = int(round(bias_fs * 32767))
                bias_code = ni + 0x8000
            channel = port_ - 1

            if self.hardware.board == "zcu111":
                raw_command = 1 << 19  # DACx register
                raw_command |= channel << 16
                raw_command |= bias_code
            else:
                raw_command = 0x00_0000  # Write code to DAC Channel x (no update)
                raw_command |= channel << 16  # Channel x
                raw_command |= bias_code  # code

            dc_bias_out = DcBiasOut(
                channel=port_ - 1,
                raw_command=raw_command,
            )
            seq_temp.append([time_clk, dc_bias_out])
            time_clk += self.time_to_clk(1e-6)

        if seq_temp and not self.hardware.board == "zcu111":
            # gen3 switch last command
            # from 0x00_0000 Write code to DAC Channel x
            # to   0x50_0000 Write code to DAC Channel x, update all DAC channels
            seq_temp[-1][1].raw_command |= 0x50_0000

        self.seq.extend(seq_temp)

    def get_store_data(self, use_compression: bool = False) -> Tuple[np.ndarray, np.ndarray]:
        """Obtain from hardware the result of the (averaged) stores.

        Only valid after the measurement is performed.

        Args:
            use_compression: if :obj:`True`, use lossless compression when downloading measurement
                data. See Notes section below.

        Returns:
            A tuple of ``(t_arr, data)`` where

              - ``t_arr`` (:class:`~numpy.ndarray`): The time axis in seconds during one acquisition.
                ``dtype`` is :class:`float`.
              - ``data`` (:class:`~numpy.ndarray`): The acquired data with
                :meth:`get_fs("adc") <Pulsed.get_fs>` sample rate and scaled to +/-1.0 being
                full-scale input. The shape of the array is
                ``(num_stores * repeat_count, num_ports, smpls_per_store)``, where ``num_stores`` is
                number of store events programmed in a sequence with the :meth:`store` method, and
                ``num_ports`` and ``smpls_per_store`` are the number of inputs ports and the number
                of samples in one acquisition set up with :meth:`setup_store`.

        Notes:
            When using digital downconversion (``adc_mode=AdcMode.Mixed``), the returned ``data``
            is complex (``dtype=np.complex128``); in direct mode (``adc_mode=AdcMode.Direct``)
            ``data`` is real (``dtype=np.float64``).

            Using lossless compression when downloading measurement data (``compression=True``)
            requires the third-party Python package `lz4`_ which can be installed from `PyPI`_ with
            ``pip install lz4`` or from `Anaconda`_ with ``conda install lz4``.

        Raises:
            RuntimeError: If no store data is available.
            ImportError: if the Python package ``lz4`` is not installed when using
                ``compression=True``, see Notes section above.

        See also:
            :meth:`store`
            :meth:`run`

        .. _lz4: https://github.com/python-lz4/python-lz4
        .. _PyPI: https://pypi.org/project/lz4/
        .. _Anaconda: https://anaconda.org/anaconda/lz4
        """
        if self.dry_run:
            raise RuntimeError("No store data available. This is a dry run!")
        if self._status != MeasurementStatus.DONE:
            raise RuntimeError("No store data available. Have you run a measurement?")
        if self._dma_len_store <= 0:
            raise RuntimeError(
                "No store data available. Was there any store() in the measurement sequence?"
            )

        t0 = datetime.now()
        if self._print_time:
            print("Downloading store data: ...", end="\r", flush=True)

        nr_store_ch = len(self.store_channels)

        reply = self.hardware.get_dma_data(self._dma_len_store, compression=use_compression)
        dtype = np.dtype(np.int32).newbyteorder("<")
        data = np.frombuffer(reply, dtype=dtype)

        # reshape
        nr_stores = self._tot_repeats * len(self.saves) // nr_store_ch
        data.shape = (nr_stores, self.store_len // 4, nr_store_ch, 4)
        temp = np.empty((nr_stores, nr_store_ch, self.store_len), dtype=dtype)
        for _iii in range(nr_store_ch):
            temp[:, _iii, :] = np.reshape(data[:, :, _iii, :], (nr_stores, self.store_len))

        # scale to +-1 of input range. NOTE: double the precision int32 --> float64
        data = temp / 32767 / self._num_averages

        if not self.adc_direct:
            # make data complex without copying
            data = np.frombuffer(data, np.complex128)  # half the length!
            data.shape = (nr_stores, nr_store_ch, self.store_len // 2)

        # create time array
        t_arr = np.arange(data.shape[-1]) / self.get_fs("adc")

        t1 = datetime.now()
        if self._print_time:
            print(f"Downloading store data: {format_sec(t1-t0):s}")

        return t_arr, data

    def get_template_matching_data(
        self, input_pairs: Union[Match, List[Match]], use_compression: bool = False
    ) -> List[np.ndarray]:
        """Obtain from hardware the result of the template matching.

        Only valid after the measurement is performed.

        Args:
            input_pairs: One or more template-matching pairs as defined by
                :meth:`setup_template_matching_pair`.
            use_compression: if :obj:`True`, use lossless compression when downloading measurement
                data. See Notes section below.

        Returns:
            A list ``ret`` where, for each element (input template) of ``input_pairs``, ``ret``
            contains a :class:`numpy.ndarray` with the template-matching results for that template.
            Therefore, ``len(input_pairs) == len(ret)``. ``dtype`` is :class:`float`. The data is
            scaled such that a perfect match of a full-scale cosine over ``N`` data samples is
            ``0.5 * N``.

        Raises:
            RuntimeError: If no template-matching data is available.
            TypeError: If ``input_pairs`` contains unrecognized objects.

        See also:
            :meth:`setup_template_matching_pair`
            :meth:`match`
            :meth:`run`
        """
        if self.dry_run:
            raise RuntimeError("No match data available. This is a dry run!")
        if self._status != MeasurementStatus.DONE:
            raise RuntimeError("No match data available. Have you run a measurement?")
        if self._nr_matches <= 0:
            raise RuntimeError(
                "No match data available. Was there any match() in the measurement sequence?"
            )

        if self._match_data is None:
            # download new data if not available, otherwise use cached data
            t0 = datetime.now()
            if self._print_time:
                print("Downloading match data: ...", end="\r", flush=True)

            if self._reply_matches is not None:
                reply_matches = self._reply_matches
                self._reply_matches = None
            elif self._nr_matches > 0:
                reply_matches = self.hardware.get_dma_data(
                    self._dma_len_match, high_mem=True, compression=use_compression
                )
            else:
                assert False  # we check that self._nr_matches > 0 above

            dtype = np.dtype(np.int64).newbyteorder("<")
            match_data = np.frombuffer(reply_matches, dtype=dtype)
            self._match_tags = match_data.astype(np.uint16)  # the low 16 bits is the tag
            match_data >>= 16  # remove tag
            self._match_data = match_data.view(np.float64)
            self._match_data[:] = match_data  # convert int64->float64 in place
            self._match_data /= float(_THRESHOLD_SCALE)  # scale

            t1 = datetime.now()
            if self._print_time:
                print(f"Downloading match data: {format_sec(t1-t0):s}")

        matches = as_flat_list(input_pairs)

        ret = []
        for match in matches:
            if not isinstance(match, Match):
                raise TypeError("{} is not a valid Match event!".format(match))
            # sum together all the sub-matches
            ret.append(
                np.sum(
                    [
                        self._match_data[self._match_tags == submatch.tag()]
                        for submatch in match.get_events()
                    ],
                    axis=0,
                )
            )

        return ret

    def _process_sequence(self, period_clk: int) -> Tuple[List, int]:
        out_cmds: List[List[List[Tuple[int, CmdOutput]]]] = [
            [[], []] for _ in range(self.hardware.nr_ports)
        ]
        match_cmds: List[List[Tuple[int, CmdMatch]]] = [[] for _ in range(NR_MATCH_GROUPS)]
        store_cmds: List[Tuple[int, CmdStore]] = []
        digout_cmds: List[Tuple[int, CmdMarker]] = []
        nr_matches = 0
        for time_clk, entry in self.seq:
            if isinstance(entry, RawTemplate):
                index = entry.index % OUT_TMPL_PER_GRP
                out_cmds[entry.channel][entry.group].append(
                    (
                        time_clk + entry.offset,
                        CmdOutput(start_mask=1 << index),
                    )
                )
                out_cmds[entry.channel][entry.group].append(
                    (
                        time_clk + entry.offset + entry.duration,
                        CmdOutput(stop_mask=1 << index),
                    )
                )
            elif isinstance(entry, RawMatch):
                block = entry.group // GRPS_PER_CMD
                index = (entry.group % GRPS_PER_CMD) * MATCH_TMPL_PER_GRP + entry.index
                match_cmds[block].append(
                    (
                        time_clk + entry.offset + _STORE_TO_MATCH_LATENCY,
                        CmdMatch(start_mask=1 << index),
                    )
                )
                match_cmds[block].append(
                    (
                        time_clk + entry.offset + entry.duration + _STORE_TO_MATCH_LATENCY,
                        CmdMatch(stop_mask=1 << index),
                    )
                )
                nr_matches += 1
            elif isinstance(entry, Store):
                store_cmds.append((time_clk, CmdStore(store_mask=1 << entry.channel)))
                store_cmds.append((time_clk + entry.duration, CmdStore(store_mask=0)))
            elif isinstance(entry, DigitalOut):
                digout_cmds.append(
                    (
                        time_clk + _DLY_DIG_OUT,
                        CmdMarker(start_mask=1 << entry.channel),
                    )
                )
                digout_cmds.append(
                    (
                        time_clk + entry.duration + _DLY_DIG_OUT,
                        CmdMarker(stop_mask=1 << entry.channel),
                    )
                )
            elif isinstance(entry, DcBiasOut):
                # lower 4 bits are for DigitalOut
                # 24 bits << 4 for DAC raw command
                # bit 24 << 4 for WE
                digout_cmds.append(
                    (
                        time_clk,
                        CmdMarker(
                            start_mask=(entry.raw_command | (1 << 24)) << 4,
                            stop_mask=0x1FF_FFFF << 4,
                        ),
                    )
                )
                # release WE some time later, leave data there
                digout_cmds.append(
                    (
                        time_clk + 6,
                        CmdMarker(stop_mask=0x100_0000 << 4),
                    )
                )
            elif isinstance(entry, NextFreq):
                out_cmds[entry.channel][entry.group].append(
                    (time_clk, CmdOutput(next_freq=True, reset=True)),
                )
            elif isinstance(entry, NextScale):
                out_cmds[entry.channel][entry.group].append(
                    (time_clk, CmdOutput(next_scale=True)),
                )
            elif isinstance(entry, ResetPhase):
                out_cmds[entry.channel][entry.group].append(
                    (time_clk, CmdOutput(reset=True)),
                )
            elif isinstance(entry, SelFreq):
                out_cmds[entry.channel][entry.group].append(
                    (time_clk, CmdOutput(freq_idx=entry.index, reset=True)),
                )
                _lut = self.freq_luts[entry.channel][entry.group]
                _lut_len = 0 if _lut is None else len(_lut)
                if entry.index >= _lut_len:
                    raise RuntimeError(
                        f"trying to select frequency index {entry.index} on port {entry.channel+1} group {entry.group},"
                        f" but programmed frequency LUT has only {_lut_len} entries."
                    )
            elif isinstance(entry, SelScale):
                out_cmds[entry.channel][entry.group].append(
                    (time_clk, CmdOutput(scale_idx=entry.index)),
                )
                _lut = self.scale_luts[entry.channel][entry.group]
                _lut_len = 0 if _lut is None else len(_lut)
                if entry.index >= _lut_len:
                    raise RuntimeError(
                        f"trying to select scale index {entry.index} on port {entry.channel+1} group {entry.group},"
                        f" but programmed scale LUT has only {_lut_len} entries."
                    )
            else:
                raise NotImplementedError

        # list of all commands on all fifos
        # (time_clk, fifo, command)
        all_cmds: List[Tuple[int, int, CmdBase]] = []

        # Sort and merge out_cmds
        for channel in range(self.hardware.nr_ports):
            for group in range(2):
                fifo = channel * 2 + group
                merged = self._merge_seq(fifo, out_cmds[channel][group])
                self._add_dummies(merged, period_clk)
                all_cmds.extend(merged)

        # Sort and merge match_cmds
        for block in range(NR_MATCH_GROUPS):
            fifo = block + _FIFO_MATCH_BASE
            merged = self._merge_seq(fifo, match_cmds[block])
            self._add_dummies(merged, period_clk)
            all_cmds.extend(merged)

        # Sort and merge store_cmds
        fifo = _FIFO_STORE
        merged = self._merge_seq(fifo, store_cmds)
        self._add_dummies(merged, period_clk)
        all_cmds.extend(merged)

        # Sort and merge digout_cmds
        fifo = _FIFO_DIGOUT
        merged = self._merge_seq(fifo, digout_cmds)
        self._add_dummies(merged, period_clk)
        all_cmds.extend(merged)

        # Sort all_cmds
        all_cmds = sorted(all_cmds)

        return all_cmds, nr_matches

    def _merge_seq(
        self, fifo: int, seq: Sequence[Tuple[int, CmdBase]]
    ) -> List[Tuple[int, int, CmdBase]]:
        if len(seq) == 0:
            return []
        seq = sorted(seq)

        merged: List[Tuple[int, int, CmdBase]] = []
        last_time = -1
        last_cmd = type(seq[0][1])()
        for entry in seq:
            trig_time, curr_cmd = entry
            if last_time != trig_time:
                new_cmd: CmdBase = last_cmd.and_then(curr_cmd)
                merged.append((trig_time, fifo, new_cmd))
            else:
                last_cmd.merge(curr_cmd)
            last_time = merged[-1][0]
            last_cmd = merged[-1][2]

        return merged

    def _add_dummies(self, seq: List[Tuple[int, int, CmdBase]], period_clk: int):
        """Assumes sequence is sorted in time, and all on same fifo"""
        if not _ADD_DUMMIES:
            return

        if len(seq) == 0:
            return

        # only accept sequences on a single fifo
        fifo = seq[0][1]

        # add first command at the end for next repetition
        seq.append((seq[0][0] + period_clk, seq[0][1], seq[0][2]))

        i = 1
        while i < len(seq):
            if seq[i][1] != fifo:
                raise NotImplementedError
            time_last = seq[i - 1][0]
            time_next = seq[i][0]
            time_diff = time_next - time_last
            if time_diff > _WRAPPING_TIME:
                nr_periods = (time_diff - 1) // _WRAPPING_TIME
                if nr_periods > _MAX_DUMMY_DELAY:
                    raise NotImplementedError(
                        f"trying to delay by {nr_periods} wrapping periods,"
                        f" but max is {_MAX_DUMMY_DELAY}"
                    )
                time_dummy = time_last + 1
                dummy = (time_dummy % period_clk, fifo, CmdDummy(nr_periods))
                seq.insert(i, dummy)
                i += 1
            i += 1

        # remove last command we added
        seq.pop(-1)

    @no_after_run
    def setup_condition(
        self,
        input_pairs: Union[Match, List[Match]],
        output_templates_true: Optional[
            Union[Template, FlatPulse, List[Union[Template, FlatPulse]]]
        ],
        output_templates_false: Optional[
            Union[Template, FlatPulse, List[Union[Template, FlatPulse]]]
        ] = None,
    ):
        """Setup a template-matching condition for one or more output pulses.

        The pulses in ``output_templates_true`` (``output_templates_false``) will be marked as
        conditional, and will be output if and only if all the template-matching conditions defined
        in ``input_pairs`` are (not) satisfied.

        Args:
            input_pairs (Match or array_like): One or more template-matching pairs as defined by
                :meth:`setup_template_matching_pair`.
            output_templates_true (Template, FlatPulse or array_like): Output in case of a
                successful match comparison. One or more pulses as defined by
                :meth:`setup_template` and/or :meth:`setup_flat_pulse`. Set to :obj:`None` or to an
                empty list ``[]`` if no pulse is desired.
            output_templates_false (Template, FlatPulse or array_like): Output in case of a
                unsuccessful match comparison. One or more pulses as defined by
                :meth:`setup_template` and/or :meth:`setup_flat_pulse`. Set to :obj:`None` or to an
                empty list ``[]`` if no pulse is desired (default).

        See also:
            :meth:`setup_template_matching_pair`
            :meth:`match`
        """
        input_pairs = as_flat_list(input_pairs)

        if output_templates_true is None:
            output_templates_true = []
        if output_templates_false is None:
            output_templates_false = []

        # output_templates will contain both true and false
        output_templates = as_flat_list(output_templates_true)
        for ii, template in enumerate(output_templates):
            if isinstance(template, (Template, FlatPulse)):
                output_templates[ii] = template.get_templates()
            else:
                raise TypeError(f"{template} is not a valid template!")
        output_templates = as_flat_list(output_templates)

        output_templates_false = as_flat_list(output_templates_false)
        for ii, template in enumerate(output_templates_false):
            if isinstance(template, (Template, FlatPulse)):
                output_templates_false[ii] = template.get_templates()  # type: ignore
            else:
                raise TypeError(f"{template} is not a valid template!")
        output_templates_false = as_flat_list(output_templates_false)

        # add false
        output_templates.extend(output_templates_false)

        if self.used_conditioners >= NR_CONDITIONERS:
            raise RuntimeError("No conditioners available")

        conditioner_inputs = 2**64 - 1  # start with all ones (don't look at this comparator)
        comparator_thresholds = list(self.comparator_thresholds)  # make a copy
        comparator_crossport = self.comparator_crossport
        found = 0
        for template in input_pairs:
            if not isinstance(template, Match):
                raise TypeError("Invalid input_pairs: {}", template)

            sub_tmpl = template.get_single()
            if sub_tmpl is None:
                raise NotImplementedError("can't do feedback on long matches")

            if template.cross_group:
                if sub_tmpl.group % 2 != sub_tmpl.index % 2:
                    # only process even(odd) templates for even(odd) ports as they should come in pairs
                    continue
            else:
                if sub_tmpl.index % 2:
                    # only process even templates as they should come in pairs
                    continue
            index = (sub_tmpl.group * MATCH_TMPL_PER_GRP + sub_tmpl.index) // 2
            conditioner_inputs &= ~(1 << index)  # set bit to zero (look at this comparator)
            if template.cross_group:
                comparator_crossport |= 1 << index
            comparator_thresholds[index] = template.threshold
            found += 1
        if not found:
            raise RuntimeError("This should not happen")

        conditioner_outputs = 0  # start with all zeros (don't control this output template)
        conditional = self.conditional
        conditional_false = self.conditional_false
        found = 0
        for template in output_templates:
            if not isinstance(template, RawTemplate):
                raise TypeError("Invalid output_templates: {}", template)

            # Check if we used the template in a conditioner already
            # if so, we check that it's used only as true or only as false
            if template.inverted is None:
                template.inverted = template in output_templates_false
            else:
                if template.inverted != template in output_templates_false:
                    raise NotImplementedError(
                        "This output template was already used in a condition, but with a different polarity (true or"
                        " false). This is not supported. {}",
                        template,
                    )

            index = template.channel * OUT_TMPL_PER_CH + template.index
            conditioner_outputs |= 1 << index  # set bit to one (control this output template)
            conditional += 2**index
            if template in output_templates_false:
                conditional_false += 2**index
            found += 1
        if not found:
            raise ValueError("No template event found in output_templates")

        self.conditioner_inputs[self.used_conditioners] = conditioner_inputs
        self.conditioner_outputs[self.used_conditioners] = conditioner_outputs
        self.conditional = conditional
        self.conditional_false = conditional_false
        self.comparator_crossport = comparator_crossport
        self.comparator_thresholds = list(comparator_thresholds)
        self.used_conditioners += 1

    @no_after_run
    def setup_histogram(self, match: Match):
        """Set up the hardware to calculate a sparse histogram in real time.

        Results from different template-matching objects are binned separately.

        Args:
            match: One template-matching object as obtained from
                :meth:`setup_template_matching_pair`.

        Raises:
            TypeError: if ``match`` is an unrecognized object.
            RuntimeError: if another histogram was already set up.

        See also:
            :meth:`setup_template_matching_pair`
            :meth:`setup_histogram_2d`
            :meth:`get_histogram_data`
        """
        if self._histogram_matches or self._histogram_dim:
            raise RuntimeError("another histogram was already set up")

        if not isinstance(match, Match):
            raise TypeError("{} is not a valid Match event!".format(match))

        sub_tmpl = match.get_single()
        if sub_tmpl is None:
            raise NotImplementedError("can't build histograms with long matches")

        self._histogram_matches.append(sub_tmpl)
        self._histogram_dim = 1

    @no_after_run
    def setup_histogram_2d(self, match_x: Match, match_y: Match):
        """Set up the hardware to calculate a sparse 2D histogram in real time.

        Results from different template-matching objects are binned separately.

        Args:
            match_x: A template-matching object for binning in the x coordinate, as obtained from
                :meth:`setup_template_matching_pair`.
            match_x: A template-matching object for binning in the y coordinate

        Raises:
            RuntimeErrir: if another histogram was already set up.

        See also:
            :meth:`setup_template_matching_pair`
            :meth:`setup_histogram`
            :meth:`get_histogram_data`
        """
        if self._histogram_matches or self._histogram_dim:
            raise RuntimeError("another histogram was already set up")

        for match in (match_x, match_y):
            if not isinstance(match, Match):
                raise TypeError("{} is not a valid Match event!".format(match))
            sub_tmpl = match.get_single()
            if sub_tmpl is None:
                raise NotImplementedError("can't build histograms with long matches")
            self._histogram_matches.append(sub_tmpl)

        self._histogram_dim = 2

    def get_histogram_data(self) -> dict:
        """Obtain from hardware the result of the sparse real-time histogram.

        Only valid after the measurement is performed.

        Returns:
            a dictionary with the following keys defined.

            For a 1D histogram:

            * ``"bins"`` (:class:`~numpy.ndarray`, ``dtype=np.float64``): left-hand edges of the
                histogram bins
            * ``"counts"`` (:class:`~numpy.ndarray`, ``dtype=np.int64``): the values (counts) of the
                histogram

            For a 2D histogram:

            * ``"bins_x"`` (:class:`~numpy.ndarray`, ``dtype=np.float64``): left-hand edges of the
                histogram bins along the x axis
            * ``"bins_y"`` (:class:`~numpy.ndarray`, ``dtype=np.float64``): left-hand edges of the
                histogram bins along the y axis
            * ``"counts"`` (:class:`~numpy.ndarray`, ``dtype=np.int64``): the values (counts) of the
                histogram

        Note:
            histogram bins are not sorted and sparse, i.e. bins with no counts are not returned

        Raises:
            RuntimeError: If no template-matching data is available.
            TypeError: If ``input_pairs`` contains unrecognized objects.

        See also:
            :meth:`setup_histogram`
            :meth:`setup_histogram_2d`
            :meth:`run`


        Examples:

            Get and plot histogram data:

            >>> hist = pls.get_histogram_data()
            >>> import matplotlib.pyplot as plt
            >>> fig, ax = plt.subplots()
            >>> ax.plot(hist["bins"], hist["counts"], '.')
            >>> fig.show()

            Sort histogram data:

            >>> hist = pls.get_histogram_data()
            >>> idx = np.argsort(hist["bins"])
            >>> bins_sorted = hist["bins"][idx]
            >>> counts_sorted = hist["counts"][idx]

        """
        if self._status != MeasurementStatus.DONE:
            raise RuntimeError("No histogram data available. Have you run a measurement?")
        if self._histogram_dim <= 0:
            raise RuntimeError(
                "No histogram data available. Have you run setup_histogram or setup_histogram_2d?"
            )

        ret = {}
        key_scale = (1 << self._histogram_res_b) / _THRESHOLD_SCALE

        t0 = datetime.now()
        if self._print_time:
            print("Downloading histogram data: ...", end="\r", flush=True)

        if self._histogram_dim == 1:
            _histogram_data = self.hardware.get_histogram()
            ret["bins"] = _histogram_data[0, :] * key_scale
            ret["hist"] = _histogram_data[1, :]
        elif self._histogram_dim == 2:
            _histogram_data = self.hardware.get_histogram_2d()
            ret["bins_x"] = _histogram_data[0, :] * key_scale
            ret["bins_y"] = _histogram_data[1, :] * key_scale
            ret["hist"] = _histogram_data[2, :]
        else:
            assert False  # we check that self._histogram_dim > 0 above

        t1 = datetime.now()
        if self._print_time:
            print(f"Downloading histogram data: {format_sec(t1-t0):s}")

        return ret

    def _check(
        self,
        period_clk: int,
        repeat_count: Union[int, tuple],
        num_averages: int,
        print_time: bool,
        verbose: bool,
        prefetch_matches: bool,
    ) -> Tuple[list, int, int]:
        self._status = MeasurementStatus.CHECKING

        t0 = time.time()
        tot_repeats = self._check_repeat_count(repeat_count)
        tot_samples = sum([num for (_, num) in self.saves])
        dma_len_store = tot_samples * tot_repeats * _BYTES_PER_STORE_SAMPLE
        nr_store_ch = len(self.store_channels)

        if period_clk > _MAX_TIME_OCM_CLK:
            raise ValueError(
                f"chosen period {period_clk*self.CLK_T} s is larger"
                f" than maximum supported {_MAX_TIME_OCM_CLK*self.CLK_T} s"
            )

        # Process sequence
        all_cmds, nr_matches = self._process_sequence(period_clk)
        if verbose:
            print(f"\n{' Processed sequence ':-^80}")
            for _cmd in all_cmds:
                print(_cmd)
            print(f"{'':-^80}\n")
            self.all_cmds = all_cmds
        self._check_buffer_overflow(all_cmds, tot_repeats * num_averages, period_clk, verbose)
        self._check_overlapping_stores(all_cmds)
        self._check_dc_bias_rate(all_cmds, period_clk)

        if verbose:
            print(f"dma_len_store: {dma_len_store}")
        if dma_len_store != 0:
            if dma_len_store < _DMA_MIN:
                raise RuntimeError(
                    f"dma_len_store must be at least {_DMA_MIN}, it was {dma_len_store}"
                )
            if dma_len_store % _DMA_MUL != 0:
                raise RuntimeError(
                    f"dma_len_store must be a multiple of {_DMA_MUL}, it was {dma_len_store}"
                )
            if prefetch_matches and nr_matches > 0:
                raise ValueError(
                    "prefetch_matches is not supported when the sequence contains store() events"
                )
            if self._histogram_dim > 0:
                raise RuntimeError(
                    "real-time histograms are not supported when the sequence contains store() events"
                )

        if prefetch_matches and self._histogram_dim > 0:
            raise RuntimeError(
                "real-time histograms are not supported when using prefetch_matches"
            )

        if len(all_cmds) > MAX_COMMANDS:
            raise RuntimeError(
                f"trying to use {len(all_cmds)} commands, maximum is {MAX_COMMANDS}"
            )
        _max_T = all_cmds[-1][0]
        if _max_T > period_clk:
            raise ValueError(
                f"chosen period {period_clk*self.CLK_T} s is smaller"
                f" than duration of sequence {_max_T*self.CLK_T} s"
            )

        dma_len_match = nr_matches * tot_repeats * num_averages * _BYTES_PER_MATCH
        if verbose:
            print(f"dma_len_match: {dma_len_match}")
        if dma_len_match != 0:
            if dma_len_match < _DMA_MIN:
                raise RuntimeError(
                    f"Not enough match events: there must be at least {_DMA_MIN//_BYTES_PER_MATCH},"
                    f" there were {dma_len_match//_BYTES_PER_MATCH}. Consider adding match"
                    " events, or increasing repeat_count or num_averages."
                )
            if dma_len_match % _DMA_MUL != 0:
                raise RuntimeError(
                    f"dma_len_match must be a multiple of {_DMA_MUL}, it was {dma_len_match}"
                )

        # we align the dma for matches at multiples of 4096 bytes
        total_dma_length = dma_len_store + (dma_len_match + 4095) // 4096 * 4096
        if verbose:
            print(f"total_dma_length: {total_dma_length}")
        if total_dma_length > _DMA_MAX:
            raise RuntimeError(
                f"requesting too much data: the max total memory size is {_DMA_MAX} bytes,"
                f"requesting {total_dma_length}. Consider removing some store or match event,"
                " or decreasing repeat_count or num_averages."
            )

        # check number of commands on each FIFO
        _nr_commands = np.zeros(_NR_FIFOS, np.int64)
        for _, fifo, _ in all_cmds:
            # WARN: what was this about?
            # if fifo >= _NR_FIFOS:
            #     fifo = fifo - _NR_FIFOS
            _nr_commands[fifo] += 1
        _max_commands = np.max(_nr_commands)
        _argmax_commands = np.argmax(_nr_commands)
        _avg_fifo_load = _max_commands * _WRAPPING_TIME / period_clk
        if verbose:
            print(f"max commands on FIFO {_argmax_commands}: {_max_commands}")
            print(f"avg_fifo_load: {_avg_fifo_load}")
            print(f"nr commands on OCM: {np.sum(_nr_commands):d}")
        _argmax_commands = np.argmax(_nr_commands)
        if verbose:
            print(f"max commands on FIFO {_argmax_commands}: {_max_commands}")
        # TODO: some sort of check if the RPU and the FIFOs can keep up with the commands

        # check that scale and frequency LUTs have been programmed
        for channel in range(self.hardware.nr_ports):
            for group in range(2):
                if self.templates[channel][group * OUT_TMPL_PER_GRP] is not None:
                    if self.scale_luts[channel][group] is None:
                        raise RuntimeError(
                            f"an output template was programmed for port {channel+1} group {group}, but"
                            " the corresponding scale LUT was not set up. Have you called "
                            "setup_scale_lut?"
                        )
                if (self.modulate[channel] >> (group * OUT_TMPL_PER_GRP)) & (
                    2**OUT_TMPL_PER_GRP - 1
                ) > 0:
                    if self.freq_luts[channel][group] is None:
                        raise RuntimeError(
                            f"an output envelope was programmed for port {channel+1} group {group}, but"
                            " the corresponding frequency/phase LUT was not set up. Have you called "
                            "setup_freq_lut?"
                        )

        exp_runtime_clk = period_clk * tot_repeats * num_averages  # clk cycles
        if print_time or verbose:
            t1 = time.time()
            print(f"Measurement sequence processed in {format_sec(t1-t0):s}")
            print(f"Expected measurement time: {format_sec(exp_runtime_clk*self.CLK_T):s}")

        self._tot_repeats = tot_repeats
        self._num_averages = num_averages
        self._dma_len_store = dma_len_store
        self._dma_len_match = dma_len_match
        self._nr_matches = nr_matches
        self._print_time = print_time

        return (
            all_cmds,
            nr_store_ch,
            exp_runtime_clk,
        )

    def _setup(
        self,
        period_clk: int,
        all_cmds: list,
        nr_store_ch: int,
    ):
        self._status = MeasurementStatus.UPLOADING

        if self.dry_run:
            raise RuntimeError("can't call _setup when dry_run=True")

        if self.hardware.dac_autoconfig:
            t0 = time.time()
            if self._print_time:
                print("Configuring ADCs and DACs: ...", end="\r", flush=True)
            # set user-requested configuration for the data converters
            self.hardware.setup_config(do_sync=False)  # sync in _run() when we start the sequence
            self.hardware.assert_errors()
            self.hardware.intr_clr()
            _ = self.hardware.get_intr_status()  # the first after MTS is polluted
            self.hardware.check_adc_intr_status()
            if self._print_time:
                t1 = time.time()
                print(f"Configuring ADCs and DACs: {format_sec(t1-t0):s}")

        t0 = time.time()
        if self._print_time:
            print("Uploading measurement parameters: ...", end="\r", flush=True)
        # Reset
        self.hardware.set_run(False)

        # upload scale LUT
        for channel in range(self.hardware.nr_ports):
            for index in range(2):
                scale_lut = self.scale_luts[channel][index]
                max_loop_count = self._scale_loop_count[channel][index] - 1
                if scale_lut is not None:
                    self.hardware._send_command(
                        cmd.Msg__PlsScale(
                            (
                                channel,
                                index,
                                scale_lut,  # pyright: ignore[reportArgumentType]
                                max_loop_count,
                            )
                        )
                    )

        # upload frequency and phase LUT
        for channel in range(self.hardware.nr_ports):
            for index in range(2):
                freq_lut = self.freq_luts[channel][index]
                phase_i_lut = self.phase_i_luts[channel][index]
                phase_q_lut = self.phase_q_luts[channel][index]
                max_loop_count = self._freq_loop_count[channel][index] - 1
                if freq_lut is not None:
                    self.hardware._send_command(
                        cmd.Msg__PlsFreqLut(
                            (
                                channel,
                                index,
                                freq_lut,  # pyright: ignore[reportArgumentType]
                                max_loop_count,
                            )
                        )
                    )
                if phase_i_lut is not None:
                    assert phase_q_lut is not None
                    self.hardware._send_command(
                        cmd.Msg__PlsPhaseLutIQ(
                            (
                                channel,
                                index,
                                phase_i_lut,
                                phase_q_lut,
                            )  # pyright: ignore[reportArgumentType]
                        )
                    )

        # upload output templates
        for channel in range(self.hardware.nr_ports):
            for index in range(OUT_TMPL_PER_CH):
                entry = self.templates[channel][index]
                if entry is not None:
                    # _, real_idx, template = entry
                    self.hardware._send_command(
                        cmd.Msg__PlsOutTmpl(
                            (
                                channel,
                                index,
                                entry,  # pyright: ignore[reportArgumentType]
                            )
                        )
                    )

        # set match multiplexer
        match_mux = 0
        for i, mux in enumerate(self._match_mux):
            if mux is None:
                continue
            assert mux < 16
            match_mux |= mux << (i * 4)
        self.hardware._send_command(cmd.Msg__PlsMatchMux(match_mux))

        # upload match templates
        for group in range(NR_MATCH_GROUPS):
            for index in range(MATCH_TMPL_PER_GRP):
                template = self.match_templates[group][index]
                if template is not None:
                    self.hardware._send_command(
                        cmd.Msg__PlsMatchTmpl(
                            (
                                group,
                                index,
                                template,  # pyright: ignore[reportArgumentType]
                            )
                        )
                    )

        # upload modulation
        for channel in range(self.hardware.nr_ports):
            self.hardware._send_command(cmd.Msg__PlsEnvelope((channel, self.modulate[channel])))

        # conditional templates
        self.hardware._send_command(
            cmd.Msg__PlsFbDefaultMask(
                (
                    (self.conditional >> 0) & (2**64 - 1),
                    (self.conditional >> 64) & (2**64 - 1),
                    (self.conditional >> 128) & (2**64 - 1),
                    (self.conditional >> 192) & (2**64 - 1),
                )
            )
        )
        self.hardware._send_command(
            cmd.Msg__PlsFbInvertCondition(
                (
                    (self.conditional_false >> 0) & (2**64 - 1),
                    (self.conditional_false >> 64) & (2**64 - 1),
                    (self.conditional_false >> 128) & (2**64 - 1),
                    (self.conditional_false >> 192) & (2**64 - 1),
                )
            )
        )

        # comparators
        self.hardware._send_command(cmd.Msg__PlsFbCompareIQ(self.comparator_crossport))
        self.hardware._send_command(cmd.Msg__PlsFbCompareConstant(self.comparator_thresholds))  # pyright: ignore[reportArgumentType]

        # conditioners
        self.hardware._send_command(cmd.Msg__PlsFbConditionMask(self.conditioner_inputs))  # pyright: ignore[reportArgumentType]
        _regs = [0] * (4 * NR_CONDITIONERS)
        for ii in range(NR_CONDITIONERS):
            _regs[4 * ii + 0] = (self.conditioner_outputs[ii] >> 0) & (2**64 - 1)
            _regs[4 * ii + 1] = (self.conditioner_outputs[ii] >> 64) & (2**64 - 1)
            _regs[4 * ii + 2] = (self.conditioner_outputs[ii] >> 128) & (2**64 - 1)
            _regs[4 * ii + 3] = (self.conditioner_outputs[ii] >> 192) & (2**64 - 1)
        self.hardware._send_command(cmd.Msg__PlsFbUserMask(_regs))  # pyright: ignore[reportArgumentType]

        # upload commands
        for time_clk, fifo, command in all_cmds:
            self.hardware._send_command(cmd.Msg__PlsSeqCmd((time_clk, fifo, command.serialize())))

        # Start DMAs
        if self._dma_len_store > 0:
            self.hardware.start_dma(
                7, self._dma_len_store, nr_cycles=self._num_averages
            )  # dma_to_pl
            self.hardware.start_dma(
                3, self._dma_len_store, nr_cycles=self._num_averages
            )  # dma_to_ps
        if self._nr_matches > 0:
            self.hardware.start_dma(
                2, self._dma_len_match, nr_cycles=1, high_mem=True
            )  # dma_to_ps
        self.hardware._send_command(cmd.Msg__PlsStoreMode(nr_store_ch))
        self.hardware.sleep(1e-3, wait=False)

        # Run measurement
        self.hardware._send_command(
            cmd.Msg__PlsNIter((self._num_averages * self._tot_repeats, period_clk))
        )
        self.hardware.assert_errors()

        if self._print_time:
            t1 = time.time()
            print(f"Uploading measurement parameters: {format_sec(t1-t0):s}")

    def _run(
        self,
        trigger: TriggerSource,
        exp_runtime_clk: int,
        prefetch_matches: bool,
    ):
        self._status = MeasurementStatus.RUNNING

        # reset cached results
        self._reply_matches = None
        self._match_data = None
        self._match_tags = None

        if self.dry_run:
            raise RuntimeError("can't call _run when dry_run=True")

        self._time_start = datetime.now()
        exp_runtime = timedelta(seconds=exp_runtime_clk * self.CLK_T)
        self._time_end = self._time_start + exp_runtime

        if trigger is TriggerSource.Internal:
            # instead of using internal, we use SYSREF and manually issue a sync event
            # this way NCOs and sequence start at the same time
            self.hardware.set_run(True, trigger=TriggerSource.Sysref)
            self.hardware.sync()
        elif trigger is TriggerSource.Sysref:
            # just arm the sequence without starting NCOs
            # NCOs will start when the SYSREF pulse comes
            self.hardware.set_run(True, trigger=trigger)
        else:
            # DigitalIn[1-4]
            # start the NCOs manually, then arm the sequence
            self.hardware.sync()
            self.hardware.set_run(True, trigger=trigger)

        if self._nr_matches > 0 and prefetch_matches:
            join_matches, self._reply_matches = self.hardware.stream_dma_data(
                dma_idx=2,
                nr_bytes=self._dma_len_match,
                high_mem=True,
            )

        if self._histogram_dim == 1:
            self.hardware.start_histogram(
                dma_idx=2,
                nr_bytes=self._dma_len_match,
                high_mem=True,
                res_b=self._histogram_res_b,
                tag=self._histogram_matches[0].tag(),
            )
        elif self._histogram_dim == 2:
            self.hardware.start_histogram_2d(
                dma_idx=2,
                nr_bytes=self._dma_len_match,
                high_mem=True,
                res_b=self._histogram_res_b,
                tag1=self._histogram_matches[0].tag(),
                tag2=self._histogram_matches[1].tag(),
            )

        prev_print_len = 0
        t_last = _T_ZERO
        ocm_done = False
        dma_done_avg = self._dma_len_store == 0
        dma_done_match = self._nr_matches == 0
        dma_done = dma_done_avg and dma_done_match
        dma_err_avg = False
        dma_err_match = False
        while (not ocm_done) and (self._status is not MeasurementStatus.ABORTED):
            t_now = datetime.now()

            if self._dma_len_store > 0:
                (dma_done_avg, dma_err_avg, _) = self.hardware.get_dma_status(3)
            if self._nr_matches > 0:
                (dma_done_match, dma_err_match, _) = self.hardware.get_dma_status(2)
            dma_done = dma_done_avg and dma_done_match

            # check using ocm_done from previous loop to give DMA time to transfer
            if ocm_done and (not dma_done):
                eprint_error(
                    "WARNING",
                    "OCM terminated but data transfer is still incomplete",
                    warn=True,
                    inline=True,
                )
            (ocm_done, ocm_err) = self.hardware.get_ocm_status()

            any_error = (ocm_err > 0) or dma_err_avg or dma_err_match
            if any_error:
                msg = []
                msg.append(f"Time since start: {format_sec(t_now - self._time_start)}")
                msg.append(f"Time remaining:   {format_sec(self._time_end - t_now)}")
                msg.append("")
                msg.append(
                    "There was an internal error in the data transfer, data is likely corrupt."
                )
                msg.append(
                    "Aborting measurement, please wait. We'll collect the data measured so far and return."
                )
                msg.append("")
                msg.append("Details:")
                msg.append(f"  dma_err_avg = {dma_err_avg}")
                msg.append(f"  dma_err_match = {dma_err_match}")
                msg.append(f"  ocm_err = {ocm_err}")
                msg = "\n".join(msg)
                print()
                eprint_error("internal error", msg)
                break

            if self._print_time and (t_now - t_last).total_seconds() > 1.0:
                t_last = t_now
                msg = "Time left: {:s}".format(format_sec(self._time_end - t_now))
                print_len = len(msg)
                if print_len < prev_print_len:
                    msg += " " * (prev_print_len - print_len)
                print("\r" + msg, end="\r", flush=True)
                prev_print_len = print_len

            time.sleep(0.1)

        if self._status is MeasurementStatus.ABORTED:
            # closing the socket should let conductor abort
            self.close()
            # then raise exception
            raise RuntimeError("measurement aborted by the user")

        self._time_end = datetime.now()
        if self._print_time:
            print(f"Measurement completed in: {format_sec(self._time_end-self._time_start):s}")
            print("Finishing internal data transfers: ...", end="\r", flush=True)

        self._status = MeasurementStatus.DOWNLOADING
        # make sure DMA transfers are actually done
        self.hardware.sleep(0.1)

        # wait for prefetching data to finish
        if self._nr_matches > 0 and prefetch_matches:
            join_matches.join()  # type:ignore : we create it before the sequence starts

        (_, _, nr_bytes_avg) = self.hardware.get_dma_status(
            3
        )  # previous nr_bytes might not be final
        (_, _, nr_bytes_match) = self.hardware.get_dma_status(
            2
        )  # previous nr_bytes might not be final
        if self._nr_matches > 0:
            self.hardware.stop_dma(2)
        if self._dma_len_store > 0:
            self.hardware.stop_dma(7)
            self.hardware.stop_dma(3)
        self.hardware.set_run(False)

        if self._print_time:
            t2 = datetime.now()
            print(f"Finishing internal data transfers: {format_sec(t2-self._time_end):s}")

        self._status = MeasurementStatus.DONE

        # Check for errors
        self.hardware.assert_errors()
        (ocm_done, ocm_err) = self.hardware.get_ocm_status()
        self.hardware.check_adc_intr_status()

        # Print errors
        if self._dma_len_store > 0:
            if nr_bytes_avg != self._dma_len_store * self._num_averages:
                eprint_error(
                    "ERROR",
                    f"expected {self._dma_len_store * self._num_averages} DMA transfers (store), got {nr_bytes_avg}",
                    inline=True,
                )
        if self._nr_matches > 0:
            if nr_bytes_match != self._dma_len_match:
                eprint_error(
                    "ERROR",
                    f"expected {self._dma_len_match} DMA transfers (match), got {nr_bytes_match}",
                    inline=True,
                )
        if not ocm_done:
            eprint_error("ERROR", "OCM did not terminate", inline=True)
        if ocm_err > 0:
            eprint_error("ERROR", f"OCM encountered an error: {ocm_err:d}", inline=True)

    def perform_measurement(self, *args, **kwargs):
        """
        .. deprecated:: 2.0.0
            Use :meth:`run` instead.
        """
        warnings.warn(
            message="perform_measurement is deprecated since version 2.0.0, use run instead.",
            category=DeprecationWarning,
            stacklevel=2,
        )
        return self.run(*args, **kwargs)

    def run_async(
        self,
        period: float,
        repeat_count: Union[int, tuple],
        num_averages: int,
        print_time: bool = False,
        verbose: bool = False,
        trigger: TriggerSource = TriggerSource.Internal,
        prefetch_matches: bool = False,
    ) -> MeasurementHandle:
        """Same as :meth:`run`, but non blocking. See ``run`` for full documentation."""
        self._status.check_runnable()

        period = float(period)
        num_averages = int(num_averages)
        period_clk = self.time_to_clk(period)

        try:
            (
                all_cmds,
                nr_store_ch,
                exp_runtime_clk,
            ) = self._check(
                period_clk,
                repeat_count,
                num_averages,
                print_time,
                verbose,
                prefetch_matches,
            )

            if not self.dry_run:
                self._setup(
                    period_clk,
                    all_cmds,
                    nr_store_ch,
                )

                self.thread = threading.Thread(
                    target=self._run,
                    args=(
                        trigger,
                        exp_runtime_clk,
                        prefetch_matches,
                    ),
                )
                self.thread.start()
            else:
                self._status = MeasurementStatus.DONE

            handle = MeasurementHandle(weakref.ref(self))
            return handle
        except (Exception, KeyboardInterrupt):
            self._status = MeasurementStatus.ABORTED
            raise

    def join(self):
        if self.thread is not None:
            self.thread.join()

    def _check_repeat_count(self, repeat_count: Union[int, Tuple]) -> int:
        if isinstance(repeat_count, int):
            tot_repeats = repeat_count

            if not repeat_count > 0:
                raise ValueError(f"repeat_count must be positve, got {repeat_count}")

            for j, (axis, count) in enumerate(zip(self._scale_axis, self._scale_loop_count)):
                for i in range(2):  # two groups
                    if axis[i] not in [0, -1]:
                        raise RuntimeError(
                            f"axis on scale LUT port {j+1} group {i} is {axis[i]}, "
                            "but repeat_count is an int (no multi-dimensional parameter sweep)"
                        )
                    count[i] = 1
            for j, (axis, count) in enumerate(zip(self._freq_axis, self._freq_loop_count)):
                for i in range(2):  # two groups
                    if axis[i] not in [0, -1]:
                        raise RuntimeError(
                            f"axis on frequency LUT port {j+1} group {i} is {axis[i]}, "
                            "but repeat_count is an int (no multi-dimensional parameter sweep)"
                        )
                    count[i] = 1

        elif isinstance(repeat_count, tuple):
            len_rc = len(repeat_count)
            if len_rc == 0:
                raise ValueError("repeat_count can't be an empty tuple")

            tot_repeats = 1
            for i, d in enumerate(repeat_count):
                if not isinstance(d, int):
                    raise TypeError(
                        f"repeat_count can be an int or a tuple(int), got type tuple({type(d)})"
                    )
                if not d > 0:
                    raise ValueError(f"dimensions must be positve, got {d}")
                tot_repeats *= d

            counts = [1]
            for rc in reversed(repeat_count[1:]):
                counts.append(rc * counts[-1])
            counts.reverse()

            for j, (axis, count) in enumerate(zip(self._scale_axis, self._scale_loop_count)):
                for i in range(2):  # two groups
                    try:
                        count[i] = counts[axis[i]]
                    except IndexError:
                        raise ValueError(
                            f"axis for scale LUT out of range, got {axis[i]} but repeat_count"
                            f" only has {len(repeat_count)} dimensions"
                        )
            for j, (axis, count) in enumerate(zip(self._freq_axis, self._freq_loop_count)):
                for i in range(2):  # two groups
                    try:
                        count[i] = counts[axis[i]]
                    except IndexError:
                        raise ValueError(
                            f"axis for frequency LUT out of range, got {axis[i]} but repeat_count"
                            f" only has {len(repeat_count)} dimensions"
                        )

        else:
            raise TypeError(
                f"repeat_count can be an int or a tuple(int), got type {type(repeat_count)}"
            )
        return tot_repeats

    def run(
        self,
        period: float,
        repeat_count: Union[int, tuple],
        num_averages: int,
        print_time: bool = True,
        verbose: bool = False,
        trigger: TriggerSource = TriggerSource.Internal,
        prefetch_matches: bool = False,
    ):
        """Execute the experiment planned so far. Can be time consuming!

        This method will block until the measurement and the data transfer are completed. See
        :meth:`run_async` for a non-blocking alternative.

        Args:
            period: Measurement time in seconds for one repetition. Should be long enough to
                include the last event programmed. If longer, there will be some waiting time
                between repetitions. Must be a multiple of :meth:`get_clk_T`
            repeat_count (int or tuple of ints): Number of times to repeat the experiment and stack
                the acquired data (no averaging). For multi-dimensional parameter sweeps,
                ``repeat_count`` is a tuple where each element specifies the number of repetitions
                along that axis. Multi-dimensional parameter sweeps are *experimental* and the API
                might be fine tuned in a future release.
            num_averages: Number of times to repeat the whole sequence (including the repetitions
                due to ``repeat_count``) and average the acquired data.
            print_time: If :obj:`True`, print to :obj:`standard output <sys.stdout>` the expected
                runtime before the experiment, the total runtime after the experiment, and print
                during the experiment the estimated time left at regular intervals.
            verbose: If :obj:`True`, print debugging information.
            trigger: Select trigger source to start measurement, default internal trigger (start
                immediately).
            prefetch_matches: if :obj:`True`, download template-matching results from the hardware
                as they become available; if :obj:`False` (default), download results only at the
                end of the experiment.

        Raises:
            ValueError: if ``period`` is negative, too small to fit the last event, or not a
                multiple of :meth:`get_clk_T`;
                if ``repeat_count`` is not positive;
                if ``num_averages`` is not positive.
            RuntimeError: if the sequence requires more triggers than :const:`MAX_COMMANDS`;
                if more than 8 templates/envelopes are used for the same group on the same port.

        See also:
            :meth:`get_store_data`
            :meth:`get_template_matching_data`

        """
        self._status.check_runnable()

        period = float(period)
        num_averages = int(num_averages)
        period_clk = self.time_to_clk(period)

        try:
            t0 = time.time()
            (
                all_cmds,
                nr_store_ch,
                exp_runtime_clk,
            ) = self._check(
                period_clk,
                repeat_count,
                num_averages,
                print_time,
                verbose,
                prefetch_matches,
            )

            if not self.dry_run:
                self._setup(
                    period_clk,
                    all_cmds,
                    nr_store_ch,
                )

                self._run(
                    trigger,
                    exp_runtime_clk,
                    prefetch_matches,
                )

            else:
                self._status = MeasurementStatus.DONE

            if print_time:
                t1 = time.time()
                print(f"Total time: {format_sec(t1-t0)}")
        except (Exception, KeyboardInterrupt):
            self._status = MeasurementStatus.ABORTED
            raise

    def _check_buffer_overflow(
        self, all_cmds: list, nr_repetitions: int, period_clk: int, verbose: bool
    ):
        store_times = np.array(
            [
                time_clk
                for (time_clk, fifo, cmd_store) in all_cmds
                if fifo == _FIFO_STORE
                and not isinstance(cmd_store, CmdDummy)
                and cmd_store.store_mask != 0
            ]
        )
        if len(store_times) > 0:
            nr_store_ch = len(self.store_channels)
            fill_rate = SMPLS_PER_CLK * nr_store_ch  # S/clk_cyc
            drain_rate = AVERAGING_RATE * self.CLK_T  # S/clk_cyc
            if fill_rate < drain_rate:
                # we empty the store buffer faster than we fill it, with margin,
                # so we can run arbitrarily long stores (until we fill the RAM)
                return

            # for simplicity, assume a store instantly fills the buffer
            new_store = self.store_len * nr_store_ch

            buf_lvl = 0
            prev_time = 0
            max_fill = 0
            for time_clk in store_times:
                buf_lvl = max(0, int(np.ceil(buf_lvl - (time_clk - prev_time) * drain_rate)))
                buf_lvl += new_store
                max_fill = max(max_fill, buf_lvl)
                prev_time = time_clk
            residual = max(
                0, int(np.ceil(buf_lvl - (period_clk - prev_time + store_times[0]) * drain_rate))
            )
            max_ever = max_fill + residual * (nr_repetitions - 1)
            if verbose:
                print(f"single rep max store-buffer usage: {max_fill / 1e6} MS")
                print(f"max store-buffer usage: {max_ever / 1e6} MS")
            if max_ever > MAX_STORE_LEN:
                raise RuntimeError(
                    "exceeding maximum store rate. Consider decreasing the store duration or"
                    " increasing the time between different store events."
                )

    def _check_overlapping_stores(self, all_cmds: list):
        in_store = False
        start_time = -1
        for at_time, fifo, cmd_store in all_cmds:
            if fifo != _FIFO_STORE or isinstance(cmd_store, CmdDummy):
                continue
            if cmd_store.store_mask != 0:
                if in_store:
                    # starting a new store while still in a store
                    raise RuntimeError(
                        f"store starting at time {round(at_time*self.CLK_T,12)}s overlaps with"
                        f" previous store started at time {round(start_time*self.CLK_T,12)}s"
                    )
                else:
                    in_store = True
                    start_time = at_time
            else:
                if not in_store:
                    # stopping a store, but no store was started
                    raise RuntimeError(
                        f"stopping store at time {round(at_time*self.CLK_T,12)}s,"
                        " but no store was started"
                    )
                else:
                    in_store = False

    def _check_dc_bias_rate(self, all_cmds: list, period_clk: int):
        min_time = math.ceil(1e-6 * self.CLK_F) * self.CLK_T
        first_time = None
        last_time = None
        last_word = -1
        in_cmd = False
        for at_time, fifo, marker_cmd in all_cmds:
            if fifo != _FIFO_DIGOUT or isinstance(marker_cmd, CmdDummy):
                continue
            data = marker_cmd.marker_mask
            we = (data >> (24 + 4)) & 1 == 1
            word = (data >> 4) & 0xFF_FFFF
            if in_cmd:
                if we:
                    if word != last_word:
                        raise RuntimeError(
                            "inconsistent sequence of DC-biasing commands."
                            " Make sure commands are spaced by at least 1 μs."
                        )
                else:
                    in_cmd = False
            else:
                if we:
                    if last_time is not None:
                        if at_time - last_time < min_time:
                            raise RuntimeError(
                                "exceeding maximum rate for DC-biasing commands."
                                " Make sure commands are spaced by at least 1 μs."
                            )
                    else:
                        first_time = at_time
                    last_time = at_time
                    last_word = word
                    in_cmd = True
                else:
                    pass

        if last_time is not None and first_time is not None:
            min_period = last_time - first_time + min_time
            if period_clk < min_period:
                raise RuntimeError(
                    "exceeding maximum rate for DC-biasing commands:"
                    " Make sure commands are spaced by at least 1 μs by increasing the period to"
                    f" at least {round(min_period*self.CLK_T,12)} seconds."
                )


def _unwrap_or(x, default):
    return default if x is None else x


@functools.total_ordering
class CmdBase:
    def __repr__(self) -> str:
        return f"{type(self).__name__}{self.__dict__}"

    def _as_tuple(self) -> Tuple:
        raise NotImplementedError

    def __eq__(self, other: object) -> bool:
        raise NotImplementedError

    def __lt__(self, other: object) -> bool:
        raise NotImplementedError

    def merge(self, other):
        raise NotImplementedError

    def and_then(self, other):
        raise NotImplementedError

    def serialize(self) -> cmd.SeqCmd:
        raise NotImplementedError


@functools.total_ordering
class CmdDummy(CmdBase):
    def __init__(self, nr_periods: int):
        self.nr_periods = nr_periods

    def __repr__(self) -> str:
        return f"{type(self).__name__}{self.__dict__}"

    def _as_tuple(self) -> Tuple:
        return (self.nr_periods,)

    def serialize(self) -> cmd.SeqCmd__Dummy:
        return cmd.SeqCmd__Dummy(
            nr_periods=self.nr_periods,  # pyright: ignore[reportArgumentType]
        )


@functools.total_ordering
class CmdOutput(CmdBase):
    def __init__(
        self,
        *,
        start_mask: Optional[int] = None,
        stop_mask: Optional[int] = None,
        scale_idx: Optional[int] = None,
        freq_idx: Optional[int] = None,
        next_scale: bool = False,
        next_freq: bool = False,
        reset: bool = False,
    ):
        if next_scale and scale_idx is not None:
            raise ValueError("can't use next and select scale at the same time")
        if next_freq and freq_idx is not None:
            raise ValueError("can't use next and select freq/phase at the same time")

        self.trig_mask: int = 0

        self.scale_idx = scale_idx
        self.freq_idx = freq_idx
        self.next_scale = next_scale
        self.next_freq = next_freq
        self.reset = reset
        self.start_mask = start_mask
        self.stop_mask = stop_mask

    def serialize(self) -> cmd.SeqCmd__Output:
        return cmd.SeqCmd__Output(
            trig_mask=self.trig_mask,  # pyright: ignore[reportArgumentType]
            scale_idx=self.scale_idx,  # pyright: ignore[reportArgumentType]
            freq_idx=self.freq_idx,  # pyright: ignore[reportArgumentType]
            next_scale=self.next_scale,
            next_freq=self.next_freq,
            reset=self.reset,
        )

    def __eq__(self, other: object) -> bool:
        if isinstance(other, CmdOutput):
            return self.__dict__ == other.__dict__
        elif isinstance(other, CmdBase):
            return False
        else:
            raise TypeError

    def __lt__(self, other: object) -> bool:
        if isinstance(other, CmdBase):
            return self._as_tuple() < other._as_tuple()
        else:
            raise TypeError

    def _as_tuple(self):
        return (
            self.trig_mask,
            _unwrap_or(self.scale_idx, -1),
            _unwrap_or(self.freq_idx, -1),
            self.next_scale,
            self.next_freq,
            self.reset,
            _unwrap_or(self.start_mask, -1),
            _unwrap_or(self.stop_mask, -1),
        )

    def copy(self) -> CmdOutput:
        return copy.copy(self)

    def merge(self, other: CmdOutput):
        if not isinstance(other, CmdOutput):
            raise TypeError

        if other.stop_mask is not None:
            self.trig_mask &= ~other.stop_mask
        if other.start_mask is not None:
            self.trig_mask |= other.start_mask

        if self.scale_idx is None:
            self.scale_idx = other.scale_idx
        elif other.scale_idx is not None:
            if self.scale_idx != other.scale_idx:
                raise ValueError("can't set two different scale indexes at the same time")

        if self.freq_idx is None:
            self.freq_idx = other.freq_idx
        elif other.freq_idx is not None:
            if self.freq_idx != other.freq_idx:
                raise ValueError("can't set two different freq/phase indexes at the same time")

        self.next_scale = self.next_scale or other.next_scale
        self.next_freq = self.next_freq or other.next_freq
        self.reset = self.reset or other.reset

        if self.next_scale and self.scale_idx is not None:
            raise ValueError("can't use next and select scale at the same time")
        if self.next_freq and self.freq_idx is not None:
            raise ValueError("can't use next and select freq/phase at the same time")

    def and_then(self, other: CmdOutput) -> CmdOutput:
        if not isinstance(other, CmdOutput):
            raise TypeError

        new = self.copy()

        if other.stop_mask is not None:
            new.trig_mask &= ~other.stop_mask
        if other.start_mask is not None:
            new.trig_mask |= other.start_mask

        new.scale_idx = other.scale_idx
        new.freq_idx = other.freq_idx

        new.next_scale = other.next_scale
        new.next_freq = other.next_freq
        new.reset = other.reset

        return new


@functools.total_ordering
class CmdMatch(CmdBase):
    def __init__(
        self,
        *,
        start_mask: Optional[int] = None,
        stop_mask: Optional[int] = None,
    ):
        self.match_mask: int = 0

        self.start_mask = start_mask
        self.stop_mask = stop_mask

    def serialize(self) -> cmd.SeqCmd__Match:
        return cmd.SeqCmd__Match(
            match_mask=self.match_mask,  # pyright: ignore[reportArgumentType]
        )

    def __eq__(self, other: object) -> bool:
        if isinstance(other, CmdMatch):
            return self.__dict__ == other.__dict__
        elif isinstance(other, CmdBase):
            return False
        else:
            raise TypeError

    def __lt__(self, other: object) -> bool:
        if isinstance(other, CmdBase):
            return self._as_tuple() < other._as_tuple()
        else:
            raise TypeError

    def _as_tuple(self):
        return (
            self.match_mask,
            _unwrap_or(self.start_mask, -1),
            _unwrap_or(self.stop_mask, -1),
        )

    def copy(self) -> CmdMatch:
        return copy.copy(self)

    def merge(self, other: CmdMatch):
        if not isinstance(other, CmdMatch):
            raise TypeError

        if other.stop_mask is not None:
            self.match_mask &= ~other.stop_mask
        if other.start_mask is not None:
            self.match_mask |= other.start_mask

    def and_then(self, other: CmdMatch) -> CmdMatch:
        if not isinstance(other, CmdMatch):
            raise TypeError

        new = self.copy()

        if other.stop_mask is not None:
            new.match_mask &= ~other.stop_mask
        if other.start_mask is not None:
            new.match_mask |= other.start_mask

        return new


@functools.total_ordering
class CmdMarker(CmdBase):
    def __init__(
        self,
        *,
        start_mask: Optional[int] = None,
        stop_mask: Optional[int] = None,
    ):
        self.marker_mask: int = 0

        self.start_mask = start_mask
        self.stop_mask = stop_mask

    def serialize(self) -> cmd.SeqCmd__Marker:
        return cmd.SeqCmd__Marker(
            marker_word=self.marker_mask,  # pyright: ignore[reportArgumentType]
        )

    def __eq__(self, other: object) -> bool:
        if isinstance(other, CmdMarker):
            return self.__dict__ == other.__dict__
        elif isinstance(other, CmdBase):
            return False
        else:
            raise TypeError

    def __lt__(self, other: object) -> bool:
        if isinstance(other, CmdBase):
            return self._as_tuple() < other._as_tuple()
        else:
            raise TypeError

    def _as_tuple(self):
        return (
            self.marker_mask,
            _unwrap_or(self.start_mask, -1),
            _unwrap_or(self.stop_mask, -1),
        )

    def copy(self) -> CmdMarker:
        return copy.copy(self)

    def merge(self, other: CmdMarker):
        if not isinstance(other, CmdMarker):
            raise TypeError

        if other.stop_mask is not None:
            self.marker_mask &= ~other.stop_mask
        if other.start_mask is not None:
            self.marker_mask |= other.start_mask

    def and_then(self, other: CmdMarker) -> CmdMarker:
        if not isinstance(other, CmdMarker):
            raise TypeError

        new = self.copy()

        if other.stop_mask is not None:
            new.marker_mask &= ~other.stop_mask
        if other.start_mask is not None:
            new.marker_mask |= other.start_mask

        return new


@functools.total_ordering
class CmdStore(CmdBase):
    def __init__(
        self,
        *,
        store_mask: int = 0,
    ):
        self.store_mask = store_mask

    def serialize(self) -> cmd.SeqCmd__Store:
        return cmd.SeqCmd__Store(
            store_mask=self.store_mask,  # pyright: ignore[reportArgumentType]
        )

    def __eq__(self, other: object) -> bool:
        if isinstance(other, CmdStore):
            return self.__dict__ == other.__dict__
        elif isinstance(other, CmdBase):
            return False
        else:
            raise TypeError

    def __lt__(self, other: object) -> bool:
        if isinstance(other, CmdBase):
            return self._as_tuple() < other._as_tuple()
        else:
            raise TypeError

    def _as_tuple(self):
        return (self.store_mask,)

    def copy(self) -> CmdStore:
        return copy.copy(self)

    def merge(self, other: CmdStore):
        if not isinstance(other, CmdStore):
            raise TypeError

        self.store_mask |= other.store_mask

    def and_then(self, other: CmdStore) -> CmdStore:
        if not isinstance(other, CmdStore):
            raise TypeError

        new = self.copy()

        new.store_mask = other.store_mask

        return new


class Event:
    """Container for hardware events.

    *The user doesn't need to instantiate this class or its derivatives in any common situation.*

    This is the base class of the return types of many methods of :class:`Pulsed`.
    """

    def __repr__(self) -> str:
        d = dict(self.__dict__)  # make a copy
        keys = sorted(d.keys())
        ll = []
        for key in keys:
            if key.startswith("_"):
                continue
            if isinstance(d[key], float):
                ll.append(f"{key:s} {d[key]:.2e}")
            else:
                ll.append(f"{key:s} {d[key]}")
        rest = ", ".join(ll)
        ret = f"({type(self).__name__}: {rest:s})"
        return ret

    def copy(self) -> Event:
        """Return a :func:`shallow copy <python:copy.copy>` of this object."""
        return copy.copy(self)


class RawTemplate(Event):
    def __init__(
        self,
        channel: int,
        group: int,
        index: int,
        duration: int,
        offset: int,
        envelope: bool,
        inverted: Optional[bool],
        pls: ReferenceType[Pulsed],
    ):
        self.channel: int = channel
        self.group: int = group
        self.index: int = index
        self.duration: int = duration
        self.offset: int = offset
        self.envelope: bool = envelope
        self.inverted: Optional[bool] = inverted
        self._pls: ReferenceType[Pulsed] = pls

    def get_data(self) -> np.ndarray:
        """Return the underlying data array for in-place modification."""
        pls = self._pls()
        if pls is None:
            raise RuntimeError("the associated Pulsed object has been destroyed!")
        data = pls.templates[self.channel][self.index]
        if data is None:
            raise RuntimeError("no data was defined for this template")
        return data

    def copy(self) -> RawTemplate:
        return copy.copy(self)


class Template(Event):
    """An output pulse event.

    *The user doesn't need to instantiate this class in any common situation.*

    Return type of :meth:`setup_template <Pulsed.setup_template>`; input type of
    :meth:`~.Pulsed.output_pulse`.
    """

    def __init__(
        self,
        channels: List[int],
        group: int,
        envelope: bool,
        events: List[Event],
        pls: ReferenceType[Pulsed],
    ):
        self.channels = channels
        self.group = group
        self.envelope = envelope
        self._events = events
        self._pls = pls

        self.duration = self._get_duration_clk()

    def pls(self) -> Pulsed:
        pls = self._pls()
        if pls is None:
            raise RuntimeError("the associated Pulsed object has been destroyed!")
        else:
            return pls

    def append(self, evt: Event):
        self._events.append(evt)
        self.duration = self._get_duration_clk()

    def get_events(self) -> List[Event]:
        return self._events

    def get_templates(self) -> List[RawTemplate]:
        return [x for x in self.get_events() if isinstance(x, RawTemplate)]

    def _get_duration_clk(self) -> int:
        d_clk = 0
        for t in self.get_templates():
            d_t = t.offset + t.duration
            d_clk = max(d_clk, d_t)
        return d_clk

    def get_duration(self) -> float:
        """Get the duration of the template in seconds."""
        return self._get_duration_clk() * self.pls().CLK_T


class FlatPulse:
    """Container for a (long) flat pulse.

    *The user doesn't need to instantiate this class in any common situation.*

    Return type of :meth:`~.Pulsed.setup_flat_pulse`; input type of :meth:`~.Pulsed.output_pulse`.
    """

    def __init__(
        self,
        rise: List[RawTemplate],
        flat: List[RawTemplate],
        fall: List[RawTemplate],
        dig_out: Optional[int],
        pls: ReferenceType[Pulsed],
    ):
        self.rise: List[RawTemplate] = rise
        self.flat: List[RawTemplate] = flat
        self.fall: List[RawTemplate] = fall
        self._dig_out: Optional[int] = dig_out
        self._pls: ReferenceType[Pulsed] = pls

    def pls(self) -> Pulsed:
        pls = self._pls()
        if pls is None:
            raise RuntimeError("the associated Pulsed object has been destroyed!")
        else:
            return pls

    def get_events(self) -> List[Event]:
        templates: List[Event] = []
        templates.extend(self.get_templates())
        if self._dig_out is not None:
            templates.append(
                DigitalOut(
                    channel=self._dig_out,
                    duration=self._get_total_clk(),
                )
            )
        return templates

    def get_templates(self) -> List[RawTemplate]:
        """Return a list of the individual templates that make up the long drive."""
        templates = []
        templates.extend(self.rise)
        templates.extend(self.flat)
        templates.extend(self.fall)
        return templates

    def __repr__(self) -> str:
        return (
            f"(FlatPulse: channel {self._get_channels()}, flat {self._get_flat_clk():d}, rise "
            f"{self._get_rise_clk():d}, fall {self._get_fall_clk():d})"
        )

    def _get_channels(self) -> List[int]:
        return [x.channel for x in self.flat]

    def _get_rise_clk(self) -> int:
        if self.rise:
            return self.rise[0].duration
        else:
            return 0

    def _get_flat_clk(self) -> int:
        if self.flat:
            return self.flat[0].duration
        else:
            return 0

    def _get_fall_clk(self) -> int:
        if self.fall:
            return self.fall[0].duration
        else:
            return 0

    def _get_total_clk(self) -> int:
        return self._get_rise_clk() + self._get_flat_clk() + self._get_fall_clk()

    def get_duration(self) -> float:
        """Get the duration of the pulse in seconds.

        Includes rise and fall segments. Same as :meth:`get_total_duration`.


        See also:
            :meth:`get_total_duration`
            :meth:`get_flat_duration`
        """
        return self.get_total_duration()

    def get_total_duration(self) -> float:
        """Total duration of the pulse in seconds.

        Includes rise and fall segments. Same as :meth:`get_duration`.


        See also:
            :meth:`get_duration`
            :meth:`get_flat_duration`
        """
        total_clk = self._get_total_clk()
        return total_clk * self.pls().CLK_T

    def set_total_duration(self, new_duration: float):
        """Update the pulse by changing the total duration of the pulse.

        Rise and fall times are not affected. The new duration of the flat part will be
        ``new_duration - rise_time - fall_time``.

        Args:
            new_duration: New total duration in seconds of the long pulse. Must be a multiple of
                :meth:`Pulsed.get_clk_T`

        Raises:
            ValueError: if ``new_duration`` is not valid.
        """
        new_total_clk = self.pls().time_to_clk(new_duration)
        rise_clk = self._get_rise_clk()
        fall_clk = self._get_fall_clk()
        new_flat_clk = new_total_clk - rise_clk - fall_clk
        if new_flat_clk < 0:
            min_dur_ns = (rise_clk + fall_clk) * self.pls().CLK_T * 1e9
            raise ValueError(f"Minimum duration: rise_time + fall_time = {min_dur_ns:d} ns.")
        self._set_flat_clk(new_flat_clk)

    def get_flat_duration(self) -> float:
        """Duration of the flat segment of the pulse in seconds.

        Does not include rise and fall segments.


        See also:
            :meth:`get_duration`
            :meth:`get_total_duration`
        """
        return self._get_flat_clk() * self.pls().CLK_T

    def set_flat_duration(self, new_duration: float):
        """Update the pulse by changing the duration of the flat part.

        Rise and fall times are not affected. The new total duration will be
        ``new_duration + rise_time + fall_time``.

        Args:
            new_duration: New duration in seconds for the flat part of the long pulse. Must be a
                multiple of :meth:`Pulsed.get_clk_T`

        Raises:
            ValueError: if ``new_duration`` is not valid.
        """
        new_flat_clk = self.pls().time_to_clk(new_duration)
        if new_flat_clk < 0:
            raise ValueError("can't set negative duration")
        self._set_flat_clk(new_flat_clk)

    def _set_flat_clk(self, new_flat_clk: int):
        self.rise = [x.copy() for x in self.rise]

        self.flat = [x.copy() for x in self.flat]
        for x in self.flat:
            x.duration = new_flat_clk

        self.fall = [x.copy() for x in self.fall]
        for x in self.fall:
            x.offset = new_flat_clk + self._get_rise_clk()


class LongDrive(FlatPulse):
    """
    .. deprecated:: 2.14.0
        See :class:`FlatPulse` instead.
    """


class RawMatch(Event):
    def __init__(
        self,
        group: int,
        index: int,
        duration: int,
        offset: int,
        pls: ReferenceType[Pulsed],
    ):
        self.group: int = group
        self.index: int = index
        self.duration: int = duration
        self.offset: int = offset
        self._pls: ReferenceType[Pulsed] = pls

    def tag(self) -> int:
        return (self.group) + (self.index << 4)


class Match(Event):
    """A template-matching event.

    *The user doesn't need to instantiate this class in any common situation.*

    Return type of :meth:`~.Pulsed.setup_template_matching_pair`; input type of
    :meth:`~.Pulsed.match`, :meth:`~.Pulsed.get_template_matching_data` and
    :meth:`~.Pulsed.setup_condition`.
    """

    def __init__(
        self,
        events: List[RawMatch],
        threshold: int,
        cross_group: bool,
        pls: ReferenceType[Pulsed],
    ):
        self._events = events
        self.threshold: int = threshold
        self.cross_group: bool = cross_group
        self._pls: ReferenceType[Pulsed] = pls

    def pls(self) -> Pulsed:
        pls = self._pls()
        if pls is None:
            raise RuntimeError("the associated Pulsed object has been destroyed!")
        else:
            return pls

    def append(self, evt: RawMatch):
        self._events.append(evt)
        # self.duration = self._get_duration_clk()

    def get_single(self) -> Optional[RawMatch]:
        if len(self._events) == 1:
            return self._events[0]
        else:
            return None

    def get_events(self) -> List[RawMatch]:
        return self._events

    def _get_duration_clk(self) -> int:
        d_clk = 0
        for t in self.get_events():
            d_t = t.offset + t.duration
            d_clk = max(d_clk, d_t)
        return d_clk

    def get_duration(self) -> float:
        """Get the duration of the reference template in seconds."""
        return self._get_duration_clk() * self.pls().CLK_T


class NextFreq(Event):
    """A next-frequency event, internal use only."""

    def __init__(self, channel: int, group: int):
        self.channel: int = channel
        self.group: int = group


class NextScale(Event):
    """A next-scale event, internal use only."""

    def __init__(self, channel: int, group: int):
        self.channel: int = channel
        self.group: int = group


class ResetPhase(Event):
    """A reset-phase event, internal use only."""

    def __init__(self, channel: int, group: int):
        self.channel: int = channel
        self.group: int = group


class SelFreq(Event):
    """A select-frequency event, internal use only."""

    def __init__(self, channel: int, group: int, index: int):
        self.channel: int = channel
        self.group: int = group
        self.index: int = index


class SelScale(Event):
    """A select-scale event, internal use only."""

    def __init__(self, channel: int, group: int, index: int):
        self.channel: int = channel
        self.group: int = group
        self.index: int = index


class Store(Event):
    """A store event, internal use only."""

    def __init__(self, channel: int, duration: int):
        self.channel: int = channel
        self.duration: int = duration


class DigitalOut(Event):
    """An output marker event, internal use only."""

    def __init__(self, channel: int, duration: int):
        self.channel: int = channel
        self.duration: int = duration


class DcBiasOut(Event):
    """A DC bias output event, internal use only."""

    def __init__(self, channel: int, raw_command: int):
        self.channel: int = channel
        self.raw_command: int = raw_command


class MeasurementStatus(enum.Enum):
    """Enumeration for current status of the measurement"""

    IDLE = enum.auto()  #: standby
    CHECKING = enum.auto()  #: checking user parameters for errors
    UPLOADING = enum.auto()  #: uploading user parameters to the hardware
    ARMED = enum.auto()  #: waiting for trigger
    RUNNING = enum.auto()  #: measurement is running
    DOWNLOADING = enum.auto()  #: measurement is done, downloading measurement data
    DONE = enum.auto()  #: measurement complete
    ABORTED = enum.auto()  #: measurement aborted by the user or by an error

    def runnable(self) -> bool:
        return self in (
            MeasurementStatus.IDLE,
            MeasurementStatus.DONE,
            MeasurementStatus.ABORTED,
        )

    def check_runnable(self):
        if not self.runnable():
            raise RuntimeError("can't run a new measurement while one is already running")


class MeasurementHandle:
    """Handle to a running measurement.

    Return type of :meth:`~.Pulsed.run_async`, *do not instantiate this class directly*.
    """

    def __init__(self, pls: ReferenceType[Pulsed]):
        self._pls: ReferenceType[Pulsed] = pls

    def pls(self) -> Pulsed:
        pls = self._pls()
        if pls is None:
            raise RuntimeError("the associated Pulsed object has been destroyed!")
        else:
            return pls

    def time_remaining(self) -> timedelta:
        """Estimated remaining time until the end of the measurement.

        Notes:
            If the measurement is not :obj:`RUNNING <MeasurementStatus.RUNNING>`,
            returns ``timedelta(0)``.

        Examples:

            >>> tr = handle.time_remaining()
            >>> tr
            datetime.timedelta(seconds=115, microseconds=897831)
            >>> tr.total_seconds()
            115.897831
            >>> str(tr)
            '0:01:55.897831'
            >>> print(tr)
            0:01:55.897831
            >>> from presto.utils import format_sec
            >>> format_sec(tr)
            '1m 55.9s'
        """
        pls = self.pls()
        if pls._status is MeasurementStatus.RUNNING:
            now = datetime.now()
            return pls._time_end - now
        else:
            return timedelta(0)

    def time_elapsed(self) -> timedelta:
        """Time elapsed since the start of the measurement.

        Notes:
            The time elapsed keeps counting even if the measurement is completed.
            When ``dry_run=True``, returns ``timedelta(0)``.

        Examples:

            >>> te = handle.time_elapsed()
            >>> te
            datetime.timedelta(seconds=269, microseconds=455817)
            >>> te.total_seconds()
            269.455817
            >>> str(te)
            '0:04:29.455817'
            >>> print(te)
            0:04:29.455817
            >>> from presto.utils import format_sec
            '4m 29.5s'
        """
        now = datetime.now()
        time_start = self.pls()._time_start
        if time_start is _T_ZERO:
            return timedelta(0)
        else:
            return now - time_start

    def time_start(self) -> datetime:
        """Start time of the measurement.

        Notes:
            When ``dry_run=True``, returns ``datetime.fromtimestamp(0)``.

        Examples:

            >>> ts = handle.time_start()
            >>> ts
            datetime.datetime(2022, 6, 22, 14, 52, 53, 850711)
            >>> ts.isoformat()
            '2022-06-22T14:52:53.850711'
            >>> ts.strftime('%Y-%m-%d %H:%M:%S')
            '2022-06-22 14:52:53'
            >>> str(ts)
            '2022-06-22 14:52:53.850711'
            >>> print(ts)
            2022-06-22 14:52:53.850711
        """
        return self.pls()._time_start

    def time_end(self) -> datetime:
        """Estimated end time of the measurement.

        Notes:
            If the measurement is completed, returns the actual time of completion.
            When ``dry_run=True``, returns ``datetime.fromtimestamp(0)``.

        Examples:

            >>> te = handle.time_end()
            >>> te
            datetime.datetime(2022, 6, 22, 14, 55, 2, 978135)
            >>> te.isoformat()
            '2022-06-22T14:55:02.978135'
            >>> te.strftime('%Y-%m-%d %H:%M:%S')
            '2022-06-22 14:55:02'
            >>> str(te)
            '2022-06-22 14:55:02.978135'
            >>> print(te)
            2022-06-22 14:55:02.978135
        """
        return self.pls()._time_end

    def join(self):
        """Block execution until the measurement is done."""
        return self.pls().join()

    def abort(self):
        """Abort current measurement."""
        self.pls()._status = MeasurementStatus.ABORTED

    def status(self) -> MeasurementStatus:
        """Current status of the measurement"""
        return self.pls()._status
