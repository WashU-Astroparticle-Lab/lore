# -*- coding: utf-8 -*-
# Copyright © 2018-2024 Intermodulation Products AB. All Rights Reserved.
"""
Hardware configuration common to all modes of operation.

Detailed information is provided in the documentation for each class:

.. autosummary::
    :nosignatures:

    Hardware
    MultibandMode
    TriggerSource
    AdcMode
    DacMode
    AdcFSample
    DacFSample
"""

from __future__ import annotations

import enum
import hashlib
from itertools import islice
import math
import os.path
import socket
import struct
import threading
import time
from typing import Dict, List, Literal, Optional, Tuple, Union, overload
import warnings

import numpy as np
from packaging.version import parse

from . import _commands as cmd
from .utils import asarray, as_flat_list, compatible_dac_configs
from .version import version_conductor, version_fpga, version_rpu

DEFAULT_ADDR = "192.168.42.50"
DEFAULT_PORT = 7878
RPL_ERR = 0x955F038CD799103F

B_RPL_ERR = struct.pack("<Q", RPL_ERR)


@enum.unique
class TriggerSource(enum.Enum):
    """Select trigger source for starting a pulsed measurement"""

    # 0 is used for stop
    Internal = 1
    """Run immediately

    :meta hide-value:"""
    # 2 is used for reset
    Sysref = 4
    """Wait for multi-presto synchronization

    :meta hide-value:"""
    DigitalIn1 = 8
    """Wait for high on digital input 1

    :meta hide-value:"""
    DigitalIn2 = 16
    """Wait for high on digital input 2

    :meta hide-value:"""
    DigitalIn3 = 32
    """Wait for high on digital input 3

    :meta hide-value:"""
    DigitalIn4 = 64
    """Wait for high on digital input 4

    :meta hide-value:"""


@enum.unique
class MultibandMode(enum.Enum):
    """Configuration options for multiband operation on a tile"""

    SingleBand = 0
    """Each port in tile works independently

    :meta hide-value:"""
    DualBand12 = 1
    """Combine ports 1 and 2 into port 1, leave ports 3 and 4 unaffected

    :meta hide-value:"""
    DualBand34 = 2
    """Combine ports 3 and 4 into port 3, leave ports 1 and 2 unaffected

    :meta hide-value:"""
    DualBandAll = 3
    """Combine ports 1 and 2 into port 1 and ports 3 and 4 into port 3

    :meta hide-value:"""
    QuadBand = 4
    """Combine ports 1, 2, 3 and 4 into port 1

    :meta hide-value:"""


@enum.unique
class AdcMode(enum.Enum):
    """Configuration for analog-to-digital converters (ADC), i.e. input channels

    Note:
        Use ``Direct`` for baseband input, or ``Mixed`` for digital IQ downconversion.
    """

    Direct = 0
    """direct mode, i.e. no digital downconversion

    :meta hide-value:"""
    Mixed = 1
    """IQ mixed mode, i.e. with digital downconversion

    :meta hide-value:"""


@enum.unique
class DacMode(enum.Enum):
    """Configuration for digital-to-analog converters (DAC), i.e. output channels.

    Note:
        Use ``Direct`` for baseband output, or ``Mixed`` for digital IQ upconversion.

        Other settings are mainly for internal use, or to override the default configuration. For
        most applications, use either ``Direct`` or ``Mixed``.
    """

    Direct = 0
    """direct mode, i.e. no digital upconversion

    :meta hide-value:"""
    Mixed02 = 1
    r"""standard IQ mixed mode, i.e. with digital upconversion. Only valid for sampling rates
    :math:`f_\mathrm{S} \le 7 \mathrm{GS/s}`.
    This is a low-level setting, it is recommeded to use ``Mixed`` instead.

    :meta hide-value:"""
    Mixed04 = 2
    r"""IQ mixed mode with
    :math:`f_\mathrm{out} \in [0;f_\mathrm{S}/4] \cup [3f_\mathrm{S}/4;f_\mathrm{S}]`.
    Only valid on Presto hardware.
    This is a low-level setting, it is recommeded to use ``Mixed`` instead.

    :meta hide-value:"""
    Mixed42 = 3
    r"""IQ mixed mode with :math:`f_\mathrm{out} \in [f_\mathrm{S}/4; 3f_\mathrm{S}/4]`.
    Only valid on Presto hardware.
    This is a low-level setting, it is recommeded to use ``Mixed`` instead.

    :meta hide-value:"""
    Mixed = -1
    r"""preferred IQ mixed mode, i.e. with digital upconversion. Automatically choose appriate
    setting among ``Mixed02``, ``Mixed04`` and ``Mixed42`` depending on sampling rate and signal
    frequency.

    :meta hide-value:"""


@enum.unique
class AdcFSample(enum.Enum):
    """Sampling rate setting for analog-to-digital converters (ADC), i.e. input channels.

    Note:
        These settings are mainly for internal use, or to override the default configuration. For
        most applications, leave the argument ``adc_fsample`` unspecified (or set it to
        :obj:`None`) to let the API select the optimal value.
    """

    G2 = 0
    r""":math:`f_\mathrm{S} = 2 \mathrm{GS/s}`

    :meta hide-value:"""
    G3_2 = 1
    r""":math:`f_\mathrm{S} = 3.2 \mathrm{GS/s}`. Only valid on Vivace hardware

    :meta hide-value:"""
    G4 = 2
    r""":math:`f_\mathrm{S} = 4 \mathrm{GS/s}`. Not valid on 16-channel Presto hardware

    :meta hide-value:"""

    def fs(self) -> float:
        return float(self.MSps())

    def fs_nco(self, mode: Optional[AdcMode] = None) -> float:
        return float(self.MSps_nco(mode))

    def nyq(self) -> float:
        return self.fs() / 2.0

    def MSps(self) -> int:
        if self is type(self).G2:
            return 2_000
        elif self is type(self).G3_2:
            return 3_200
        elif self is type(self).G4:
            return 4_000
        else:
            raise NotImplementedError

    def MSps_nco(self, mode: Optional[AdcMode] = None) -> int:  # pyright: ignore
        return self.MSps()

    def to_1st(self, f_MHz: float) -> float:
        fs_MHz = self.fs()
        return _to_1st(f_MHz, fs_MHz)

    def to_1st_nco(self, f_MHz: float, mode: Optional[AdcMode] = None) -> float:
        fs_MHz = self.fs_nco(mode)
        return _to_1st(f_MHz, fs_MHz)

    def fix_freq(self, f_MHz: float, mode: AdcMode, zone: int) -> float:
        return _fix_for_xrfdc(f_MHz, self.fs_nco(mode), zone)


@enum.unique
class DacFSample(enum.Enum):
    """Sampling rate setting for digital-to-analog converters (DAC), i.e. output channels.

    Note:
        These settings are mainly for internal use, or to override the default configuration. For
        most applications, leave the argument ``dac_fsample`` unspecified (or set it to
        :obj:`None`) to let the API select the optimal value.
    """

    G2 = 0
    r""":math:`f_\mathrm{S} = 2 \mathrm{GS/s}`

    :meta hide-value:"""
    G4 = 1
    r""":math:`f_\mathrm{S} = 4 \mathrm{GS/s}`

    :meta hide-value:"""
    G6 = 2
    r""":math:`f_\mathrm{S} = 6 \mathrm{GS/s}`. Only valid on Presto hardware

    :meta hide-value:"""
    G6_4 = 3
    r""":math:`f_\mathrm{S} = 6.4 \mathrm{GS/s}`. Only valid on Vivace hardware

    :meta hide-value:"""
    G8 = 4
    r""":math:`f_\mathrm{S} = 8 \mathrm{GS/s}`. Only valid on Presto hardware

    :meta hide-value:"""
    G10 = 5
    r""":math:`f_\mathrm{S} = 10 \mathrm{GS/s}`. Only valid on Presto hardware

    :meta hide-value:"""

    def fs(self) -> float:
        return float(self.MSps())

    def fs_nco(self, mode: DacMode) -> float:
        return float(self.MSps_nco(mode))

    def nyq(self) -> float:
        return self.fs() / 2.0

    def MSps(self) -> int:
        if self is type(self).G2:
            return 2_000
        elif self is type(self).G4:
            return 4_000
        elif self is type(self).G6:
            return 6_000
        elif self is type(self).G6_4:
            return 6_400
        elif self is type(self).G8:
            return 8_000
        elif self is type(self).G10:
            return 10_000
        else:
            raise NotImplementedError

    def MSps_nco(self, mode: DacMode) -> int:
        if mode is DacMode.Mixed04 or mode is DacMode.Mixed42:
            return self.MSps() // 2
        else:
            return self.MSps()

    def to_1st(self, f_MHz: float) -> float:
        fs_MHz = self.fs()
        return _to_1st(f_MHz, fs_MHz)

    def to_1st_nco(self, f_MHz: float, mode: DacMode) -> float:
        fs_MHz = self.fs_nco(mode)
        return _to_1st(f_MHz, fs_MHz)

    def fix_freq(self, f_MHz: float, mode: DacMode, zone: int) -> float:
        return _fix_for_xrfdc(f_MHz, self.fs_nco(mode), zone)


def _to_1st(f: float, fs: float) -> float:
    f = math.fmod(f, fs)
    if f < -fs / 2:
        f += fs
    elif f > fs / 2:
        f -= fs
    return f


def _fix_for_xrfdc(nco_freq: float, sampling_rate: float, nyquist_zone: int) -> float:
    XRFDC_NCO_FREQ_MULTIPLIER = 0x1 << 48  # 2^48

    nco_freq = _to_1st(nco_freq, sampling_rate)
    n = int(round(nco_freq * XRFDC_NCO_FREQ_MULTIPLIER / sampling_rate))
    if n >= 0:
        n += 0.5
    else:
        n -= 0.5
    nco_freq = n * (sampling_rate / XRFDC_NCO_FREQ_MULTIPLIER)

    if nyquist_zone % 2 == 0:  # even zone
        nco_freq = -nco_freq

    return nco_freq


class _DacConfig:
    def __init__(self, setup: DacMode, fsample: DacFSample):
        self.setup: DacMode = setup
        self.fsample: DacFSample = fsample

    def __eq__(self, other: object) -> bool:
        if isinstance(other, _DacConfig):
            return self.__dict__ == other.__dict__
        else:
            return False

    def __repr__(self) -> str:
        return f"{self.setup.name}-{self.fsample.name}"

    def _recommended_range(self):
        i = 0
        if self.setup is DacMode.Direct:
            yield (0, 45)
        elif self.setup is DacMode.Mixed02:
            while True:
                yield (i + (0 if i == 0 else 5), i + 45)
                yield (i + 55, i + 95)
                i += 100
        elif self.setup is DacMode.Mixed04:
            while True:
                yield (i + (0 if i == 0 else 5), i + 20)
                yield (i + 80, i + 95)
                i += 100
        elif self.setup is DacMode.Mixed42:
            while True:
                yield (i + 30, i + 45)
                yield (i + 55, i + 70)
                i += 100

    def recommended_range(self, hnz: Optional[int] = 3):
        return islice(
            map(
                lambda t: (
                    t[0] * self.fsample.MSps() // 100,
                    t[1] * self.fsample.MSps() // 100,
                ),
                self._recommended_range(),
            ),
            hnz,
        )

    def is_in_range(self, freq: float, hnz: Optional[int] = 3) -> bool:
        tol = max(1e-3, abs(freq) * 1e-9)  # tolerance for float comparison
        for low, high in self.recommended_range(hnz):
            if low - freq > tol:
                break
            if (low - freq < tol) and (freq - high < tol):
                return True
        return False

    def _spurs(self, f1st: int, fs: int):
        yield f1st
        n = 1
        while True:
            yield n * fs - f1st
            yield n * fs + f1st
            n += 1

    def spurs(self, freq: float) -> Tuple[Optional[float], float]:
        freq = int(round(freq))
        fs = self.fsample.MSps()
        f1st = int(round(abs(_to_1st(freq, fs))))
        lower = None
        temp = None
        higher = None
        for x in self._spurs(f1st, fs):
            lower = temp
            temp = higher
            higher = x
            if x > freq:
                break
        assert higher is not None
        return (lower, higher)


class MixerSettings:
    def __init__(
        self, base_MHz: float, n: int, phase: float, zone: Optional[int], tune: bool = True
    ):
        self.base_MHz = base_MHz
        self.n = n
        self.phase = phase
        self.zone = zone
        self.tune = tune


class Hardware:
    """Interface to the Vivace/Presto hardware.

    *This class does not need to be instantiated by the user.* It is available as the ``hardware``
    attribute of instances of :class:`~.lockin.Lockin` and :class:`~.pulsed.Pulsed` classes.

    Examples:
        Configure digital IQ mixers:

        >>> from presto.hardware import AdcMode, DacMode
        >>> from presto import lockin
        >>> with lockin.Lockin(adc_mode=AdcMode.Mixed, dac_mode=DacMixed02) as lck:
        >>>     lck.hardware.configure_mixer(
        >>>         freq=3.5e+9,  # 3.5 GHz
        >>>         in_ports=1,
        >>>         out_ports=[1, 2],
        >>>     )
    """

    def __init__(
        self,
        address: Optional[str] = None,
        port: Optional[int] = None,
        dry_run: bool = False,
        adc_bus_width: int = 4,
        dac_bus_width: int = 4,
        adc_fab_rate: float = 500.0,
        dac_fab_rate: float = 500.0,
    ):
        self.sock: Optional[socket.socket] = None
        self.dry_run = bool(dry_run)
        self.adc_bus_width = int(adc_bus_width)  # nr real samples per clk cycle
        self.dac_bus_width = int(dac_bus_width)  # nr real samples per clk cycle
        self.adc_fab_rate = float(adc_fab_rate)  # MHz
        self.dac_fab_rate = float(dac_fab_rate)  # MHz
        self.adc_setup: list[AdcMode] = []
        self.adc_fsample: list[AdcFSample] = []
        self.dac_setup: list[DacMode] = []
        self.dac_fsample: list[DacFSample] = []
        self.dac_autoconfig = False  # changed by validate_config
        self._defer_mixer_config = False  # changed by validate_config
        self._apply_required_rf = True  #: something changed in the NCO domain or in the converters
        self._mixer_adc: Dict[int, MixerSettings] = {}
        self._mixer_dac: Dict[int, Tuple[MixerSettings, List[Tuple[_DacConfig, float]]]] = {}
        self.board = "zcu216"  # overridden when connected
        self.nr_ports = 16  # overridden when connected
        # last used range for DC bias: dict[port] = (range_i, range_f)
        self._dc_range: dict[int, tuple[float, float]] = {}

        if not self.dry_run:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                self.sock.setsockopt(socket.SOL_TCP, socket.TCP_NODELAY, 1)
                if address is None:
                    address = DEFAULT_ADDR
                if port is None:
                    port = DEFAULT_PORT
                self.sock.connect((address, port))

                self._check_version_conductor()

                self.board = self.get_board_name()
                self.nr_ports = self.get_nr_ports()
            except (Exception, KeyboardInterrupt):
                self.close()
                raise

    def __enter__(self):  # for use with 'with' statement
        return self

    def __exit__(self, exc_type, exc_value, traceback):  # pyright: ignore
        self.close()

    def close(self):
        """Close the connection to the hardware

        This method is called automatically upon exit from a :ref:`with block <python:with>`
        """
        if self.sock is not None:
            self.sock.close()
            self.sock = None
            # NOTE: sleep a tiny bit after closing connection
            # or next connection might get a ConnectionRefusedError
            # if reconnecting too quickly
            time.sleep(0.001)

    def _quit_server(self):
        self._send_command(cmd.Msg__Quit())

    def _send_command(self, cmd: cmd.Msg):
        message = cmd.bincode_serialize()
        if self.sock is not None:
            self.sock.sendall(message)

    def _echo(self, val: int) -> int:
        val = int(val)
        if self.sock is not None:
            self._send_command(cmd.Msg__Echo(val))
            reply = self._receive(8)
            return int.from_bytes(reply, byteorder="little", signed=False)
        else:
            return val

    def _receive(self, N: int) -> bytearray:
        expected = int(N)
        buf = bytearray(expected)
        if self.sock is not None:
            self._receive_from_into(N, self.sock, buf)
        return buf

    def _receive_from(self, N: int, sock: socket.socket, *, status_callback=None) -> bytearray:
        expected = int(N)
        buf = bytearray(expected)
        self._receive_from_into(N, sock, buf, status_callback=status_callback)
        return buf

    def _receive_from_into(
        self, N: int, sock: socket.socket, buf: bytearray, *, status_callback=None
    ):
        expected = int(N)
        assert len(buf) >= expected
        view = memoryview(buf)
        received = 0
        while received < expected:
            remaining = expected - received
            nb = sock.recv_into(view[received:expected], remaining)
            if nb == 0:
                raise RuntimeError(f"connection closed, got {received} bytes out of {expected}")
            received += nb
            if status_callback is not None:
                status_callback(nb)
            if buf.startswith(B_RPL_ERR):
                # raise RuntimeError("the server sent a RPL_ERR value.")
                self.assert_errors()

    def _receive_compressed(self, N: int) -> bytearray:
        expected = int(N)
        buf = bytearray(expected)
        if self.sock is not None:
            self._receive_from_into_compressed(N, self.sock, buf)
        return buf

    def _receive_from_compressed(self, N: int, sock: socket.socket) -> bytearray:
        expected = int(N)
        buf = bytearray(expected)
        self._receive_from_into_compressed(N, sock, buf)
        return buf

    def _receive_from_into_compressed(
        self, N: int, sock: socket.socket, buf: bytearray
    ) -> bytearray:
        from lz4.frame import LZ4FrameDecompressor

        do = LZ4FrameDecompressor()
        expected = int(N)
        assert len(buf) >= expected
        view = memoryview(buf)
        temp = bytearray(4096)
        tempview = memoryview(temp)
        received = 0
        received_compressed = 0
        while received < expected:
            temp_received = sock.recv_into(tempview)
            if temp_received == 0:
                raise RuntimeError(f"connection closed, got {received} bytes out of {expected}")
            received_compressed += temp_received
            data = do.decompress(tempview[:temp_received])
            view[received : received + len(data)] = data
            received += len(data)

            if buf.startswith(B_RPL_ERR):
                # raise RuntimeError("the server sent a RPL_ERR value.")
                self.assert_errors()

        if received != expected:
            raise RuntimeError(f"expected {expected} bytes, got {received}")

        return buf

    def reset(self):
        self._send_command(cmd.Msg__Reset())

    def sleep(self, secs: float, wait: bool = True):
        """Tell the hardware to sleep for ``secs`` seconds.

        Like :func:`time.sleep`, except the sleep is done on the hardware rather than on the local
        computer.

        Args:
            secs: duration of sleep in seconds
            wait: if False, tell the hardware to sleep without waiting for completion. If True
                (default), block the calling thread on the local computer until the hardware is
                done sleeping.
        """
        secs = float(secs)
        self._send_command(cmd.Msg__Sleep(secs))

        if wait:
            # send an echo command and wait for answer
            self._echo(42)

    def init_clock(self, ext_ref_clk: Union[None, bool, int, float]):
        if ext_ref_clk is None:
            val = 0
        else:
            if isinstance(ext_ref_clk, bool):
                val = 10_000_000 if ext_ref_clk else 0
            else:
                val = int(round(ext_ref_clk))
        self._send_command(cmd.Msg__ClockInit(val))

    def set_lmx(self, freq: float, pwr: int, ports=None):
        """Configure the clock chip on Presto hardware to use as RF source.

        *The new setting is applied* **immediately**.

        Args:
            freq: frequency in Hz between <~ 10 MHz and 15 GHz
            pwr: power setting in ``[0, 47]``
            ports (int or list of int): valid values are 1 and 2. If None (default), use both.
        """
        if ports is None:
            ports = [1, 2]
        else:
            ports = np.atleast_1d(ports).astype(np.int64)
            if np.any(ports < 1) or np.any(ports > 2):
                raise ValueError("invalid LMX port, valid values are 1 and 2")

        freq = int(round(freq))
        pwr = int(pwr)
        for port in ports:
            channel = port - 1
            self._send_command(cmd.Msg__ClockSetLmx((channel, freq, pwr)))

    def load_firmware(self, filename: str):
        self._send_command(cmd.Msg__LoadFirmware(filename))

    def init_presto(self):
        self._send_command(cmd.Msg__PrestoInit())

    def init_rfdc(self):
        self._send_command(cmd.Msg__RfdcInit())

    def sync(self):
        """Manually issue a command to synchronize the NCO phases.

        Can be used after a call to :meth:`configure_mixer` with ``sync=False``.

        Examples:
            This code:

            >>> with lockin.Lockin(adc_mode=AdcMode.Mixed, dac_mode=DacMixed02) as lck:
            >>>     lck.hardware.configure_mixer(
            >>>         freq=3.5e+9,  # 3.5 GHz
            >>>         in_ports=1,
            >>>         out_ports=1,
            >>>         sync=False,  # don't sync here...
            >>>     )
            >>>     lck.hardware.sync()  # <-- sync here!

            is equivalent to this code:

            >>> with lockin.Lockin(adc_mode=AdcMode.Mixed, dac_mode=DacMixed02) as lck:
            >>>     lck.hardware.configure_mixer(
            >>>         freq=3.5e+9,  # 3.5 GHz
            >>>         in_ports=1,
            >>>         out_ports=1,
            >>>         sync=True,  # <-- sync here!
            >>>     )
        """
        self._send_command(cmd.Msg__RfdcSync())

    def mts(
        self,
        target_latency_adc: Optional[int] = None,
        target_latency_dac: Optional[int] = None,
    ):
        if target_latency_adc is None:
            # use calibrated target latency, encode as -2
            target_latency_adc = -2
        elif target_latency_adc == -1:
            # set no target latency, encoded as -1 by XRFdc
            target_latency_adc = -1
        elif target_latency_adc > 0:
            target_latency_adc = int(target_latency_adc)
        else:
            raise ValueError(
                f"target_latency_adc must be positive, -1 (no target), or None (calibrated);"
                f" got {target_latency_adc}"
            )

        if target_latency_dac is None:
            # use calibrated target latency, encode as -2
            target_latency_dac = -2
        elif target_latency_dac == -1:
            # set no target latency, encoded as -1 by XRFdc
            target_latency_dac = -1
        elif target_latency_dac > 0:
            target_latency_dac = int(target_latency_dac)
        else:
            raise ValueError(
                f"target_latency_dac must be positive, -1 (no target), or None (calibrated);"
                f" got {target_latency_dac}"
            )

        self._send_command(cmd.Msg__RfdcMts((target_latency_adc, target_latency_dac)))

    def get_var_ver(self) -> Tuple[int, int]:
        self._send_command(cmd.Msg__PrestoVarVer())
        reply = self._receive(8)
        variant = int.from_bytes(reply[4:], byteorder="little", signed=False)
        version = int.from_bytes(reply[:4], byteorder="little", signed=False)
        return (variant, version)

    def get_nr_ports(self) -> int:
        self._send_command(cmd.Msg__NrPorts())
        reply = self._receive(8)
        return int.from_bytes(reply, byteorder="little", signed=False)

    def set_run(self, state: bool, trigger: TriggerSource = TriggerSource.Internal):
        value = trigger.value if state else 0
        self._send_command(cmd.Msg__PrestoRun(value))

    def _ports_to_mask(self, in_ports, out_ports) -> int:
        in_ports = np.atleast_1d(in_ports).astype(np.int64)
        out_ports = np.atleast_1d(out_ports).astype(np.int64)
        mask = 0
        for port in in_ports:
            channel = port - 1
            mask |= 1 << channel
        for port in out_ports:
            channel = port - 1
            mask |= 1 << (channel + 16)
        return mask

    def _nr_tiles(self, type_: str) -> int:
        if type_ == "adc":
            if self.board == "zcu216":
                return 4
            elif self.board == "zcu208":
                return 4
            elif self.board == "zcu111":
                return 4
            else:
                raise NotImplementedError(f'unrecognized board "{self.board}"')
        elif type_ == "dac":
            if self.board == "zcu216":
                return 4
            elif self.board == "zcu208":
                return 4
            elif self.board == "zcu111":
                return 2
            else:
                raise NotImplementedError(f'unrecognized board "{self.board}"')
        else:
            raise ValueError(f'type_ must be "adc" or "dac", got "{type_}"')

    def _blocks_per_tile(self, type_: str) -> int:
        if type_ == "adc":
            if self.board == "zcu216":
                return 4
            elif self.board == "zcu208":
                return 2
            elif self.board == "zcu111":
                return 2
            else:
                raise NotImplementedError(f'unrecognized board "{self.board}"')
        elif type_ == "dac":
            if self.board == "zcu216":
                return 4
            elif self.board == "zcu208":
                return 2
            elif self.board == "zcu111":
                return 4
            else:
                raise NotImplementedError(f'unrecognized board "{self.board}"')
        else:
            raise ValueError(f'type_ must be "adc" or "dac", got "{type_}"')

    def _port_to_tile(self, port: int, type_: str) -> int:
        if port < 1 or port > self.nr_ports:
            raise ValueError(f"port out of range, must be in [1, {self.nr_ports}], got {port}")
        blocks_per_tile = self._blocks_per_tile(type_)
        channel = port - 1
        return channel // blocks_per_tile

    def _tune_nco_freq(self, freq_MHz: float) -> float:
        fs_arr: List[int] = []
        for adc_mode, adc_fsample in zip(self.adc_setup, self.adc_fsample):
            fs_arr.append(adc_fsample.MSps_nco(adc_mode))
        for dac_mode, dac_fsample in zip(self.dac_setup, self.dac_fsample):
            fs_arr.append(dac_fsample.MSps_nco(dac_mode))
        fs_lcm = _lcm(*fs_arr)  # MHz

        n = round(freq_MHz * 2**48 / fs_lcm)
        freq_MHz = n * fs_lcm / 2**48
        return freq_MHz

    def configure_mixer_base_n(
        self,
        base_freq: float,
        *,
        in_n=None,
        out_n=None,
        in_ports=None,
        out_ports=None,
        in_zone: Optional[int] = None,
        out_zone: Optional[int] = None,
        in_phase: float = 0.0,
        out_phase: float = 0.0,
        sync: bool = True,
        tune: bool = True,
    ):
        r"""Configure the NCO for the digital IQ mixers with strict integer requirements.

        This method is a variant of :meth:`configure_mixer` that allows the user to express the
        desired frequencies on multiple ports as integer multiples of a common base frequency. It
        is useful to ensure that, even after small rounding errors in the digital domain, the final
        frequencies programmed in the NCOs maintain the desired rational relation to each other.

        Args:
            base_freq: base frequency of the numerically-controlled oscillator (NCO) in Hz
            in_n (int or list of int): input frequencies as multiples of ``base_freq``
            out_n (int or list of int): output frequencies as multiples of ``base_freq``
            in_ports (int or list of int): configure downconversion for ports in ``in_ports``
            out_ports (int or list of int): configure upconversion for ports in ``out_ports``
            in_zone: optimize downconversion mixer for operation in the ``in_zone``\ th Nyquist
                band. If :obj:`None` (default), choose appropriate zone automatically
            out_zone: optimize upconversion mixer for operation in the ``out_zone``\ th Nyquist
                band. If :obj:`None` (default), choose appropriate zone automatically
            in_phase: phase of the numerically-controlled oscillator (NCO) in radians for each input port
            out_phase: phase of the numerically-controlled oscillator (NCO) in radians for each output port
            sync: *deprecated since version 2.12.0*, see Notes section below.
            tune: if ``True`` (default), avoid long-term drifts between ports by rounding ``freq``
                so that it is representable exactly by the NCOs in all input and output ports. If
                ``False``, ``freq`` is programmed as-is into the different NCOs and a small
                frequency mismatch (at most 40 μHz) can occur between different channels, leading
                to a slow phase drift (at most 0.8 deg/min).

        Examples:

            Configure 240 MHz on port 1 and 720 MHz on port 2, ensuring that the frequency on port
            2 is *exactly* three times the frequency on port 1:

            >>> from presto.hardware import AdcMode, DacMode
            >>> from presto import lockin
            >>> with lockin.Lockin(adc_mode=AdcMode.Mixed, dac_mode=DacMixed) as lck:
            >>>     lck.hardware.configure_mixer_base_n(
            >>>         base_freq=2.4e8,   # 240 MHz base frequency
            >>>         in_n=1,            # 240 MHz carrier...
            >>>         in_ports=1,        # ...on input port 1
            >>>         out_n=[1, 3],      # 240 MHz and 720 MHz carriers...
            >>>         out_ports=[1, 2],  # ...on output ports 1 and 2
            >>>     )

        Notes:
            See :meth:`configure_mixer` for additional notes.
        """
        # validate ports
        if in_ports is None and out_ports is None:
            raise ValueError("At least one of in_ports or out_ports must be given.")
        if in_ports is None:
            in_ports = np.array([], np.int64)
        else:
            in_ports = np.atleast_1d(in_ports).astype(np.int64)
        if np.any(in_ports < 1) or np.any(in_ports > self.nr_ports):
            raise ValueError(f"valid input ports are in [1, {self.nr_ports}]")
        if out_ports is None:
            out_ports = np.array([], np.int64)
        else:
            out_ports = np.atleast_1d(out_ports).astype(np.int64)
        if np.any(out_ports < 1) or np.any(out_ports > self.nr_ports):
            raise ValueError(f"valid output ports are in [1, {self.nr_ports}]")

        # validate `n`
        if in_n is None:
            if len(in_ports) > 0:
                raise ValueError(
                    "no value for `in_n` specified, required because `in_ports` is not empty"
                )
            in_n = np.array([], np.int64)
        else:
            if len(in_ports) == 0:
                raise ValueError(
                    "no value for `in_ports` specified, required because `in_n` is not empty"
                )
            if np.ndim(in_n) == 0:
                in_n = np.full(len(in_ports), int(in_n))
            else:
                in_n = np.atleast_1d(in_n).astype(np.int64)
        if out_n is None:
            if len(out_ports) > 0:
                raise ValueError(
                    "no value for `out_n` specified, required because `out_ports` is not empty"
                )
            out_n = np.array([], np.int64)
        else:
            if len(out_ports) == 0:
                raise ValueError(
                    "no value for `out_ports` specified, required because `out_n` is not empty"
                )
            if np.ndim(out_n) == 0:
                out_n = np.full(len(out_ports), int(out_n))
            else:
                out_n = np.atleast_1d(out_n).astype(np.int64)

        # by now, n and ports should have the same length
        if len(in_n) != len(in_ports):
            raise ValueError(
                "`in_n` should either be scalar or have the same length as `in_ports`"
            )
        if len(out_n) != len(out_ports):
            raise ValueError(
                "`out_n` should either be scalar or have the same length as `out_ports`"
            )

        # validate frequencies
        base_Hz = abs(float(base_freq))
        for n in in_n:
            f = n * base_Hz
            if f > 1e10:
                raise ValueError(f"input frequency not supported: got {f} Hz, max is 10 GHz")
        for n in out_n:
            f = n * base_Hz
            if f > 1e10:
                raise ValueError(f"output frequency not supported: got {f} Hz, max is 10 GHz")

        # use MHz from now on
        base_MHz = base_Hz / 1e6

        if self._defer_mixer_config:
            for n, in_port in zip(in_n, in_ports):
                sett = MixerSettings(base_MHz, n, in_phase, in_zone, tune)
                self._mixer_adc[in_port] = sett
            for n, out_port in zip(out_n, out_ports):
                sett = MixerSettings(base_MHz, n, out_phase, out_zone, tune)
                configs = compatible_dac_configs(n * base_MHz)
                self._mixer_dac[out_port] = (sett, configs)
            self._apply_required_rf = True
        else:
            self._configure_mixer_inner(
                base_MHz=base_MHz,
                in_n=in_n,
                out_n=out_n,
                in_ports=in_ports,
                out_ports=out_ports,
                in_zone=in_zone,
                out_zone=out_zone,
                in_phase=in_phase,
                out_phase=out_phase,
                sync=sync,
                tune=tune,
            )

    def configure_mixer(
        self,
        freq: float,
        *,
        in_ports=None,
        out_ports=None,
        in_zone: Optional[int] = None,
        out_zone: Optional[int] = None,
        in_phase: float = 0.0,
        out_phase: float = 0.0,
        sync: bool = True,
        tune: bool = True,
    ):
        r"""Configure the NCO for the digital IQ mixers.

        Args:
            freq: frequency of the numerically-controlled oscillator (NCO) in Hz
            in_ports (int or list of int): configure downconversion for ports in ``in_ports``
            out_ports (int or list of int): configure upconversion for ports in ``out_ports``
            in_zone: optimize downconversion mixer for operation in the ``in_zone``\ th Nyquist
                band. If :obj:`None` (default), choose appropriate zone automatically
            out_zone: optimize upconversion mixer for operation in the ``out_zone``\ th Nyquist
                band. If :obj:`None` (default), choose appropriate zone automatically
            in_phase: phase of the numerically-controlled oscillator (NCO) in radians for each input port
            out_phase: phase of the numerically-controlled oscillator (NCO) in radians for each output port
            sync: *deprecated since version 2.12.0*, see Notes section below.
            tune: if ``True`` (default), avoid long-term drifts between ports by rounding ``freq``
                so that it is representable exactly by the NCOs in all input and output ports. If
                ``False``, ``freq`` is programmed as-is into the different NCOs and a small
                frequency mismatch (at most 40 μHz) can occur between different channels, leading
                to a slow phase drift (at most 0.8 deg/min).

        Examples:

            >>> from presto.hardware import AdcMode, DacMode
            >>> from presto import lockin
            >>> with lockin.Lockin(adc_mode=AdcMode.Mixed, dac_mode=DacMixed02) as lck:
            >>>     lck.hardware.configure_mixer(
            >>>         freq=3.5e+9,  # 3.5 GHz
            >>>         in_ports=1,
            >>>         out_ports=1,
            >>>     )
            >>>     lck.hardware.configure_mixer(
            >>>         freq=3.6e+9,  # 3.6 GHz
            >>>         out_ports=2,
            >>>     )
            >>>     lck.hardware.configure_mixer(
            >>>         freq=3.7e+9,  # 3.7 GHz
            >>>         out_ports=3,
            >>>     )

        Notes:
            The ``sync`` parameter is deprecated since version 2.12.0. Starting from that version,
            when using the *autoconfiguration* feature all calls to ``configure_mixer`` are handled
            simultaneously at the next call to :meth:`.Lockin.apply_settings` or :meth:`.Pulsed.run`.
            See :ref:`autoconf-sync-mixers`

            On versions prior to 2.12.0, or when not using the *autoconfiguration* feature, the
            behavior of the ``sync`` parameter is as follows: if ``True`` (default), issue a
            :meth:`sync` event to align the phase of the NCO for ``in_ports`` and ``out_ports``.
            When using multiple calls to configure different NCO frequencies on different ports,
            set ``sync=True`` only on the last call to ensure that all NCO phases align.

        See also:
            :meth:`configure_mixer_base_n`: require strict rational relation between different
            frequencies on different ports.
        """
        in_n = None if in_ports is None else 1
        out_n = None if out_ports is None else 1
        self.configure_mixer_base_n(
            base_freq=freq,
            in_n=in_n,
            out_n=out_n,
            in_ports=in_ports,
            out_ports=out_ports,
            in_zone=in_zone,
            out_zone=out_zone,
            in_phase=in_phase,
            out_phase=out_phase,
            sync=sync,
            tune=tune,
        )

    def _configure_mixer_inner(
        self,
        base_MHz: float,  # MHz
        *,
        in_n=[],
        out_n=[],
        in_ports=[],
        out_ports=[],
        in_zone: Optional[int] = None,
        out_zone: Optional[int] = None,
        in_phase: float = 0.0,
        out_phase: float = 0.0,
        sync: bool = True,
        tune: bool = True,
    ):
        if tune:
            # tune to lcm of all NCO sampling rates, so that it's exactly representable by all NCOs
            # NOTE: by when we call _configure_mixer_inner, all DAC config should be finalized so
            # we know all NCO sampling rates
            base_MHz = self._tune_nco_freq(base_MHz)

        for n, in_port in zip(in_n, in_ports):
            freq_MHz = n * base_MHz
            adc_tile = self._port_to_tile(in_port, "adc")
            adc_fsample = self.adc_fsample[adc_tile]
            adc_setup = self.adc_setup[adc_tile]
            adc_nyq = adc_fsample.nyq()

            if in_zone is None:
                in_zone = 1 + int(freq_MHz // adc_nyq)
            else:
                in_zone = int(in_zone)
            self._set_nyquist(in_port, [], in_zone)

            # the XRFDC driver will convert to 1st NZ then truncate
            # we do it here instead so no loss of precision happens
            freq_nco = adc_fsample.fix_freq(freq_MHz, adc_setup, in_zone)

            if in_zone % 2 == 1:  # odd zone
                self._set_nco(in_port, [], -freq_nco, in_phase, sync=False)
            else:  # even zone
                self._set_nco(in_port, [], +freq_nco, in_phase, sync=False)

        for n, out_port in zip(out_n, out_ports):
            freq_MHz = n * base_MHz
            dac_tile = self._port_to_tile(out_port, "dac")
            dac_fsample = self.dac_fsample[dac_tile]
            dac_setup = self.dac_setup[dac_tile]
            dac_nyq = dac_fsample.nyq()
            dac_fs = dac_fsample.fs()

            if out_zone is None:
                # to maximize power, the setting for Nyquist zone is not the same as the actual
                # Nyquist zone!
                # NZ | Setting
                #  1 | 1
                #  2 | 2
                #  3 | 2
                #  4 | 1
                f_rem_nyq = (int(freq_MHz // dac_nyq) % 2) == 1
                f_rem_fs = (int(freq_MHz // dac_fs) % 2) == 1
                if f_rem_nyq ^ f_rem_fs:
                    out_zone = 2
                else:
                    out_zone = 1
            else:
                out_zone = int(out_zone)
            self._set_nyquist([], out_port, out_zone)

            # the XRFDC driver will convert to 1st NZ then truncate
            # we do it here instead so no loss of precision happens
            freq_nco = dac_fsample.fix_freq(freq_MHz, dac_setup, out_zone)

            if out_zone % 2 == 1:  # odd zone
                self._set_nco([], out_port, +freq_nco, out_phase, sync=False)
            else:  # even zone
                self._set_nco([], out_port, -freq_nco, out_phase, sync=False)

            dac_config = _DacConfig(dac_setup, dac_fsample)
            if not dac_config.is_in_range(freq_MHz):
                msg = (
                    f"Frequency {freq_MHz} MHz is outside recommended range for current DAC "
                    f"configuration {dac_config} on tile {dac_tile}. Recommended ranges for this "
                    "configuration are:\n"
                )
                for low, high in dac_config.recommended_range():
                    msg += f"  - from {low} to {high} MHz\n"
                msg += (
                    "Change frequency, or change DAC configuration. See also helper functon "
                    "presto.utils.recommended_dac_config() for help."
                )
                warnings.warn(
                    message=msg,
                    category=UserWarning,
                    stacklevel=2,
                )

        if sync:
            self.sync()

    def _set_nco(self, in_ports, out_ports, freq_MHz: float, phase: float, sync: bool = True):
        in_ports = np.atleast_1d(in_ports).astype(np.int64)
        out_ports = np.atleast_1d(out_ports).astype(np.int64)
        freq = float(freq_MHz) * 1e6
        phase = float(phase)

        for port in np.r_[in_ports, out_ports + 16]:
            channel = port - 1
            self._send_command(cmd.Msg__RfdcSetNCO((channel, freq, phase)))
        if sync:
            self.sync()

    def _set_nyquist(self, in_ports, out_ports, zone: int):
        in_ports = np.atleast_1d(in_ports).astype(np.int64)
        out_ports = np.atleast_1d(out_ports).astype(np.int64)
        zone = int(zone)
        zone = 2 - (zone % 2)  # 1 for odd and 2 for even zones

        for port in np.r_[in_ports, out_ports + 16]:
            channel = port - 1
            self._send_command(cmd.Msg__RfdcNyquist((channel, zone)))

    def set_cal_freeze(self, freeze: bool):
        """
        .. deprecated:: 2.13.0
            Use :meth:`save_cal_coeff` and :meth:`restore_cal_coeff` instead.

        See also:
            :meth:`save_cal_coeff`
            :meth:`restore_cal_coeff`
            :meth:`disable_coeff_override`
        """
        warnings.warn(
            message="set_cal_freeze is deprecated since version 2.13.0, use save_cal_coeff and restore_cal_coeff.",
            category=DeprecationWarning,
            stacklevel=2,
        )
        self._send_command(cmd.Msg__RfdcCalFreeze(freeze))

    def save_cal_coeff(self):
        """Save the current coefficients for the background calibration of the input ports (ADC).

        See also:
            :meth:`restore_cal_coeff`
        """
        self._send_command(cmd.Msg__RfdcCalSave())

    def restore_cal_coeff(self):
        """Restore previously-saved coefficients for the background calibration of the input ports (ADC).

        Note:
            This will disable the background calibration. To re-enable, see :meth:`disable_coeff_override`.

        See also:
            :meth:`save_cal_coeff`
            :meth:`disable_coeff_override`
        """
        self._send_command(cmd.Msg__RfdcCalRestore())

    def _store_factory_adc_calibration(self):
        """Write current ADC calibation to disk as factory calibration.

        :meta private:
        """
        self._send_command(cmd.Msg__RfdcStoreFactoryAdcCal())

    def _load_factory_adc_calibration(self):
        """Load factory ADC calibation from disk.

        :meta private:
        """
        self._send_command(cmd.Msg__RfdcLoadFactoryAdcCal())

    def disable_coeff_override(self):
        """Disable the override on ADC calibration coefficients.

        Note:
            This will re-enable the background calibration, in case it was disabled by :meth:`restore_cal_coeff`.

        See also:
            :meth:`save_cal_coeff`
            :meth:`restore_cal_coeff`
        """
        self._send_command(cmd.Msg__RfdcDisCoeffOverride())

    def get_input_multiband(self, tile: int) -> MultibandMode:
        """Return current multiband configuration on an input tile.

        Args:
            tile: group of ports affected by multiband, valid values are in ``[0, 3]``.
                See :ref:`adv tile` for port grouping.

        See also:
            :meth:`set_input_multiband`
        """
        tile = int(tile)
        if tile not in [0, 1, 2, 3]:
            raise ValueError(f"tile must be in [0, 3], got {tile}")

        self._send_command(cmd.Msg__RfdcGetInMultiBand(tile))
        reply = self._receive(8)
        mode_value = int.from_bytes(reply, byteorder="little", signed=False)
        return MultibandMode(mode_value)

    def set_input_multiband(self, tile: int, mode: MultibandMode):
        """Configure multiband operation on an input tile.

        Args:
            tile: group of ports affected by multiband, valid values are in [0, 3].
                See :ref:`adv tile` for port grouping.
            mode: multiband configuration to enable

        See also:
            :meth:`get_input_multiband`
        """
        tile = int(tile)
        if tile not in [0, 1, 2, 3]:
            raise ValueError(f"tile must be in [0, 3], got {tile}")

        self._send_command(cmd.Msg__RfdcSetInMultiBand((tile, mode.value)))

    def get_output_multiband(self, tile: int) -> MultibandMode:
        """Return current multiband configuration on an output tile.

        Args:
            tile: group of ports affected by multiband, valid values are in ``[0, 3]``.
                See :ref:`adv tile` for port grouping.

        Note:
            Output multiband is currently not supported on Presto-8 hardware.

        See also:
            :meth:`set_output_multiband`
        """
        tile = int(tile)
        if tile not in [0, 1, 2, 3]:
            raise ValueError(f"tile must be in [0, 3], got {tile}")

        self._send_command(cmd.Msg__RfdcGetOutMultiBand(tile))
        reply = self._receive(8)
        mode_value = int.from_bytes(reply, byteorder="little", signed=False)
        return MultibandMode(mode_value)

    def set_output_multiband(self, tile: int, mode: MultibandMode):
        """Configure multiband operation on an output tile.

        Args:
            tile: group of ports affected by multiband, valid values are in ``[0, 3]``.
                See :ref:`adv tile` for port grouping.
            mode: multiband configuration to enable

        Note:
            Output multiband is currently not supported on Presto-8 hardware.

        See also:
            :meth:`get_output_multiband`
        """
        tile = int(tile)
        if tile not in [0, 1, 2, 3]:
            raise ValueError(f"tile must be in [0, 3], got {tile}")

        self._send_command(cmd.Msg__RfdcSetOutMultiBand((tile, mode.value)))

    def set_inv_sinc(self, ports, mode: int):
        """Enable/disable the inverse-sinc FIR filter on the output ports (DAC)

        *The new setting is applied* **immediately**.

        Args:
            ports (int or list of int): output port number
            mode: which FIR filter to use: 0 disables correction; 1 for operation in 1st Nyquist
                zone; 2 for operation in 2nd Nyquist zone (only on Presto hardware)

        Notes:
            Using the inverse-sinc correction can improve gain flatness over frequency, but can
            cause clipping of the output when used at full-scale amplitude. To avoid clipping, it
            is recommended to not drive above -3.5 dBFS when ``mode=1``, and -1.0 dBFS when
            ``mode=2``.
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        mode = int(mode)
        for port in ports:
            channel = port - 1
            self._send_command(cmd.Msg__RfdcSetInvSinc((channel, mode)))

    def set_dac_current(self, ports, current_ua: int):
        """Set the full-scale current of the output ports (DAC)

        Results in changing the analog range of the output.

        *The new setting is applied* **immediately**.

        Args:
            ports (int or list of int): output port number
            current_ua: full-scale current in μA, see Notes for valid values

        Raises:
            ValueError: if ``current_ua`` is out of range

        Notes:
            - On Vivace hardware, valid values are ``20_000`` and ``32_000`` μA.
            - On Presto hardware, valid values range from ``2_250`` to ``40_500`` μA. The provided
              value will be rounded in steps of approximately 43.75 μA.
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        current_ua = int(current_ua)

        if self.board == "zcu111":
            if current_ua not in [20_000, 32_000]:
                raise ValueError(
                    f"invalid DAC current: must be either 20000 or 32000 μA, got {current_ua}"
                )
        else:
            if current_ua < 2_250 or current_ua > 40_500:
                raise ValueError(
                    f"DAC current out of range: must be between 2250 and 40500 μA, got {current_ua}"
                )

        for port in ports:
            channel = port - 1
            self._send_command(cmd.Msg__RfdcSetDacCurrent((channel, current_ua)))

    def set_dac_lownoise(self, ports, low_noise: bool):
        """Optimize DAC output for low-noise or high-linearity operation.

        *The new setting is applied* **immediately**.

        Args:
            ports (int or list of int): output port number
            low_noise: if :obj:`True`, optimize the DAC for low noise (high SNR); if :obj:`False`,
                optimize for high linearity.
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        for port in ports:
            channel = port - 1
            self._send_command(cmd.Msg__RfdcDacLowNoise((channel, low_noise)))

    def set_adc_attenuation(self, ports, attenuation: float):
        """Set the attenuation of the input ports (ADC)

        Results in changing the analog range of the input. Only on Presto hardware.

        *The new setting is applied* **immediately**.

        Args:
            ports (int or list of int): input port number
            attenuation: attenuation in dB, see Notes for valid values

        Raises:
            ValueError: if ``attenuation`` is out of range on Presto hardware
            ValueError: on Vivace hardware

        Notes:
            - On Presto hardware, valid values range from ``0.0`` to ``27.0`` dB. The provided
              value will be rounded in steps of 1.0 dB.
            - On Vivace hardware, this setting is not supported.
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        attenuation = float(attenuation)

        if self.board == "zcu111":
            raise ValueError("ADC attenuation not supported on Vivace hardware")
        else:
            if attenuation < 0.0 or attenuation > 27.0:
                raise ValueError(
                    f"ADC attenuation out of range: must be between 0 and 27 dB, got {attenuation}"
                )

        for port in ports:
            channel = port - 1
            self._send_command(cmd.Msg__RfdcSetDSA((channel, attenuation)))

    def get_input_delay(self, port: int) -> int:
        """Retrieve the digital delay programmed on an input port.

        Args:
            port: input port number

        Returns:
            delay in units of ADC sampling clock

        See also:
            :meth:`set_input_delay`
            :meth:`get_output_delay`
        """
        port = int(port)
        channel = port - 1
        self._send_command(cmd.Msg__RfdcGetDelay(channel))
        reply = self._receive(8)
        delay = int.from_bytes(reply, byteorder="little", signed=False)
        return delay

    def get_output_delay(self, port: int) -> int:
        """Retrieve the digital delay programmed on an output port.

        Args:
            port: output port number

        Returns:
            delay in units of DAC sampling clock

        See also:
            :meth:`set_output_delay`
            :meth:`get_input_delay`
        """
        port = int(port)
        channel = port - 1
        self._send_command(cmd.Msg__RfdcGetDelay(channel + 16))
        reply = self._receive(8)
        delay = int.from_bytes(reply, byteorder="little", signed=False)
        return delay

    def set_input_delay(self, port: int, delay: int):
        """Program a digital delay on an input port.

        *The new setting is applied after a call to* :meth:`sync`

        Args:
            port: input port number
            delay: delay in units of ADC sampling clock, see Notes

        Notes:
            The digital delay is expressed in units of the period *Ts* of the ADC sampling clock.
            For example, when using ``adc_fsample=AdcFSample.G4`` the sampling clock is at 4 GS/s
            and has a period of 250 ps. Setting ``delay=7`` then corresponds to a delay of 1.75 ns.

        Examples:
            With the input ADC running at 4 GS/s, the input delay is set in multiples of 1/4 ns:

            >>> with pulsed.Pulsed(adc_fsample=AdcFSample.G4) as pls:  # 4 GS/s sampling rate
            >>>     pls.hardware.set_input_delay(port=1, delay=0)  # no delay
            >>>     pls.hardware.set_input_delay(port=2, delay=3)  # 0.75 ns
            >>>     pls.hardware.set_input_delay(port=3, delay=6)  # 1.50 ns
            >>>     pls.hardware.set_input_delay(port=4, delay=7)  # 1.75 ns
            >>>     pls.hardware.sync()  # <-- apply the delay settings

        See also:
            :meth:`get_input_delay`
            :meth:`set_output_delay`
        """
        port = int(port)
        delay = int(delay)
        channel = port - 1
        self._send_command(cmd.Msg__RfdcSetDelay((channel, delay)))

    def set_output_delay(self, port: int, delay: int):
        """Program a digital delay on an output port.

        *The new setting is applied after a call to* :meth:`sync`

        Args:
            port: output port number
            delay: delay in units of DAC sampling clock, see Notes

        Notes:
            The digital delay is expressed in units of the period *Ts* of the DAC sampling clock.
            For example, when using ``dac_fsample=DacFSample.G10`` the sampling clock is at 10 GS/s
            and has a period of 100 ps. Setting ``delay=7`` then corresponds to a delay of 700 ps.

        Examples:
            With the output DAC running at 6 GS/s, the output delay is set in multiples of 1/6 ns:

            >>> with pulsed.Pulsed(dac_fsample=DacFSample.G6) as pls:  # 6 GS/s sampling rate
            >>>     pls.hardware.set_output_delay(port=1, delay=0)  # no delay
            >>>     pls.hardware.set_output_delay(port=2, delay=3)  # 0.5 ns
            >>>     pls.hardware.set_output_delay(port=3, delay=6)  # 1.0 ns
            >>>     pls.hardware.set_output_delay(port=4, delay=7)  # 7/6 ns
            >>>     pls.hardware.sync()  # <-- apply the delay settings

        See also:
            :meth:`get_output_delay`
            :meth:`set_input_delay`
        """
        port = int(port)
        delay = int(delay)
        channel = port - 1
        self._send_command(cmd.Msg__RfdcSetDelay((channel + 16, delay)))

    def default_config(self):
        self._send_command(cmd.Msg__RfdcDefaultConfig())

    def blank_output(self, ports, state: bool):
        """Disable the output port(s). Has no effect on the DC bias.

        *The new setting is applied* **immediately**.

        Args:
            ports (int or list of int): Output ports to enable/disable
            state: When :obj:`True`, disable the RF output.
        """
        ports = np.atleast_1d(ports).astype(np.int64)
        for port in ports:
            channel = port - 1
            self._send_command(cmd.Msg__TestBlank((channel, state)))

    def _validate_adc_dac_mode(
        self,
        adc_mode: Union[AdcMode, List[AdcMode]],
        dac_mode: Union[DacMode, List[DacMode]],
    ) -> Tuple[List[AdcMode], List[DacMode]]:
        adc_mode = as_flat_list(adc_mode)
        dac_mode = as_flat_list(dac_mode)

        for elem in adc_mode:
            if not isinstance(elem, AdcMode):
                raise TypeError(f"adc_mode must be of type AdcMode, got {type(elem)}")
        for elem in dac_mode:
            if not isinstance(elem, DacMode):
                raise TypeError(f"dac_mode must be of type DacMode, got {type(elem)}")

        if len(adc_mode) == 1:
            adc_mode = [adc_mode[0]] * 4
        elif len(adc_mode) != 4:
            raise ValueError(
                "expected either 1 (all tile the same) or 4 (one per tile) values for adc_mode"
            )

        if len(dac_mode) == 1:
            dac_mode = [dac_mode[0]] * 4
        elif len(dac_mode) != 4:
            raise ValueError(
                "expected either 1 (all tile the same) or 4 (one per tile) values for dac_mode"
            )

        # only support either all tiles Direct or all tiles Mixed
        # ADC and DAC can be different
        # different types of Mixed (DAC gen3) are fine
        if 0 < sum([mode is AdcMode.Direct for mode in adc_mode]) < 4:
            raise NotImplementedError(
                "all ADC tiles must be configured with the same mode (all Direct or all Mixed)"
            )
        if 0 < sum([mode is DacMode.Direct for mode in dac_mode]) < 4:
            raise NotImplementedError(
                "all DAC tiles must be configured with the same mode type"
                " (all Direct, all Mixed (auto), or any combination of MixedXX)"
            )
        if 0 < sum([mode is DacMode.Mixed for mode in dac_mode]) < 4:
            raise NotImplementedError(
                "all DAC tiles must be configured with the same mode type"
                " (all Direct, all Mixed (auto), or any combination of MixedXX)"
            )

        return (adc_mode, dac_mode)

    def _validate_adc_fsample(
        self, adc_fsample: Union[AdcFSample, List[AdcFSample]]
    ) -> List[AdcFSample]:
        adc_fsample = as_flat_list(adc_fsample)

        for elem in adc_fsample:
            if not isinstance(elem, AdcFSample):
                raise TypeError(f"adc_fsample must be of type AdcFSample, got {type(elem)}")

        if len(adc_fsample) == 1:
            adc_fsample = [adc_fsample[0]] * 4
        elif len(adc_fsample) != 4:
            raise ValueError(
                "expected either 1 (all tile the same) or 4 (one per tile) values for adc_fsample"
            )

        if 0 < sum([fsample is AdcFSample.G3_2 for fsample in adc_fsample]) < 4:
            raise NotImplementedError(
                "if adc_fsample=AdcFSample.G3_2 on one tile, then all ADC tiles must use it"
            )

        return adc_fsample

    def _validate_dac_fsample(
        self,
        dac_fsample: Union[DacFSample, List[DacFSample]],
        dac_mode: List[DacMode],
        force_config: bool,
    ) -> List[DacFSample]:
        dac_fsample = as_flat_list(dac_fsample)

        for elem in dac_fsample:
            if not isinstance(elem, DacFSample):
                raise TypeError(f"dac_fsample must be of type DacFSample, got {type(elem)}")

        if len(dac_fsample) == 1:
            dac_fsample = [dac_fsample[0]] * 4
        elif len(dac_fsample) != 4:
            raise ValueError(
                "expected either 1 (all tile the same) or 4 (one per tile) values for dac_fsample"
            )

        if 0 < sum([fsample is DacFSample.G6_4 for fsample in dac_fsample]) < 4:
            raise NotImplementedError(
                "if dac_fsample=DacFSample.G6_4 on one tile, then all DAC tiles must use it"
            )

        if not force_config:
            for setup, fsample in zip(dac_mode, dac_fsample):
                if (fsample.value > DacFSample.G6_4.value) and (
                    setup.value < DacMode.Mixed04.value
                ):
                    raise ValueError(
                        f"{setup} is not recommended for sampling rates above 7 GS/s, "
                        f"use {DacMode.Mixed04} or {DacMode.Mixed42} instead. "
                        "To ignore this error and preceed anyway, pass the argument force_config=True."
                    )

        return dac_fsample

    def validate_config(
        self,
        adc_mode: Union[AdcMode, List[AdcMode]],
        adc_fsample: Optional[Union[AdcFSample, List[AdcFSample]]],
        dac_mode: Union[DacMode, List[DacMode]],
        dac_fsample: Optional[Union[DacFSample, List[DacFSample]]],
        force_config: bool = False,
    ) -> Tuple[List[AdcMode], List[AdcFSample], List[DacMode], List[DacFSample]]:
        adc_mode, dac_mode = self._validate_adc_dac_mode(adc_mode, dac_mode)
        if dac_mode[0] is DacMode.Mixed:
            if dac_fsample is not None:
                raise NotImplementedError(
                    "when using the automatic dac_mode=DacMode.Mixed, only the automatic "
                    "dac_fsample=None is supported. Either set dac_fsample to None to let the API "
                    "choose the best settings for you, or manually set dac_mode to one of "
                    "DacMode.Mixed02, DacMode.Mixed04 or DacMode.Mixed42."
                )

        if adc_fsample is not None:
            adc_fsample = self._validate_adc_fsample(adc_fsample)
            if dac_fsample is None and adc_fsample[0] is AdcFSample.G3_2:
                # it has to be G6_4
                dac_fsample = [DacFSample.G6_4] * 4

        if dac_fsample is not None:
            dac_fsample = self._validate_dac_fsample(dac_fsample, dac_mode, force_config)
            if adc_fsample is None and dac_fsample[0] is DacFSample.G6_4:
                # it has to be G3_2
                adc_fsample = [AdcFSample.G3_2] * 4
        else:
            if dac_mode[0] not in [DacMode.Direct, DacMode.Mixed]:
                raise NotImplementedError(
                    "when using the automatic dac_fsample=None, only the automatic dac_mode=Mixed "
                    "is supported. Either set dac_mode to DacMode.Mixed to let the API choose the "
                    "best settings for you, or manually set dac_fsample to one of the "
                    "DacFSample.Gx values."
                )

        if adc_fsample is not None and dac_fsample is not None:
            if (AdcFSample.G3_2 in adc_fsample) ^ (DacFSample.G6_4 in dac_fsample):
                raise NotImplementedError(
                    "adc_fsample=AdcFSample.G3_2 and dac_fsample=DacFSample.G6_4 must be used together"
                )

        # first check if we need to perform automatic configuration
        # then start with a reasonable default

        if adc_fsample is None:
            # just choose G4 if possible, else G2
            if self.board == "zcu216":
                adc_fsample = [AdcFSample.G2] * 4
            else:
                adc_fsample = [AdcFSample.G4] * 4

        if dac_fsample is None:
            # start with default choice
            if self.board == "zcu111":
                dac_fsample = [DacFSample.G4] * 4
            else:
                dac_fsample = [DacFSample.G6] * 4
            # this choice is final if DacMode.Direct
            # otherwise if DacMode.Mixed see next if

        if dac_mode[0] is DacMode.Mixed:
            # choose automatically between Mixed02, Mixed04 and Mixed42
            # choose automatically best sampling rate
            dac_mode = [DacMode.Mixed02] * 4
            if self.board == "zcu111":
                # there's no choice here
                self.dac_autoconfig = False
            else:
                self.dac_autoconfig = True
        else:
            self.dac_autoconfig = False

        self._defer_mixer_config = self.dac_autoconfig

        # save (temporary) results
        self.adc_setup = adc_mode
        self.adc_fsample = adc_fsample
        self.dac_setup = dac_mode
        self.dac_fsample = dac_fsample

        return (adc_mode, adc_fsample, dac_mode, dac_fsample)

    def will_autoconfig(self) -> bool:
        return self.dac_autoconfig

    def _find_score(self, configs: List[Tuple[_DacConfig, float]], config: _DacConfig) -> float:
        for conf, score in configs:
            if conf == config:
                return score
        return 0.0

    def _intersection(
        self,
        configs1: List[Tuple[_DacConfig, float]],
        configs2: List[Tuple[_DacConfig, float]],
    ) -> List[Tuple[_DacConfig, float]]:
        ret = []
        for conf, score1 in configs1:
            score2 = self._find_score(configs2, conf)
            if score2 > 0.0:
                score = score1 * score2 / (score1 + score2)
                ret.append((conf, score))
        return ret

    def _autoconfig(self):
        nr_tiles = self._nr_tiles("dac")
        blocks_per_tile = self._blocks_per_tile("dac")
        for i in range(nr_tiles):
            tile_used = False
            possible_configs = []

            for j in range(blocks_per_tile):
                port = i * blocks_per_tile + j + 1
                if port not in self._mixer_dac:
                    continue
                else:
                    if not tile_used:
                        tile_used = True
                        _, possible_configs = self._mixer_dac[port]
                    else:
                        _, new_configs = self._mixer_dac[port]
                        possible_configs = self._intersection(possible_configs, new_configs)

            if tile_used:
                if len(possible_configs) == 0:
                    port_min = i * blocks_per_tile + 1
                    port_max = port_min + blocks_per_tile - 1
                    msg = (
                        f"could not find suitable DAC configuration for tile {i} (ports {port_min}"
                        f"-{port_max}) due to conflicting requirements between ports."
                    )
                    raise RuntimeError(msg)
                possible_configs.sort(key=lambda x: x[1], reverse=True)
                best_config = possible_configs[0][0]
                self.dac_setup[i] = best_config.setup
                self.dac_fsample[i] = best_config.fsample
            else:
                pass  # nothing to do

    def setup_config(self, do_sync: bool = True):
        if self.dac_autoconfig:
            self._autoconfig()

        adc_mask = 0
        dac_mask = 0
        for i in range(4):
            adc_mask |= self.adc_setup[i].value << (i * 16)
            adc_mask |= self.adc_fsample[i].value << (i * 16 + 8)
            dac_mask |= self.dac_setup[i].value << (i * 16)
            dac_mask |= self.dac_fsample[i].value << (i * 16 + 8)

        # RFDC config + MTS (calibrated) + load factory ADC calibration (if available)
        self._send_command(
            cmd.Msg__RfdcConfigure(
                (
                    adc_mask,
                    dac_mask,
                    self.adc_bus_width,
                    self.dac_bus_width,
                    self.adc_fab_rate,
                    self.dac_fab_rate,
                )
            )
        )

        if self._defer_mixer_config:
            need_sync = False
            for port, sett in self._mixer_adc.items():
                self._configure_mixer_inner(
                    sett.base_MHz,
                    in_n=[sett.n],
                    in_ports=[port],
                    in_phase=sett.phase,
                    in_zone=sett.zone,
                    sync=False,
                    tune=sett.tune,
                )
                need_sync = True
            for port, (sett, _) in self._mixer_dac.items():
                self._configure_mixer_inner(
                    sett.base_MHz,
                    out_n=[sett.n],
                    out_ports=[port],
                    out_phase=sett.phase,
                    out_zone=sett.zone,
                    sync=False,
                    tune=sett.tune,
                )
                need_sync = True
            if do_sync and need_sync:
                self.sync()
            self._mixer_adc = {}
            self._mixer_dac = {}

        self._apply_required_rf = False

    def start_dma(self, dma_idx: int, nr_bytes: int, nr_cycles: int = 1, high_mem: bool = False):
        dma_idx = int(dma_idx)
        nr_bytes = int(nr_bytes)
        nr_cycles = int(nr_cycles)
        high_mem = bool(high_mem)
        self._send_command(cmd.Msg__PrestoDmaStart((dma_idx, nr_bytes, nr_cycles, high_mem)))

    def wait_for_dma(self, dma_idx: int, wait: bool = True):
        dma_idx = int(dma_idx)
        self._send_command(cmd.Msg__PrestoDmaWait(dma_idx))

        if wait:
            # send an echo command and wait for answer
            self._echo(42)

    def stop_dma(self, dma_idx: int):
        dma_idx = int(dma_idx)
        self._send_command(cmd.Msg__PrestoDmaStop(dma_idx))

    def get_dma_status(self, dma_idx: int) -> Tuple[bool, bool, int]:
        dma_idx = int(dma_idx)
        self._send_command(cmd.Msg__PrestoDmaStatus(dma_idx))
        reply = self._receive(8)
        status = int.from_bytes(reply, byteorder="little", signed=False)
        done = (status >> 63) & 1 == 1
        error = (status >> 62) & 1 == 1
        nr_bytes = status & 0xFFFFFFFFFFFF
        return (done, error, nr_bytes)

    def get_dma_data(
        self, nr_bytes: int, high_mem: bool = False, compression: bool = False
    ) -> bytearray:
        nr_bytes = int(nr_bytes)
        high_mem = bool(high_mem)
        compression = bool(compression)
        self._send_command(cmd.Msg__PrestoDmaGet((nr_bytes, high_mem, compression)))
        # receive confirmation the server is waiting for a connection
        reply = self._receive(8)
        assert 35 == int.from_bytes(reply, byteorder="little", signed=False)

        with self._new_connection() as sock:
            if compression:
                reply = self._receive_from_compressed(nr_bytes, sock)
            else:
                reply = self._receive_from(nr_bytes, sock)

        return reply

    def clear_dma(self, nr_bytes: int):
        self._send_command(cmd.Msg__PrestoDmaClear(nr_bytes))

    def _new_connection(self) -> socket.socket:
        assert self.sock is not None
        peername = self.sock.getpeername()
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect(peername)
        return sock

    def stream_dma_data(
        self, dma_idx: int, nr_bytes: int, high_mem: bool
    ) -> Tuple[threading.Thread, bytearray]:
        assert self.sock is not None

        dma_idx = int(dma_idx)
        nr_bytes = int(nr_bytes)
        high_mem = bool(high_mem)
        self._send_command(cmd.Msg__PrestoStreamDma((dma_idx, nr_bytes, high_mem)))
        # receive confirmation the server is waiting for a connection
        reply = self._receive(8)
        assert 35 == int.from_bytes(reply, byteorder="little", signed=False)

        def _thread(nr_bytes: int, buf: bytearray):
            with self._new_connection() as sock:
                self._receive_from_into(nr_bytes, sock, buf)

        buf = bytearray(nr_bytes)
        thread = threading.Thread(
            target=_thread,
            args=(nr_bytes, buf),
        )
        thread.start()
        return thread, buf

    def start_histogram(self, dma_idx: int, nr_bytes: int, high_mem: bool, res_b: int, tag: int):
        dma_idx = int(dma_idx)
        nr_bytes = int(nr_bytes)
        high_mem = bool(high_mem)
        res_b = int(res_b)
        tag = int(tag)
        self._send_command(cmd.Msg__PrestoHistBuild((dma_idx, nr_bytes, high_mem, res_b, tag)))

    def get_histogram(self):
        assert self.sock is not None

        self._send_command(cmd.Msg__PrestoHistGet())
        # receive confirmation the server is waiting for a connection
        reply = self._receive(8)
        assert 35 == int.from_bytes(reply, byteorder="little", signed=False)

        with self._new_connection() as sock:
            reply = self._receive_from(8, sock)
            N = int.from_bytes(reply, byteorder="little", signed=False)
            buf = np.zeros((2, N), np.int64)
            for i in range(N):
                reply = self._receive_from(4, sock)
                key = int.from_bytes(reply, byteorder="little", signed=True)
                buf[0, i] = key
                reply = self._receive_from(4, sock)
                val = int.from_bytes(reply, byteorder="little", signed=False)
                buf[1, i] = val

        return buf

    def start_histogram_2d(
        self, dma_idx: int, nr_bytes: int, high_mem: bool, res_b: int, tag1: int, tag2: int
    ):
        dma_idx = int(dma_idx)
        nr_bytes = int(nr_bytes)
        high_mem = bool(high_mem)
        res_b = int(res_b)
        tag1 = int(tag1)
        tag2 = int(tag2)
        self._send_command(
            cmd.Msg__PrestoHist2DBuild((dma_idx, nr_bytes, high_mem, res_b, tag1, tag2))
        )

    def get_histogram_2d(self):
        assert self.sock is not None

        self._send_command(cmd.Msg__PrestoHist2DGet())
        # receive confirmation the server is waiting for a connection
        reply = self._receive(8)
        assert 35 == int.from_bytes(reply, byteorder="little", signed=False)

        with self._new_connection() as sock:
            reply = self._receive_from(8, sock)
            N = int.from_bytes(reply, byteorder="little", signed=False)
            buf = np.zeros((3, N), np.int64)
            for i in range(N):
                reply = self._receive_from(4, sock)
                key0 = int.from_bytes(reply, byteorder="little", signed=True)
                buf[0, i] = key0
                reply = self._receive_from(4, sock)
                key1 = int.from_bytes(reply, byteorder="little", signed=True)
                buf[1, i] = key1
                reply = self._receive_from(4, sock)
                val = int.from_bytes(reply, byteorder="little", signed=False)
                buf[2, i] = val

        return buf

    def get_ocm_status(self) -> Tuple[bool, int]:
        self._send_command(cmd.Msg__PrestoOcmError())
        reply = self._receive(8)
        status = int.from_bytes(reply, byteorder="little", signed=False)
        done = bool(status & 1)
        error = status & ~1
        return (done, error)

    def _write_raw_dc(self, word: int):
        word = int(word)
        self._send_command(cmd.Msg__PrestoDcRaw(word))

    def _write_raw_ioe(self, word: int):
        word = int(word)
        self._send_command(cmd.Msg__PrestoIoeRaw(word))

    def _read_dc_word(self) -> int:
        self._send_command(cmd.Msg__PrestoDcReadback())
        reply = self._receive(8)
        word = int.from_bytes(reply, byteorder="little", signed=False)
        return word

    def _get_marker_in(self) -> int:
        self._send_command(cmd.Msg__PrestoMarkerIn())
        reply = self._receive(8)
        return int.from_bytes(reply, byteorder="little", signed=False)

    def _set_marker_out(self, mask: int):
        mask = int(mask)
        self._send_command(cmd.Msg__PrestoMarkerOut(mask))

    @staticmethod
    def _dc_max_min(range_i: int) -> Tuple[float, float]:
        if range_i == 0:
            max_bias = 10.0 / 3.0
            min_bias = 0.0
        elif range_i == 1:
            max_bias = 20.0 / 3.0
            min_bias = 0.0
        elif range_i == 2:
            max_bias = 10.0 / 3.0
            min_bias = -max_bias
        elif range_i == 3:
            max_bias = 20.0 / 3.0
            min_bias = -max_bias
        elif range_i == 4:
            max_bias = 10.0
            min_bias = -max_bias
        elif range_i == 0xFF:  # zcu111
            max_bias = 1.0
            min_bias = -max_bias
        else:
            raise ValueError(f"unknown range setting: {range_i}")

        return (max_bias, min_bias)

    def set_dc_bias(self, bias: float, port, range_i: Optional[int] = None):
        """Set a DC bias on the output ports.

        *The new setting is applied* **immediately**.

        Args:
            bias: DC bias value. Must be within the selected range.
            port (int or array_like): Output port, if :obj:`None` set DC bias for all ports.
                See Notes for valid ports.
            range_i: Range setting for DC bias DAC. On Vivace hardware this setting is ignored and
                the selected range is always ±1.0 FS. On Presto hardware, the default behavior is
                to auto-select an appropriate range based on the value of ``bias``. See Notes for
                other available options.

        Raises:
            ValueError: If ``bias`` or ``port`` are outside valid range.

        Notes:
            On Vivace hardware, the DC bias is applied to the RF output ports by means of a
            internal bias tees; as such, valid values for ``port`` are in the interval ``[1,8]``.
            On Presto hardware, DC bias is provided from the dedicated DC output ports on the front
            panel; valid values for ``port`` are then in the interval ``[1,16]`` regardless of the
            available number of RF outputs.

            On Presto hardware, there are 5 available range settings:

            ===========  ============
            ``range_i``  Analog range
            ===========  ============
            0            0V — 3.33V
            1            0V — 6.67V
            2            ±3.33V
            3            ±6.67V
            4            ±10.0V
            ===========  ============

            When selecting ``range_i=None`` (default), the API will choose the smallest bipolar
            range (2, 3 or 4) such that ``bias`` is at most 90% of the range.

            When changing range, voltage transients of about 0.5 V can appear at the output for
            about 1 us.

        Examples:

            >>> from presto import lockin
            >>> with lockin.Lockin() as lck:
            >>>     lck.hardware.set_dc_bias(
            >>>         bias=5.0,  # 5V
            >>>         port=[5, 6, 7, 8],  # update 4 ports simultaneously
            >>>         range_i=None,  # auto-select range_i=3, i.e. ±6.67V
            >>>     )
            >>>     lck.hardware.set_dc_bias(
            >>>         bias=-2.0,  # -2V
            >>>         port=1,
            >>>         range_i=4,  # manually select range_i=4, i.e. ±10.0V
            >>>     )

        See also:
            :meth:`get_dc_bias`
            :meth:`ramp_dc_bias`
        """
        bias = float(bias)
        if self.board == "zcu111":
            range_i = 0xFF
            max_port = 8
        else:
            max_port = 16
            if range_i is None:
                if abs(bias) <= 3.0:
                    range_i = 2
                elif abs(bias) <= 6.0:
                    range_i = 3
                else:
                    range_i = 4
            else:
                range_i = int(range_i)

        (max_bias, min_bias) = self._dc_max_min(range_i)

        if bias > max_bias or bias < min_bias:
            raise ValueError(f"bias must be in [{min_bias:.2f},{max_bias:.2f}], got {bias}")

        if port is None:
            port = np.arange(1, max_port + 1)
        else:
            port = asarray(port, np.int64)
            if np.any(port < 1) or np.any(port > max_port):
                raise ValueError(f"port must be in [1, {max_port}], got {port}")

        channel_mask = 0
        for p in port:
            ch = int(p - 1)
            channel_mask |= 1 << ch
            self._dc_range[ch + 1] = (min_bias, max_bias)

        self._send_command(cmd.Msg__PrestoDcBias((channel_mask, bias, range_i)))

    def ramp_dc_bias(self, bias: float, port, rate: float):
        """Ramp the output DC bias from the current voltage to a new voltage with a specified rate
        of change.

        Args:
            bias: Target DC bias value. Must be within the previously selected range.
            port (int or array_like): Output port, if :obj:`None` set DC bias for all ports.
                See Notes in :meth:`set_dc_bias` for valid ports.
            rate: The rate in V/s at which the bias should change from the current value to the new
                one.

        Raises:
            ValueError: If ``bias`` or ``port`` are outside valid range; if ``rate`` is zero; if
            current range is not equal on all ports in ``port``.

        Notes:
            When ramping multiple ports from different initial DC bias, all ports will reach the
            final ``bias`` at the same time. This means that the ports will ramp at different
            rates. In this case, ``rate`` sets the fastest rate, i.e. the rate for the port with
            the largest requested change in DC bias.

        Examples:

            >>> from presto import lockin
            >>> with lockin.Lockin() as lck:
            >>>     # set a bias of -2 V with range ±10.0 V
            >>>     # active immediately
            >>>     lck.hardware.set_dc_bias(
            >>>         bias=-2.0,  # -2 V
            >>>         port=1,
            >>>         range_i=4,  # ±10.0V
            >>>     )
            >>>     # slowly ramp bias voltage from -2 V to +2 V in 8 seconds
            >>>     lck.hardware.ramp_dc_bias(
            >>>             bias=+2.0,  # +2 V
            >>>             port=1,
            >>>             rate=0.5,  # 0.5 V/s
            >>>     )

        See also:
            :meth:`set_dc_bias`
            :meth:`get_dc_bias`
        """
        if self.board == "zcu111":
            max_port = 8
        else:
            max_port = 16

        bias = float(bias)
        if port is None:
            port = np.arange(1, max_port + 1)
        else:
            port = np.atleast_1d(port).astype(np.int64)
            if np.any(port < 1) or np.any(port > max_port):
                raise ValueError(f"port must be in [1, {max_port}], got {port}")

        rate = abs(float(rate))
        if rate == 0.0:
            raise ValueError("rate must be positive")

        if self.board == "zcu111":
            range_i = 0xFF
        else:
            ranges = [self.get_dc_bias(p, True)[1] for p in port]  # type: ignore
            if np.any(np.array(ranges) != ranges[0]):
                raise ValueError(
                    "All ports must be configured to the same range. "
                    f"Current ranges on ports {port} are {ranges}. "
                    "You may want to change the current ranges with set_dc_bias."
                )
            range_i = ranges[0]

        (max_bias, min_bias) = self._dc_max_min(range_i)
        if bias > max_bias or bias < min_bias:
            raise ValueError(
                f"bias must be in [{min_bias:.2f},{max_bias:.2f}], got {bias}. "
                "You may want to change the current range with set_dc_bias."
            )

        channel_mask = 0
        for p in port:
            ch = int(p - 1)
            channel_mask |= 1 << ch

        self._send_command(cmd.Msg__PrestoDcBiasRamp((channel_mask, bias, rate)))

    @overload
    def get_dc_bias(self, port: int) -> float: ...

    @overload
    def get_dc_bias(self, port: int, get_range: Literal[False]) -> float: ...

    @overload
    def get_dc_bias(self, port: int, get_range: Literal[True]) -> Tuple[float, int]: ...

    @overload
    def get_dc_bias(self, port: int, get_range: bool) -> Union[float, Tuple[float, int]]: ...

    def get_dc_bias(self, port: int, get_range: bool = False) -> Union[float, Tuple[float, int]]:
        """Get the DC bias programmed on the output ports.

        Args:
            port: Output port. See Notes in :meth:`set_dc_bias` for valid ports.
            get_range: If ``True``, return also the current range ``range_i``.

        Returns:
            The return value depends on the optional ``get_range`` parameter.

            * if ``get_range=False`` (default), returns:

                * ``bias``: The DC bias currently set in units of volts (V) on Presto hardware,
                    or in full-scale units (FS) on Vivace hardware.

            * if ``get_range=True``, return a tuple containing:

                * ``bias``: like above
                * ``range_i``: The range currently set, only present if ``get_range=True``.
                    See :meth:`set_dc_bias` for available ranges.

        Raises:
            ValueError: If ``port`` is outside valid range.

        See also:
            :meth:`set_dc_bias`
            :meth:`ramp_dc_bias`
        """
        port = int(port)
        if self.board == "zcu111":
            max_port = 8
        else:
            max_port = 16
        if port < 1 or port > max_port:
            raise ValueError(f"port must be in [1, {max_port}], got{port}")
        channel = port - 1
        self._send_command(cmd.Msg__PrestoDcGetBias(channel))
        reply = self._receive(9)
        (bias, range_i) = struct.unpack("<dB", reply)

        if get_range:
            return bias, range_i
        else:
            return bias

    def last_dc_range(self, port: int) -> Tuple[float, float]:
        return self._dc_range[port]  # raise KeyError if key port is missing

    def _check_version_conductor(self):
        ver_hw = parse(self._get_conductor_version_legacy())
        ver_api = parse(version_conductor)
        if ver_hw != ver_api:
            msg = (
                "version mismatch!\n"
                "The Presto API currently installed on this computer is not compatible\n"
                "with the firmware running on the Presto hardware:\n"
                f"  - required by current API: conductor v{ver_api}\n"
                f"  - installed on hardware:   conductor v{ver_hw}\n"
            )
            if ver_hw > ver_api:
                msg += "Please consider updating the Presto API on this computer."
            else:
                msg += "Please consider updating the firmware on the Presto hardware."
            raise RuntimeError(msg)

    def _check_version_rpu(self):
        ver_hw = parse(self.get_rpu_version())
        ver_api = parse(version_rpu)
        if ver_hw != ver_api:
            msg = (
                "version mismatch!\n"
                "The Presto API currently installed on this computer is not compatible\n"
                "with the firmware running on the Presto hardware:\n"
                f"  - required by current API: rpu v{ver_api}\n"
                f"  - installed on hardware:   rpu v{ver_hw}\n"
            )
            if ver_hw > ver_api:
                msg += "Please consider updating the Presto API on this computer."
            else:
                msg += "Please consider updating the firmware on the Presto hardware."
            raise RuntimeError(msg)

    def _check_version_fw(self, ver_hw: Optional[int] = None):
        if ver_hw is None:
            ver_hw = self.get_var_ver()[1]
        ver_api = version_fpga
        if ver_hw != ver_api:
            msg = (
                "version mismatch!\n"
                "The Presto API currently installed on this computer is not compatible\n"
                "with the firmware running on the Presto hardware:\n"
                f"  - required by current API: PL fw v{ver_api}\n"
                f"  - installed on hardware:   PL fw v{ver_hw}\n"
            )
            if ver_hw > ver_api:
                msg += "Please consider updating the Presto API on this computer."
            else:
                msg += "Please consider updating the firmware on the Presto hardware."
            raise RuntimeError(msg)

    def _get_conductor_version_legacy(self) -> str:
        assert self.sock is not None
        message = b"\x10\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00"
        self.sock.sendall(message)
        reply = self._receive(8)
        nr_bytes = int.from_bytes(reply, byteorder="little", signed=False)
        reply = self._receive(nr_bytes)
        return reply.decode("utf-8")

    def get_conductor_version(self) -> str:
        self._send_command(cmd.Msg__Version())
        reply = self._receive(8)
        nr_bytes = int.from_bytes(reply, byteorder="little", signed=False)
        reply = self._receive(nr_bytes)
        return reply.decode("utf-8")

    def get_rpu_version(self) -> str:
        self._send_command(cmd.Msg__PrestoRpuVer())
        reply = self._receive(8)
        nr_bytes = int.from_bytes(reply, byteorder="little", signed=False)
        reply = self._receive(nr_bytes)
        return reply.decode("utf-8")

    def get_errors(self) -> List[str]:
        """Get error messages, if any, from the hardware.

        Returns:
            a list of error messages. If there's no error, returns an empty list.

        See also:
            :meth:`assert_errors`
        """
        assert self._echo(42) == 42  # send echo command to wait for all errors to propagate
        self._send_command(cmd.Msg__ErrorList())
        errors = []
        nr_bytes = int.from_bytes(self._receive(8), byteorder="little", signed=False)
        while nr_bytes > 0:
            errors.append(self._receive(nr_bytes).decode("utf-8"))
            nr_bytes = int.from_bytes(self._receive(8), byteorder="little", signed=False)
        return errors

    def format_errors(self) -> str:
        """Format error messages from the hardware, ready for printing.

        Returns:
            a formatted string containing the errors, or an empty string.

        See also:
            :meth:`get_errors`
            :meth:`assert_errors`
        """
        errors = self.get_errors()
        msg = []
        if errors:
            msg.append(f"\x1b[1;31m{' SERVER ERROR ':-^80}\x1b[0m")
            for err in errors:
                msg.append(err)
            msg.append(f"\x1b[1;31m{'':-^80}\x1b[0m")
            msg_txt = "\n".join(msg)
            return msg_txt
        else:
            return ""

    def assert_errors(self):
        """Print errors from the hardware and raise an exception if there were any.

        Raises:
            RuntimeError: if any error has occurred

        See also:
            :meth:`get_errors`
        """
        errors = self.format_errors()
        if errors:
            raise RuntimeError(f"got errors from the hardware, check the log below.\n{errors:s}")

    def get_board_name(self) -> str:
        self._send_command(cmd.Msg__WhichBoard())
        reply = self._receive(8)
        nr_bytes = int.from_bytes(reply, byteorder="little", signed=False)
        reply = self._receive(nr_bytes)
        return reply.decode("utf-8")

    def get_intr_status(self) -> int:
        self._send_command(cmd.Msg__IntrStatus())
        reply = self._receive(8)
        return int.from_bytes(reply, byteorder="little", signed=False)

    def check_adc_intr_status(self):
        status = self.get_intr_status()
        if status > 0:
            print_adc_intr_status(status, all_=False, color=True)

    def intr_clr(self):
        self._send_command(cmd.Msg__IntrClr())

    def temperature_fpga(self) -> float:
        self._send_command(cmd.Msg__TempFpga())

        # get temperature as string
        reply = self._receive(8)
        nr_bytes = int.from_bytes(reply, byteorder="little", signed=False)
        reply = self._receive(nr_bytes)
        string = reply.decode("utf-8")
        return float(string)

    def current_vccint(self) -> float:
        self._send_command(cmd.Msg__CurrVccInt())

        # get current as string
        reply = self._receive(8)
        nr_bytes = int.from_bytes(reply, byteorder="little", signed=False)
        reply = self._receive(nr_bytes)
        string = reply.decode("utf-8")
        return float(string)

    def get_rpu_param(self, index: int) -> int:
        """Read a parameter from the real-time processor (RPU).

        The available indexes and the meaning of the parameter values are dependent on the
        user-defined algorithm running on the RPU.

        Warning:
            This method is *experimental* and the exposed API might change in future releases.

        Args:
            index: which parameter to read, starting from index 0.

        Returns:
            the value of the parameter at `index`, as a 64-bit integer.

        See also:
            :meth:`set_rpu_param`
        """
        self._send_command(cmd.Msg__RpuGetParam(index))
        reply = self._receive(8)
        return int.from_bytes(reply, byteorder="little", signed=False)

    def set_rpu_param(self, index: int, value: int):
        """Write a parameter to the real-time processor (RPU).

        The available indexes and the meaning of the parameter values are dependent on the
        user-defined algorithm running on the RPU.

        Warning:
            This method is *experimental* and the exposed API might change in future releases.

        Args:
            index: which parameter to write, starting from index 0.
            value: the value of the parameter at `index`, as a 64-bit integer.

        See also:
            :meth:`get_rpu_param`
        """
        self._send_command(cmd.Msg__RpuSetParam((index, value)))

    def upload_rpu_firmware(self, binary_path: str, filename: Optional[str] = None):
        """Upload a custom firmware for the real-time processor (RPU).

        Warning:
            This method is *experimental* and the exposed API might change in future releases.

        Args:
            binary_path: the local path on disk of the compiled firmware binary.
            filename: a custom filename for the firmware. If :obj:`None` (default), use the
                :func:`basename <os.path.basename>` of `binary_path`.
        """
        print("Uploading custom RPU firmware...")
        print("  Reading file from disk...")
        with open(binary_path, "rb") as f:
            binary = f.read()
        print("  Calculating sha256 digest...")
        m = hashlib.sha256()
        m.update(binary)
        digest = m.hexdigest().lower()
        print("  Sending file...")
        if filename is None:
            filename = os.path.basename(binary_path)
        self._send_command(cmd.Msg__RpuUpload((filename, binary, digest)))
        print("  Checking for errors...")
        self.assert_errors()
        print("  Done!")


def print_adc_intr_status(status: int, all_: bool = True, color: bool = False):
    start = "\x1b[1;33m" if color else ""
    stop = "\x1b[0m" if color else ""
    for i in range(16):
        elem = (status >> (4 * i)) & 0xF
        if all_ or elem > 0:
            print(f"{start}Input {i+1:2d} out of range: {elem:04b}{stop}")


def _lcm(*integers) -> int:
    nargs = len(integers)
    if nargs == 0:
        return 1
    res = integers[0]
    if nargs == 1:
        return abs(res)
    for i in range(1, nargs):
        x = integers[i]
        if res == 0:
            continue
        res = _long_lcm(res, x)
    return res


def _long_lcm(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    g = math.gcd(a, b)
    f = a // g
    m = f * b
    return abs(m)
