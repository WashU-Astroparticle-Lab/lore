# -*- coding: utf-8 -*-
# Copyright © 2018-2024 Intermodulation Products AB. All Rights Reserved.
"""
Under-the-hood version information.

Note:
    *For all common purposes, the user doesn't need this information.* Instead, use the constant
    ``presto.__version__``.

Examples:
    >>> import presto
    >>> print(presto.__version__)
    2.0.0
    >>> print(presto.version.version_api)
    2.0.0
    >>> presto.__version__ is presto.version.version_api
    True

Notes:
    The following table summarizes all the released version numbers:

    =============== ===================== ================ ===============
    ``version_api`` ``version_conductor`` ``version_fpga`` ``version_rpu``
    =============== ===================== ================ ===============
    2.16.0          0.10.0                47               0.5.4
    2.15.1          0.9.5                 44               0.5.4
    2.15.0          0.9.4                 43               0.5.4
    2.14.1          0.8.8                 40               0.5.3
    2.14.0          0.8.8                 40               0.5.3
    2.13.0          0.8.5                 39               0.5.1
    2.12.2          0.7.0                 39               0.5.0
    2.12.1          0.6.5                 37               0.4.4
    2.12.0          0.6.4                 37               0.4.4
    2.11.0          0.6.2                 35               0.4.3
    2.10.1          0.5.0                 34               0.4.1
    2.10.0          0.5.0                 34               0.4.1
    2.9.0           0.4.6                 34               0.4.0
    2.8.0           0.4.4                 33               0.4.0
    2.7.1           0.4.0                 33               0.4.0
    2.7.0           0.4.0                 33               0.4.0
    2.6.0           0.3.1                 32               0.3.1
    2.5.1           2.0.3                 31               1.2.2
    2.5.0           2.0.1                 31               1.2.2
    2.4.1           1.7.1                 29               1.2.1
    2.4.0           1.7.1                 29               1.2.1
    2.3.2           1.7.1                 29               1.2.1
    2.3.1           1.7.1                 29               1.2.1
    2.3.0           1.7.1                 29               1.2.1
    2.2.1           1.4.0                 27               1.2.1
    2.2.0           1.4.0                 27               1.2.1
    2.1.1           1.2.3                 25               1.1.1
    2.1.0           1.2.2                 25               1.1.1
    2.0.0           1.0.0                 24               1.0.0
    =============== ===================== ================ ===============

"""

from __future__ import annotations

version_api: str = "2.16.0"  # semver string
"""version of the Python public API"""
version_conductor: str = "0.10.0"  # semver string
"""version of the Rust server"""
version_fpga: int = 47  # int
"""version of the firmware for the programmable logic"""
version_rpu: str = "0.5.4"  # semver string
"""version of the firmware for the realtime-processing unit"""


def get_version_api() -> str:
    return version_api
