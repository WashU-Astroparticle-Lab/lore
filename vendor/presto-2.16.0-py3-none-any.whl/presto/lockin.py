# -*- coding: utf-8 -*-
# Copyright © 2018-2024 Intermodulation Products AB. All Rights Reserved.
"""
Continuous-wave generation and measurement.

Detailed information is provided in the documentation for each class.

.. autosummary::
    :nosignatures:

    Lockin
    SymmetricLockin
    InputGroup
    OutputGroup
    SymmetricGroup
    LockinReceiver
"""

from __future__ import annotations

import math
import socket
from typing import List, Optional, Union, Tuple, overload
import weakref
from weakref import ReferenceType

import numpy as np
import numpy.typing as npt
from numpy.typing import ArrayLike, NDArray

from . import _commands as cmd
from .hardware import AdcFSample, AdcMode, DacFSample, DacMode, Hardware
from ._stream import StreamReceiver
from .utils import asarray, as_flat_list
from .version import version_fpga as VERSION

NR_LCK_FREQ = 192
NR_GROUPS = 16
FREQ_PER_GROUP = NR_LCK_FREQ // NR_GROUPS
_MAX_TRIGGER_CLK = (1 << 24) - 1


class Lockin:
    VARIANT = 7

    def __init__(
        self,
        *,
        ext_ref_clk: Union[None, bool, int, float] = False,
        force_reload: bool = False,
        dry_run: bool = False,
        address: Optional[str] = None,
        port: Optional[int] = None,
        adc_mode: Union[AdcMode, List[AdcMode]] = AdcMode.Direct,
        adc_fsample: Optional[Union[AdcFSample, List[AdcFSample]]] = None,
        dac_mode: Union[DacMode, List[DacMode]] = DacMode.Direct,
        dac_fsample: Optional[Union[DacFSample, List[DacFSample]]] = None,
        force_config: bool = False,
    ):
        r"""Use the hardware in continuous-wave mode.

        Warning:
            Create only one instance at a time. This class is designed to be instantiated with
            Python's :ref:`with statement <python:with>`, see Examples section.

        Args:
            ext_ref_clk: if :obj:`None` or :obj:`False` use internal reference clock; if
                :obj:`True` use external reference clock (10 MHz); if :class:`float` or
                :class:`int` use external reference clock at ``ext_ref_clk`` Hz
            force_reload: if :obj:`True` re-configure clock and reload firmware even if there's no
                change from the previous settings.
            dry_run: if :obj:`True` don't connect to hardware, for testing only.
            address: IP address or hostname of the hardware. If :obj:`None`, use factory default
                ``"192.168.42.50"``.
            port: port number of the server running on the hardware. If :obj:`None`, use factory
                default ``7878``.
            adc_mode (AdcMode or list): configure the inputs to sample in direct mode (default), or
                to use the digital mixers for downconversion. See Notes.
            adc_fsample (AdcFSample or list): configure the inputs sampling rate. If :obj:`None`
                (default), choose optimal rate automatically. See Notes.
            dac_mode (DacMode or list): configure the outputs to work in direct mode (default), or
                to use the digital mixers for upconversion. See Notes.
            dac_fsample (DacFSample or list): configure the outputs sampling rate. If :obj:`None`
                (default), choose optimal rate automatically. See Notes.
            force_config: if :obj:`True` skip checks on ``DacMode``\ s not recommended for high DAC
                sampling rates.

        Raises:
            ValueError: if ``adc_mode`` or ``dac_mode`` are not valid :ref:`converter modes`;
                if ``adc_fsample`` or ``dac_fsample`` are not valid :ref:`converter rates`.

        Notes:
            In all the Examples, it is assumed that the imports ``import numpy as np`` and
            ``from presto import lockin`` have been performed, and that this class has been
            instantiated in the form ``lck = lockin.Lockin()``, or, **much much better**, using the
            ``with lockin.Lockin() as lck`` construct as below.

            For an introduction to ``adc_mode`` and ``dac_mode``, see :doc:`../special/direct_mixed`.
            For valid values of ``adc_mode`` and ``dac_mode``, see :ref:`converter modes`. For
            valid values of ``adc_fsample`` and ``dac_fsample``, see :ref:`converter rates`. For
            advanced configuration, e.g. different converter rates on different ports, see
            :ref:`adv tile`.
        """
        self.dry_run = bool(dry_run)

        self._apply_required_if = True  #: somethig changed in the IF domain, e.g. df or amplitude

        self._df = 1e3
        # self._nsum = 250
        self._reset_phase = True
        self._trigctrl = 0
        self._trigstart = 0
        self._trigwidth = 0
        self._input_frequencies = np.zeros(NR_LCK_FREQ, np.float64)
        self._input_phases_i = np.zeros(NR_LCK_FREQ, np.float64)
        self._input_phases_q = np.zeros(NR_LCK_FREQ, np.float64)
        self._input_select = np.zeros(NR_GROUPS, np.int64)
        self._input_used = np.zeros(NR_LCK_FREQ, bool)
        self._input_map = []
        self._output_frequencies = np.zeros(NR_LCK_FREQ, np.float64)
        self._output_phases_i = np.zeros(NR_LCK_FREQ, np.float64)
        self._output_phases_q = np.zeros(NR_LCK_FREQ, np.float64)
        self._output_scales = np.zeros(NR_LCK_FREQ, np.float64)
        self._output_mask = np.zeros(16, np.int64)
        self._output_used = np.zeros(NR_LCK_FREQ, bool)
        self._output_groups: list[OutputGroup | SymmetricGroup] = []
        self._input_groups: list[InputGroup | SymmetricGroup] = []

        self.hardware: Hardware = Hardware(address, port, dry_run)
        """interface to hardware features common to all modes of operation"""

        adc_mode, adc_fsample, dac_mode, dac_fsample = self.hardware.validate_config(
            adc_mode, adc_fsample, dac_mode, dac_fsample, force_config=force_config
        )
        self.adc_direct = adc_mode[0] == AdcMode.Direct
        self.dac_direct = dac_mode[0] == DacMode.Direct

        if adc_fsample[0] == AdcFSample.G3_2:
            self.CLK_T = 2.5e-9
            self.CLK_F = 400e6
            self.hardware.adc_fab_rate = 400.0
            self.hardware.dac_fab_rate = 400.0
        else:
            self.CLK_T = 2e-9
            self.CLK_F = 500e6
            self.hardware.adc_fab_rate = 500.0
            self.hardware.dac_fab_rate = 500.0

        try:
            if not self.dry_run:
                if force_reload:
                    self.hardware.reset()
                self.hardware.init_clock(ext_ref_clk)
                self.hardware.load_firmware(f"presto_{self.VARIANT:d}_{VERSION:d}.bin")
                self.hardware.init_presto()
                self.hardware.init_rfdc()

                var, ver = self.hardware.get_var_ver()
                if var != self.VARIANT:
                    raise RuntimeError(
                        f"The loaded firmware variant {var} does not match the expected {self.VARIANT}."
                        " This should not happen, please contact Intermodulation Products for support."
                    )
                self.hardware._check_version_fw(ver)

            # apply settings now to reset all frequencies, phases and scales to zero
            # otherwise we can run into trouble when changing rfdc mode later
            self.apply_settings(only_if=True)

            if not self.hardware.dac_autoconfig:
                # set user-requested configuration for the data converters
                self.hardware.setup_config()
                self.hardware.assert_errors()
                self.hardware.intr_clr()
                _ = self.hardware.get_intr_status()  # the first after MTS is polluted
                self.hardware.check_adc_intr_status()

        except (Exception, KeyboardInterrupt):
            self.close()
            raise

    def __enter__(self):  # for use with 'with' statement
        return self

    def __exit__(self, exc_type, exc_value, traceback):  # pyright: ignore
        self.close()

    def close(self):
        """Gracely disconnect from the hardware.

        Call this method if the class was instantiated without a
        :ref:`with statement <python:with>`. This method is called automatically when exiting a
        ``with`` block and before the object is destructed.
        """
        self.hardware.close()

    def apply_required(self) -> bool:
        """Check whether calling :meth:`apply_settings` is required to sync outstanding changes."""
        return self._apply_required_if or self.hardware._apply_required_rf

    def check_current_consumption(self):
        # TODO: update estimates on current consumption

        # if self.hardware.board == "zcu111":
        #     # estimate power consumption
        #     nr_outputs = np.sum(self._output_frequencies > 0)
        #     nr_input_pairs = np.sum(self._input_frequencies > 0) // 2
        #     if nr_outputs > 0 or nr_input_pairs > 0:
        #         (q_static, m_out,
        #          m_in) = (16.75, 0.082, 0.144) if self.hardware.adc_fsample[0] == AdcFSample.G3_2 else (20.75, 0.101,
        #                                                                                                 0.176)
        #         current = q_static + m_out * nr_outputs + m_in * nr_input_pairs
        #         if current > 30.0:
        #             raise RuntimeError(f"the requested configuration would consume too much power: {current} A."
        #                                "Consider decreasing the number of input/output frequencies")
        pass

    def _apply_rf_settings(self, do_sync: bool = True):
        if self.hardware.dac_autoconfig and self.hardware._apply_required_rf:
            # set user-requested configuration for the data converters
            self.hardware.setup_config(do_sync=do_sync)
            self.hardware.assert_errors()
            self.hardware.intr_clr()
            _ = self.hardware.get_intr_status()  # the first after MTS is polluted
            # self.hardware.check_adc_intr_status()

    def apply_settings(self, *, auto_sync: bool = True, only_if: bool = False):
        """Apply the settings to the hardware.

        Args:
            auto_sync: if ``True`` (default), trigger signal generation internally. Set to
                ``False`` to synchronize to an external source, e.g. a Metronomo unit.

        Note:
            Prior to a call to this function, any change of settings has no effect on the hardware.
        """
        if not only_if:
            self._apply_rf_settings(do_sync=auto_sync)

        if self._apply_required_if:
            self._clear_outputs()
            self._clear_inputs()

            for og in self._output_groups:
                assert isinstance(og, OutputGroup)
                self._add_output(
                    og.ports,
                    og._output_frequencies,
                    og._output_scales,
                    og._output_phases_i,
                    og._output_phases_q,
                )
            for ig in self._input_groups:
                assert isinstance(ig, InputGroup)
                self._add_input(ig.port, ig._input_frequencies, ig._input_phases_i)

            self.check_current_consumption()

            if not self.dry_run:
                # disable outputs
                self.hardware.blank_output(range(1, self.hardware.nr_ports + 1), True)

                # send settings
                self.hardware._send_command(
                    cmd.Msg__LckSetInFreqPhase(
                        (  # pyright: ignore[reportArgumentType]
                            self._input_frequencies,
                            self._input_phases_i,
                            self._input_phases_q,
                        )
                    )
                )
                self.hardware._send_command(
                    cmd.Msg__LckSetOutFreqPhase(
                        (  # pyright: ignore[reportArgumentType]
                            self._output_frequencies,
                            self._output_phases_i,
                            self._output_phases_q,
                        )
                    )
                )

                self.hardware._send_command(cmd.Msg__LckSetScale(self._output_scales))  # pyright: ignore[reportArgumentType]
                self.hardware._send_command(
                    cmd.Msg__LckSetDf(
                        (
                            self.get_df(),
                            self._reset_phase,
                            self._trigctrl,
                            self._trigstart,
                            self._trigstart + self._trigwidth,
                        )
                    )
                )

                for channel in range(self.hardware.nr_ports):
                    self.hardware._send_command(
                        cmd.Msg__LckGroupMask((channel, self._output_mask[channel]))
                    )

                for i in range(NR_GROUPS):
                    self.hardware._send_command(
                        cmd.Msg__LckInputSelect((i, self._input_select[i]))
                    )

                # signal generation is started on a sysref edge
                if auto_sync:
                    # trigger sysref
                    self.hardware.sync()

                # enable outputs
                self.hardware.sleep(self.get_Tm(), False)
                self.hardware.blank_output(range(1, self.hardware.nr_ports + 1), False)

                self.hardware.assert_errors()
            self._apply_required_if = False

    @overload
    def tune(
        self, f: npt.NDArray[np.floating], df: float
    ) -> Tuple[npt.NDArray[np.floating], float]: ...

    @overload
    def tune(self, f: float, df: float) -> Tuple[float, float]: ...

    def tune(self, f: ArrayLike, df: float) -> Tuple[Union[float, np.ndarray], float]:
        r"""Perform standard level of tuning.

        This provides frequencies closer to the requested ones, with a level of Fourier leakage
        that is adequate to most experiments. See Notes.

        Args:
            f (float or array_like): Target frequency/ies in Hz
            df: Target measurement bandwidth in Hz

        Returns:
            a tuple of ``(f_tuned, df_tuned)`` where

            * ``f_tuned`` (float or array_like): Tuned frequencies in Hz. If ``f`` is a
              :class:`float`, then ``f_tuned`` is also a ``float``; if ``f`` is array-like, then
              ``f_tuned`` is a :class:`~numpy.ndarray` with ``dtype=np.float64``
            * ``df_tuned`` (float): Tuned measurement bandwith in Hz

        See also:
            :meth:`tune_perfect`: perfect tuning
            :meth:`set_phase_reset`: enable/disable phase reset every ``1/df``

        Notes:
            First, this level of tuning forces the measurement bandwith ``df`` to be a divisor of
            the sampling frequency ``fs``, i.e. there is an integer number of samples
            ``ns = fs/df_tuned`` in each lock-in measurement window. Second, the tuning forces each
            frequency ``f`` to be integer multiple of the measurement bandwith ``df_tuned``, i.e.
            there is an integer number ``n = f_tuned/df_tuned`` of oscillations within each
            measurement window.

            In theory, this level of tuning allows for measurement without Fourier leakage, or
            spectral leakage. In practice, however, not every value of ``f_tuned`` can be
            represented exactly in the hardware. With this level of tuning, the frequency that is
            actually set in hardware ``f_set`` is slightly different from the tuned frequency
            ``f_tuned``. Therefore, the ratio ``f_set/df_tuned`` is not an integer, and some
            Fourier leakage occurs. To avoid long-term phase drift, the phase of the oscillation at
            frequency ``f_set`` is reset at the end of each lock-in window (every ``1/df_tuned``).
            See :meth:`set_phase_reset` for a way to disable this behavior.

            Nonetheless, the difference between ``f_set`` and ``f_tuned`` is actually really small:
            the worst-case error is ``get_fs("dac")/2/2**48``, on the order of a single microhertz
            (1 μHz)! For most common applications, the resulting Fourier leakage and the
            phase-reset glitches are well below the noise level. If however, this is not
            acceptable, see :meth:`tune_perfect`.
        """
        ret_scalar = isinstance(f, float)
        f = np.atleast_1d(f).astype(np.float64)

        # in general, df must correspond to an integer number of samples
        # but more stringent: it must correspond to an integer number of clock cycles (4 samples in direct mode)
        df = float(df)
        ns_tuned = int(round(self.CLK_F / df))
        df_tuned = self.CLK_F / ns_tuned

        f_tuned = df_tuned * np.round(f / df_tuned)
        if ret_scalar:
            return f_tuned[0], df_tuned
        else:
            return f_tuned, df_tuned

    def tune_perfect(self, f: ArrayLike, df: float) -> Tuple[Union[float, np.ndarray], float]:
        """Perform perfect level of tuning.

        This provides frequencies that might be further from the requested ones, but with zero
        Fourier leakage. See Notes.

        Args:
            f (float or array_like): Target frequency/ies in Hz
            df: Target measurement bandwidth in Hz

        Returns:
            a tuple of ``(f_tuned, df_tuned)`` where

            * ``f_tuned`` (float or array_like): Tuned frequencies in Hz. If ``f`` is a
              :class:`float`, then ``f_tuned`` is also a ``float``; if ``f`` is array-like, then
              ``f_tuned`` is a :class:`~numpy.ndarray` with ``dtype=np.float64``
            * ``df_tuned`` (float): Tuned measurement bandwith in Hz

        See also:
            :meth:`tune`: standard tuning

        Notes:
            First, this level of tuning forces the measurement bandwith ``df`` to divide the
            sampling frequency ``fs`` by a power of 2, i.e. the number of samples in each lock-in
            measurement window is a power of 2: ``ns = fs/df_tuned = 2**m``. Second, the tuning
            forces each frequency ``f`` to be integer multiple of the measurement bandwith
            ``df_tuned``, i.e. there is an integer number ``n = f_tuned/df_tuned`` of oscillations
            within each measurement window.

            This level of tuning always allows for measurement without Fourier leakage, or spectral
            leakage, and guarantees that ``f_tuned`` can be represented exactly in the hardware.
        """
        ret_scalar = isinstance(f, float)
        f = np.atleast_1d(f).astype(np.float64)

        fs = self.CLK_F  # tune with respect to clock frequency
        ns = fs / df
        ns_tuned: int = 2 ** int(round(math.log2(ns)))
        df_tuned = fs / ns_tuned

        f_tuned = df_tuned * np.round(f / df_tuned)
        if ret_scalar:
            return f_tuned[0], df_tuned
        else:
            return f_tuned, df_tuned

    def get_clk_f(self) -> float:
        """Frequency of the programmable-logic clock in Hz.


        See also:
            :meth:`get_clk_T`
            :meth:`get_fs`
        """
        return self.CLK_F

    def get_clk_T(self) -> float:
        """Period of the programmable-logic clock in seconds.


        See also:
            :meth:`get_clk_f`
            :meth:`get_fs`
        """
        return self.CLK_T

    def get_fs(self, which: str) -> float:
        """Get sampling frequency for ``which`` converter in Hz.

        Args:
            which: ``"adc"`` for input and ``"dac"`` for output.

        Raises:
            ValueError: if ``which`` is unknown.
        """
        if which == "adc":
            if self.adc_direct:
                return 4 * self.get_clk_f()
            else:
                return 2 * self.get_clk_f()
        elif which == "dac":
            if self.dac_direct:
                return 4 * self.get_clk_f()
            else:
                return 2 * self.get_clk_f()
        else:
            raise ValueError(f'which can be "adc" or "dac", got {which}')

    def get_df(self) -> float:
        """Get measurement bandwidth in Hz.


        See also:
            :meth:`set_df`
            :meth:`get_Tm`
        """
        return self._df

    def set_df(self, df: float):
        """Set measurement bandwith.

        *The new setting is not applied until* :meth:`apply_settings` *is called!*

        Args:
            df: Measurement bandwith in Hz.

        Notes:
            Non-tuned measurement bandwidths can't be set in hardware. When passing a non-tuned
            ``df``, the closest tuned value will be set in hardware. To avoid confusion, it is
            recommended to explicitly tune ``df`` before calling this method.

        See also:
            :meth:`get_df`
            :meth:`tune`
            :meth:`tune_perfect`
        """
        self._apply_required_if = True
        df = float(df)
        # df must correspond to an integer number of clock cycles
        # NOTE: this is the same as standard tuning!
        period = int(round(self.CLK_F / df))
        self._df = self.CLK_F / period

    def set_phase_reset(self, reset_phase: bool):
        """Reset the phase of the reference signals at the end of every lock-in window.

        *The new setting is not applied until* :meth:`apply_settings` *is called!*

        Args:
            reset_phase: if :obj:`True` the phase reset is enabled, set to :obj:`False` to disable.

        Notes:
            This setting is enabled by default. See Notes in :meth:`tune` for rationale.
        """
        self._reset_phase = bool(reset_phase)

    def _time_to_clk(self, t: float, check: bool = False) -> int:
        """Convert ``t`` to an integer number of clock cycles, round if needed."""
        t = float(t)
        c = int(round(t * self.CLK_F))
        if check:
            if c < 0:
                raise ValueError("t must be nonnegative")
            if abs(c * self.CLK_T - t) > self.CLK_T / 100:
                raise ValueError(f"t={t} is not a multiple of the clock period {self.CLK_T}")
        return c

    def set_trigger_out(
        self,
        states: Union[int, List[int]],
        delay: float = 0.0,
        width: float = 100e-9,
    ) -> None:
        """Output a trigger on the digital output ports at the start of every demodulation or
        summing window.

        Times will be rounded to closest integer multiple of :meth:`get_clk_T`.

        Args:
            states: enable/disable the trigger on each of the digital output ports. Valid values
                are:

                * ``0`` no trigger output
                * ``1`` trigger for each new lock-in window
                * ``2`` trigger for each new sum window (mean and std)

            delay: delay trigger rising edge from start of lock-in window, in seconds
            width: trigger-high duration, in seconds

        Raises:
            ValueError: if ``delay`` and ``width`` are negative, or too large

        Examples:
            Output a 100ns trigger on port 1 every summing window and on port 2 every demodulation
            window:

            >>> lck.set_trigger_out([2, 1])
        """
        states = as_flat_list(states)
        control = 0
        for ii, state in enumerate(states):
            if state < 3:
                control |= state << (2 * ii)
            else:
                raise ValueError("state can be 0, 1 or 2")

        start = self._time_to_clk(delay)
        if start < 0 or start > _MAX_TRIGGER_CLK:
            raise ValueError(f"delay must be between 0 and {_MAX_TRIGGER_CLK*self.CLK_T} seconds")
        width = self._time_to_clk(width)
        if width < 1 or width > _MAX_TRIGGER_CLK:
            raise ValueError(
                f"width must be within {self.CLK_T} and {_MAX_TRIGGER_CLK*self.CLK_T} seconds"
            )

        self._trigctrl = control
        self._trigstart = start
        self._trigwidth = width

    def get_Tm(self) -> float:
        """Get measurement time in seconds.

        The inverse of the measurement bandwidth.


        See also:
            :meth:`get_df`
        """
        df = self.get_df()
        return 1.0 / df

    def get_ns(self, which: str = "adc") -> int:
        """Get number of samples per lock-in window.

        The sampling rate divided by the measurement bandwidth.

        Args:
            which: "adc" for input and "dac" for output.
        """
        return int(round(self.get_fs(which=which) / self.get_df()))

    def _clear_outputs(self):
        """Clears all outputs.

        Clears all outputs so that :meth:`add_output` starts from scratch. Not applied until
        :meth:`apply_settings` is called!
        """
        self._output_frequencies.fill(0.0)
        self._output_phases_i.fill(0.0)
        self._output_phases_q.fill(0.0)
        self._output_scales.fill(0.0)
        self._output_mask.fill(0)
        self._output_used.fill(False)

    def _add_output(
        self,
        ports: ArrayLike,
        freqs: ArrayLike,
        amps: ArrayLike,
        phases: ArrayLike,
        phases_q: Optional[ArrayLike] = None,
        deg: bool = False,
    ):
        ports = np.atleast_1d(ports).astype(np.int64)
        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        phases = np.atleast_1d(phases).astype(np.float64)
        amps = np.atleast_1d(amps).astype(np.float64)

        if self.dac_direct:
            if phases_q is not None:
                raise ValueError("setting phases_q is not allowed if dac_mode is DacDirect!")
        else:
            if phases_q is None:
                raise ValueError("must provide phases_q if dac_mode is not DacDirect!")
            phases_q = np.atleast_1d(phases_q).astype(np.float64)
            if phases_q.shape != phases.shape:
                raise ValueError("phases_q must have same shape as phases!")

        if deg:
            phases = phases / 180.0 * np.pi

        if np.any(np.abs(amps) > 1.0):
            raise ValueError("Max amplitude is 1.0")

        first = self._first_free_output()
        last = first + freqs.shape[0]
        if last > NR_LCK_FREQ:
            raise ValueError("Too many output frequencies used")
        self._output_frequencies[first:last] = freqs
        self._output_phases_i[first:last] = phases
        self._output_phases_q[first:last] = phases_q
        self._output_scales[first:last] = amps
        self._output_used[first:last] = True

        for port in ports:
            for bit in set(np.arange(first, last, dtype=np.int64) // FREQ_PER_GROUP):
                self._output_mask[port - 1] = self._output_mask[port - 1] | (1 << bit)

        self._resync_phases()

    def _clear_inputs(self):
        """Removes settings for all inputs."""
        self._input_frequencies.fill(0.0)
        self._input_phases_i.fill(0.0)
        self._input_phases_q.fill(0.0)
        self._input_select.fill(0)
        self._input_used.fill(False)
        self._input_map = []

    def _add_input(self, port: int, freqs: ArrayLike, phases: ArrayLike):
        if port in [x[0] for x in self._input_map]:
            raise ValueError("Can only add an input once")

        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        freqs = freqs.repeat(2)  # I&Q
        phases = np.atleast_1d(phases).astype(np.float64)

        first = self._first_free_input()
        last = first + freqs.shape[0]

        if last > NR_LCK_FREQ:
            raise ValueError("Too many input frequencies used")

        self._input_frequencies[first:last] = freqs
        self._input_phases_i[first:last:2] = phases
        self._input_phases_i[first + 1 : last : 2] = phases + np.pi / 2

        for i in set(np.arange(first, last, dtype=np.int64) // FREQ_PER_GROUP):
            self._input_select[i] = port - 1
        self._input_used[first:last] = True
        if len(self._input_map) == 0:
            self._input_map.append((port, first, last, first, last))
        else:
            tot_used = self._input_map[-1][4]
            self._input_map.append((port, first, last, tot_used, tot_used + (last - first)))

        self._resync_phases()

    def add_output_group(self, ports: ArrayLike, nr_freq: int) -> "OutputGroup":
        """Create and return a new :class:`output group <.OutputGroup>`

        Args:
            ports (int or array_like): which output port(s) the group should output data to. If a
                :class:`list`, the output will be replicated on all ``ports``
            nr_freq: how many frequencies the output group should modulate
        """
        g = OutputGroup(ports, nr_freq, self)
        self._output_groups.append(g)
        self._add_output(
            ports,
            np.zeros(nr_freq),
            np.zeros(nr_freq),
            np.zeros(nr_freq),
            None if self.dac_direct else np.zeros(nr_freq),
        )
        return g

    def add_input_group(self, port: int, nr_freq: int) -> "InputGroup":
        """Create and return a new :class:`input group <.InputGroup>`

        Args:
            port: which input port the group should sample data from
            nr_freq: how many frequencies the input group should demodulate
        """
        g = InputGroup(port, nr_freq, self)
        self._input_groups.append(g)
        self._add_input(port, np.zeros(nr_freq), np.zeros(nr_freq))
        return g

    def set_dither(self, state: bool, output_ports: ArrayLike):
        """Add pseudorandom noise to the generated output.

        Can improve harmonic and intermodulation distortion when working with small output
        amplitudes.

        *The change is active* **immediately**

        Args:
            state: if :obj:`True`, add pseudorandom noise to the output
            output_ports (int or array_like): which output port(s) should be affected
        """
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        self._apply_required_if = True

        if not self.dry_run:
            for port in output_ports:
                channel = port - 1
                self.hardware._send_command(cmd.Msg__TestDither((channel, state)))

    def _build_get_command(
        self,
        *,
        n: Optional[int],  # <-- None means streaming
        summed: bool,
        fir_coeffs: Optional[ArrayLike],
        nsum: int,
        quiet: bool,
        auto_sync: bool,
        rpu_params: Optional[Tuple],
    ) -> Tuple[cmd.Msg, int, int]:
        # NOTE: common to Lockin and SymmetricLockin

        if self.dry_run:
            raise RuntimeError("get_pixels does not work when dry_run is True")
        if self.apply_required():
            raise RuntimeError(
                "there are outstanding changes not applied to hardware. Call apply_settings first!"
            )
        if summed and self.adc_direct:
            raise NotImplementedError("summed=True does not work when in Direct mode")

        if fir_coeffs is None:
            coeffs = []
            pixels_to_skip = 1
        else:
            if not summed:
                raise ValueError("the FIR filter is only supported when summed=True")
            coeffs = np.atleast_1d(fir_coeffs).astype(np.float64)
            if len(coeffs) == 22:
                # first half + center tap
                pass
            elif len(coeffs) == 43:
                # full coefficient list
                # check symmetric
                if not np.allclose(coeffs[:21], coeffs[-21:][::-1]):
                    raise ValueError("FIR filter must be symmetric")
                # take only the first half + center
                coeffs = coeffs[:22]
            else:
                raise ValueError("FIR filter must have 43 coefficients")
            pixels_to_skip = 43

        nsum = int(nsum)
        if nsum < 1 or nsum > 1023:
            raise ValueError("nsum must be in [1;1023]")

        # get more pixels, and throw them away as the first pixels_to_skip are bad
        num_pixels_extra = math.ceil(pixels_to_skip / nsum) if summed else pixels_to_skip

        # two accumulators used for every quadrature I,I for direct mode I,Q for mixed mode
        lck_map = np.nonzero(self._input_used)[0].astype(np.int64).repeat(2) * 2
        lck_map[1::2] += 1

        # number of 4-parallel lockins used, each producing 2 sums, I,I for direct mode I,Q for mixed mode
        num_demod = np.sum(self._input_used).astype(np.int64)

        if n is not None:
            num_pixels = int(n)
            msg = cmd.Msg__LckGet(
                (  # pyright: ignore[reportArgumentType]
                    summed,
                    num_pixels + num_pixels_extra,
                    coeffs,
                    nsum,
                    lck_map,
                )
            )

        else:
            # streaming!
            msg = cmd.Msg__LckStream(
                (  # pyright: ignore[reportArgumentType]
                    summed,
                    coeffs,
                    nsum,
                    lck_map,
                    rpu_params,
                )
            )

        return (msg, num_pixels_extra, num_demod)

    def _get_pixels_common(
        self,
        *,
        n: int,
        summed: bool,
        fir_coeffs: Optional[ArrayLike],
        nsum: int,
        quiet: bool,
        auto_sync: bool,
        rpu_params: Optional[Tuple],
    ) -> Tuple[int, int, npt.NDArray[np.float32]]:
        # NOTE: common to Lockin and SymmetricLockin

        msg, num_pixels_extra, num_demod = self._build_get_command(
            n=n,
            summed=summed,
            fir_coeffs=fir_coeffs,
            nsum=nsum,
            quiet=quiet,
            auto_sync=auto_sync,
            rpu_params=None,
        )
        self.hardware._send_command(msg)

        # pixel window is aligned with next SYSREF edge
        if auto_sync:
            # trigger immediately
            self.hardware.sync()

        # receive confirmation the server is waiting for a connection
        reply = self.hardware._receive(8)
        assert 35 == int.from_bytes(reply, byteorder="little", signed=False)

        num_pixels = int(n)

        # bytes/sample * number of used quadratures * I,Q
        bytes_per_pixel = 4 * num_demod * 2
        if summed:
            bytes_per_pixel *= 2  # sum and sum squared
        nr_bytes = num_pixels * bytes_per_pixel
        extra_bytes = num_pixels_extra * bytes_per_pixel

        with self.hardware._new_connection() as sock:
            reply = self.hardware._receive_from(nr_bytes + extra_bytes, sock)

        self.hardware.assert_errors()
        if not quiet:
            self.hardware.check_adc_intr_status()

        dtype = np.dtype(np.float32).newbyteorder("<")
        data = np.frombuffer(reply[-nr_bytes:], dtype=dtype)  # don't convert first bad pixels
        return (num_pixels, num_demod, data)

    def get_pixels(
        self,
        n: int,
        *,
        summed: bool = False,
        fir_coeffs: Optional[ArrayLike] = None,
        nsum: int = 250,
        quiet: bool = False,
        auto_sync: bool = True,
    ) -> dict:
        r"""Get lock-in packets (pixels) from the hardware.

        Args:
            n: the number of lock-in packets to measure.
            summed: when ``True``, calculate on the hardware the mean and standard deviation of the
                acquired data in chunks of ``nsum`` lock-in packets.
            fir_coeffs (array_like of float): coefficients for FIR filter to be applied to measured
                data. 43 coefficients must be provided, or pass None (default) to disable the
                filter. Not available if ``summed=False``. See also *Notes* and *Examples* sections.
            nsum: Only active when ``summed=True``. How many lock-in packets (at rate
                :meth:`get_df`\ ) are included in a "chunk". The resulting data rate is
                ``df / nsum``. Ignored if ``summed=False``.
            quiet: if True, don't check for inputs out of range
            auto_sync: if ``True`` (default), trigger signal acquisition internally. Set to
                ``False`` to synchronize to an external source, e.g. a Metronomo unit.

        Returns:
            A dictionary with key ``port`` and value depending on the value of ``summed``.

            The key is always:

              - ``port`` (:class:`int`): input port measured

            When ``summed=False`` (default), the value is a tuple of:

              - ``freqs`` (:class:`~numpy.ndarray`, ``dtype=np.float64``): frequencies at which the
                lockin measurement was done.
              - ``pixels`` (:class:`~numpy.ndarray`, ``dtype=np.complex64``): measured lock-in data
                in ratio of full-scale input. ``shape`` is ``(n, len(freqs))``. When using digital
                downconversion (``adc_mode`` is :class:`AdcMode.Mixed <.AdcMode>`), these are the
                pixels of the I port of the digital mixer.
              - ``pixels_q`` (:class:`~numpy.ndarray`, ``dtype=np.complex64``): only present when
                using digital downconversion (``adc_mode`` is :class:`AdcMode.Mixed <.AdcMode>`),
                these are the pixels of the Q port of the digital mixer.

            When ``summed=True``, the value is a tuple of:

              - ``freqs`` (:class:`~numpy.ndarray`, ``dtype=np.float64``): frequencies at which the
                lockin measurement was done.
              - ``mean_I`` (:class:`~numpy.ndarray`, ``dtype=np.complex64``): calculated mean of
                ``nsum`` consecutive lock-in packets from the I port of the digital downconversion.
                ``shape`` is ``(n, len(freqs))``.
              - ``std_I`` (:class:`~numpy.ndarray`, ``dtype=np.complex64``): calculated standard
                deviation of ``nsum`` consecutive lock-in packets from the I port of the digital
                downconversion. ``shape`` is ``(n, len(freqs))``. The standard deviation has a real
                and an imaginary part; ``abs(std)`` is the total standard deviation according to
                `Complex random variable <https://en.wikipedia.org/wiki/Complex_random_variable#Variance_and_pseudo-variance>`_.
              - ``mean_Q`` (:class:`~numpy.ndarray`, ``dtype=np.complex64``): same as ``mean_I``,
                but from the Q port.
              - ``std_Q`` (:class:`~numpy.ndarray`, ``dtype=np.complex64``): same as ``std_I``, but
                from the Q port.

        Raises:
            RuntimeError: if :meth:`apply_settings` was not called after changing some setting

        Notes:
            This method locks execution until at least ``n`` measured packets are available.

            ``summed=True`` is only implemented when using digital downconversion (``adc_mode`` is
            :class:`AdcMode.Mixed <.AdcMode>`).

            Useful functions for computing the coefficients ``fir_coeffs`` for the FIR filter are
            :func:`~scipy.signal.remez` and :func:`~scipy.signal.firwin` in :mod:`scipy.signal`.

        Examples:
            Measure 1k lock-in packets, and low-pass filter the measured data:

            >>> from scipy.signal import firwin
            >>> coeffs = firwin(43, 80e3, fs=lck.get_df())  # low-pass filter with 80 kHz cutoff
            >>> data = lck.get_pixels(n=1000, fir_coeffs=coeffs)
            >>> freqs, (pixels_I, pixels_Q) = data[input_port]
            >>> freqs.shape
            (32,)
            >>> pixels_I.shape
            (1000, 32)
            >>> pixels_Q.shape
            (1000, 32)

            Measure 100k lock-in packets, and compute mean and standard deviation in chunks of 100
            packets:

            >>> data = lck.get_pixels(n=1000, summed=True, nsum=100)
            >>> freqs, (mean_I, std_I, mean_Q, std_Q) = data[input_port]
            >>> freqs.shape
            (32,)
            >>> mean_I.shape
            (1000, 32)
            >>> std_Q.shape
            (1000, 32)
        """
        # common to Lockin and SymmetricLockin
        num_pixels, num_demod, data = self._get_pixels_common(
            n=n,
            summed=summed,
            fir_coeffs=fir_coeffs,
            nsum=nsum,
            quiet=quiet,
            auto_sync=auto_sync,
            rpu_params=None,
        )
        # specific to Lockin
        return self._data_to_pixels(
            data=data,
            summed=summed,
            num_pixels=num_pixels,
            num_demod=num_demod,
        )

    def _data_to_pixels(
        self,
        *,
        data: npt.NDArray[np.float32],
        summed: bool,
        num_pixels: int,
        num_demod: int,
    ) -> dict:
        # NOTE: specific to Lockin

        if summed:  # summed, mixed
            # NOTE: no direct case
            mean_I = data[0::4]
            var_I = data[1::4]
            mean_Q = data[2::4]
            var_Q = data[3::4]
            # complex mean, can't use np.frombuffer because array is not C-contiguous
            mean_I = mean_I[0::2] + 1j * mean_I[1::2]
            mean_Q = mean_Q[0::2] + 1j * mean_Q[1::2]
            # real variance of complex variable
            var_Ir = var_I[0::2]
            var_Ii = var_I[1::2]
            std_I = np.sqrt(var_Ir) + 1j * np.sqrt(var_Ii)
            var_Qr = var_Q[0::2]
            var_Qi = var_Q[1::2]
            std_Q = np.sqrt(var_Qr) + 1j * np.sqrt(var_Qi)
            # reshape
            mean_I.shape = (num_pixels, num_demod // 2)
            mean_Q.shape = (num_pixels, num_demod // 2)
            std_I.shape = (num_pixels, num_demod // 2)
            std_Q.shape = (num_pixels, num_demod // 2)
            d = dict()
            for port, f1, l1, f2, l2 in self._input_map:
                _mean_I = mean_I[:, f2:l2]
                _mean_Q = mean_Q[:, f2:l2]
                _std_I = std_I[:, f2:l2]
                _std_Q = std_Q[:, f2:l2]
                d[port] = (self._input_frequencies[f1:l1], _mean_I, _std_I, _mean_Q, _std_Q)
            return d

        else:
            if self.adc_direct:  # normal, direct
                data /= 2  # in direct mode we have twice the number of samples
                # sum I and Q samples
                data = data[0::2] + data[1::2]
                # complex
                data_C = np.frombuffer(data, np.complex64)
                # reshape
                data_C.shape = (num_pixels, num_demod // 2)
                # group inputs
                d = dict()
                for port, f1, l1, f2, l2 in self._input_map:
                    d[port] = (self._input_frequencies[f1:l1:2], data_C[:, f2 // 2 : l2 // 2])
                return d
            else:  # normal, mixed
                data_I, data_Q = data[0::2], data[1::2]
                # complex, can't use np.frombuffer because array is not C-contiguous
                data_I = data_I[0::2] + 1j * data_I[1::2]
                data_Q = data_Q[0::2] + 1j * data_Q[1::2]
                # reshape
                data_I.shape = (num_pixels, num_demod // 2)
                data_Q.shape = (num_pixels, num_demod // 2)
                # group inputs
                d = dict()
                for port, f1, l1, f2, l2 in self._input_map:
                    d[port] = (
                        self._input_frequencies[f1:l1:2],
                        data_I[:, f2 // 2 : l2 // 2],
                        data_Q[:, f2 // 2 : l2 // 2],
                    )
                return d

    def stream_pixels(
        self,
        *,
        summed: bool = False,
        fir_coeffs: Optional[ArrayLike] = None,
        nsum: int = 250,
        quiet: bool = False,
        auto_sync: bool = True,
        rpu_params: Optional[Tuple] = None,
    ) -> "LockinReceiver":
        r"""Receive lock-in packets (pixels) from the hardware in the background.

        This method returns a :class:`LockinReceiver` object that receives a stream of packets in
        a separate thread, without blocking the execution of the current thread.

        Warning:
            This method is *experimental* and the exposed API might change in future releases.

        Args:
            summed: when ``True``, calculate on the hardware the mean and standard deviation of the
                acquired data in chunks of ``nsum`` lock-in packets.
            fir_coeffs (array_like of float): coefficients for FIR filter to be applied to measured
                data. 43 coefficients must be provided, or pass None (default) to disable the
                filter. Not available if ``summed=False``. See also *Notes* and *Examples* sections.
            nsum: Only active when ``summed=True``. How many lock-in packets (at rate
                :meth:`get_df`\ ) are included in a "chunk". The resulting data rate is
                ``df / nsum``. Ignored if ``summed=False``.
            quiet: if True, don't check for inputs out of range
            auto_sync: if ``True`` (default), trigger signal acquisition internally. Set to
                ``False`` to synchronize to an external source, e.g. a Metronomo unit.
            rpu_params: set to ``None`` to not start the RPU. Otherwise, set to a ``tuple`` of:

                - RPU firmware filename (str)
                - quadrature select (list of int): a list of indexes for which lockin quadratures
                  the RPU firmware should have access to. E.g. ``[0, 1]`` for I and Q quadratures
                  of first frequency.
                - length of sliding window (int): the number of lockin pixels in the sliding
                  sum/average performed by the RPU

        Returns:
            An instance of :class:`LockinReceiver`, to be used with Python's
            :ref:`with statement <python:with>`, see Examples section.

        Raises:
            RuntimeError: if :meth:`apply_settings` was not called after changing some setting

        Notes:
            ``summed=True`` is only implemented when using digital downconversion (``adc_mode`` is
            :class:`AdcMode.Mixed <.AdcMode>`).

            Useful functions for computing the coefficients ``fir_coeffs`` for the FIR filter are
            :func:`~scipy.signal.remez` and :func:`~scipy.signal.firwin` in :mod:`scipy.signal`.

        Examples:
            See :class:`LockinReceiver` for examples.
        """
        msg, num_pixels_extra, num_demod = self._build_get_command(
            n=None,
            summed=summed,
            fir_coeffs=fir_coeffs,
            nsum=nsum,
            quiet=quiet,
            auto_sync=auto_sync,
            rpu_params=rpu_params,
        )
        self.hardware._send_command(msg)

        # pixel window is aligned with next SYSREF edge
        if auto_sync:
            # trigger immediately
            self.hardware.sync()

        # receive confirmation the server is waiting for a connection
        reply = self.hardware._receive(8)
        assert 35 == int.from_bytes(reply, byteorder="little", signed=False)

        # bytes/sample * number of used quadratures * I,Q
        bytes_per_pixel = 4 * num_demod * 2
        if summed:
            bytes_per_pixel *= 2  # sum and sum squared
        extra_bytes = num_pixels_extra * bytes_per_pixel

        return LockinReceiver(
            lck=weakref.ref(self),
            sock=self.hardware._new_connection(),
            summed=summed,
            bytes_per_meas=bytes_per_pixel,
            extra_bytes=extra_bytes,
        )

    def sweep_nco(
        self,
        input_port: int,
        input_freqs: ArrayLike,
        output_port: int,
        output_freqs: ArrayLike,
        nr_averages: int,
        *,
        status_callback=None,
    ):
        if self.adc_direct or self.dac_direct:
            raise RuntimeError("sweep_nco requires Mixed mode on both ADC and DAC")

        input_port = int(input_port)
        if input_port < 1 or input_port > self.hardware.nr_ports:
            raise ValueError(f"input_port must be in [1, {self.hardware.nr_ports}]")
        output_port = int(output_port)
        if output_port < 1 or output_port > self.hardware.nr_ports:
            raise ValueError(f"output_port must be in [1, {self.hardware.nr_ports}]")

        # frequencies in MHz
        input_freqs = np.atleast_1d(input_freqs).astype(np.float64) / 1e6
        output_freqs = np.atleast_1d(output_freqs).astype(np.float64) / 1e6
        if (
            np.any(input_freqs < 0.0)
            or np.any(input_freqs > 10e3)
            or np.any(output_freqs < 0.0)
            or np.any(output_freqs > 10e3)
        ):
            raise ValueError("NCO frequencies must be within 0 and 10 GHz")

        nr_freqs = len(input_freqs)
        if len(output_freqs) != nr_freqs:
            raise ValueError("input_freqs and output_freqs must have the same length")

        adc_tile = self.hardware._port_to_tile(input_port, "adc")
        adc_fsample = self.hardware.adc_fsample[adc_tile]
        adc_setup = self.hardware.adc_setup[adc_tile]
        adc_nyq = adc_fsample.nyq()
        in_zone = 1 + int(input_freqs[nr_freqs // 2] // adc_nyq)
        input_freqs_nco = np.array(
            [adc_fsample.fix_freq(f, adc_setup, in_zone) for f in input_freqs]
        )
        if in_zone % 2 == 1:  # odd zone
            input_freqs_nco = -input_freqs_nco

        dac_tile = self.hardware._port_to_tile(output_port, "dac")
        dac_fsample = self.hardware.dac_fsample[dac_tile]
        dac_setup = self.hardware.dac_setup[dac_tile]
        dac_nyq = dac_fsample.nyq()
        dac_fs = dac_fsample.fs()
        f_rem_nyq = (int(output_freqs[nr_freqs // 2] // dac_nyq) % 2) == 1
        f_rem_fs = (int(output_freqs[nr_freqs // 2] // dac_fs) % 2) == 1
        if f_rem_nyq ^ f_rem_fs:
            out_zone = 2
        else:
            out_zone = 1
        output_freqs_nco = np.array(
            [dac_fsample.fix_freq(f, dac_setup, out_zone) for f in output_freqs]
        )
        if out_zone % 2 == 0:  # even zone
            output_freqs_nco = -output_freqs_nco

        nr_averages = int(nr_averages)
        if nr_averages <= 0:
            raise ValueError("nr_averages must be positive")

        lck_map = np.nonzero(self._input_used)[0].astype(np.int64).repeat(2) * 2
        lck_map[0::2] = lck_map[0::2] + 1
        num_demod = np.sum(self._input_used).astype(np.int64)

        self.hardware._send_command(
            cmd.Msg__LckNcoSweep(
                (
                    input_port - 1,
                    input_freqs_nco * 1e6,
                    output_port - 1,
                    output_freqs_nco * 1e6,
                    nr_averages,
                    lck_map,
                )  # pyright: ignore
            )
        )

        # receive confirmation the server is waiting for a connection
        reply = self.hardware._receive(8)
        assert 35 == int.from_bytes(reply, byteorder="little", signed=False)

        bytes_per_freq = 8 * num_demod * 2  # bytes/sample * number of used quadratures * I,Q
        nr_bytes = nr_freqs * bytes_per_freq
        if status_callback is not None:
            callback = lambda x: status_callback(x // bytes_per_freq)  # noqa: E731
        else:
            callback = None
        with self.hardware._new_connection() as sock:
            reply = self.hardware._receive_from(nr_bytes, sock, status_callback=callback)

        self.hardware.assert_errors()

        dtype = np.dtype(np.float64).newbyteorder("<")
        data = np.frombuffer(reply[:], dtype=dtype)

        # scale by lockin period
        # (conductor already scales by max amplitude)
        scale = self.get_ns(which="adc")
        data /= scale
        data_I, data_Q = data[0::2], data[1::2]
        # complex, can't use np.frombuffer because array is not C-contiguous
        data_I = data_I[0::2] + 1j * data_I[1::2]
        data_Q = data_Q[0::2] + 1j * data_Q[1::2]
        # reshape
        data_I.shape = (nr_freqs, num_demod // 2)
        data_Q.shape = (nr_freqs, num_demod // 2)
        # group inputs
        d = dict()
        for port, f1, l1, f2, l2 in self._input_map:
            d[port] = (
                self._input_frequencies[f1:l1:2],
                data_I[:, f2 // 2 : l2 // 2],
                data_Q[:, f2 // 2 : l2 // 2],
            )
        return d

    def _first_free_output(self) -> int:
        if np.any(self._output_used):
            used = np.nonzero(self._output_used)
            last = used[0][-1] + 1
            return int(np.ceil(last / FREQ_PER_GROUP) * FREQ_PER_GROUP)
        return 0

    def _first_free_input(self) -> int:
        if np.any(self._input_used):
            used = np.nonzero(self._input_used)
            last = used[0][-1] + 1
            return int(np.ceil(last / FREQ_PER_GROUP) * FREQ_PER_GROUP)
        return 0

    def _resync_phases(self):
        if self.dac_direct:
            self._output_phases_q = (
                self._output_phases_i
                + math.tau * self._output_frequencies / self.get_fs(which="dac")
            )
        if self.adc_direct:
            self._input_phases_q = (
                self._input_phases_i
                + math.tau * self._input_frequencies / self.get_fs(which="adc")
            )
        else:
            self._input_phases_q = self._input_phases_i


class SymmetricGroup:
    """Settings of a symmetric lock-in group.

    Used as return type by :meth:`SymmetricLockin.add_symmetric_group`. Contains access functions
    for changing the settings of this input-output group.

    The lock-in output is divided into 16 groups. Each group is capable of driving tones at 12
    different frequencies, for a total of 192 frequencies. Each tone has a configurable frequency,
    phase and amplitude. Each group can be output on one or more output ports, and acquire data
    from a single (configurable) input port.

    Warning:
        Do not instantiate this class directly! Call :meth:`SymmetricLockin.add_symmetric_group` to
        obtain a valid instance.
    """

    def __init__(
        self,
        input_port: int,
        output_ports: ArrayLike,
        nr_freq: int,
        lockin: "SymmetricLockin",
    ):
        input_port = int(input_port)
        if input_port < 1 or input_port > lockin.hardware.nr_ports:
            raise ValueError(f"port must be in [1, {lockin.hardware.nr_ports}]")
        output_ports = np.atleast_1d(output_ports).astype(np.int64)
        if np.any(output_ports < 1) or np.any(output_ports > lockin.hardware.nr_ports):
            raise ValueError(f"output_ports must be in [1, {lockin.hardware.nr_ports}]")
        nr_freq = int(nr_freq)
        if nr_freq < 1 or nr_freq > NR_LCK_FREQ:
            raise ValueError(f"nr_freq must be in [1, {NR_LCK_FREQ}]")
        self.input_port: int = input_port
        self.output_ports: NDArray[np.int64] = output_ports
        self.nr_freq: int = nr_freq
        self.lockin: SymmetricLockin = lockin
        self._frequencies: NDArray[np.float64] = np.zeros(nr_freq, np.float64)
        self._phases: NDArray[np.float64] = np.zeros(nr_freq, np.float64)
        self._output_scales: NDArray[np.float64] = np.zeros(nr_freq, np.float64)

    def get_frequencies(self) -> np.ndarray:
        """Get the lock-in frequencies.

        Returns:
            :class:`~numpy.ndarray` of frequencies in Hz. ``dtype=np.float64``
        """
        # get every second frequency to keep same number as input frequencies
        return self._frequencies.copy()

    def set_frequencies(self, freqs: ArrayLike) -> "SymmetricGroup":
        """Set the lock-in frequencies.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Args:
            freqs (float or array_like): frequency/ies in Hz. If less than available number of
                frequencies, the rest is set to zero.

        Notes:
            This function performs no tuning, make sure ``freqs`` are
            :meth:`tuned <.SymmetricLockin.tune>` to the user needs before calling this function.

        See also:
            :meth:`.SymmetricLockin.set_df`
            :meth:`.SymmetricLockin.tune`
        """
        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        if len(freqs) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(freqs)}")
        if np.any(freqs < 0):
            raise ValueError("freqs must be positive")
        max_freq = self.lockin.get_fs("dac") / 2
        if np.any(freqs >= max_freq):
            raise ValueError(f"freqs must be less than {max_freq/1e6} MHz")

        self.lockin._apply_required_if = True
        self._frequencies.fill(0)
        self._frequencies[0 : len(freqs)] = freqs

        return self

    def get_amplitudes(self) -> np.ndarray:
        """Get the lock-in output amplitudes.

        Returns:
            :class:`~numpy.ndarray` of amplitudes for each frequency with +/- 1.0 being full scale.
            ``dtype=np.float64``.
        """
        return self._output_scales.copy()

    def set_amplitudes(self, amps: ArrayLike) -> "SymmetricGroup":
        """Set the lock-in output amplitudes.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Args:
            amps (float or array_like): amplitudes with +/- 1.0 being full scale. If less than
                available number of frequencies, set the rest to zero.
        """
        amps = np.atleast_1d(amps).astype(np.float64)
        if len(amps) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(amps)}")
        if np.any(np.abs(amps) > 1.0):
            raise ValueError("Max amplitude is 1.0")

        self.lockin._apply_required_if = True
        self._output_scales.fill(0)
        # set every second scale to keep same number as input frequencies
        self._output_scales[0 : len(amps)] = amps

        return self

    def get_phases(self, *, deg: bool = False) -> np.ndarray:
        """Get the lock-in output phases.

        Args:
            deg: if :obj:`True`, get the phases in degrees in [-180.0, +180.0]; if :obj:`False`
                (default) radians in [-π, +π].

        Returns:
            :class:`~numpy.ndarray` of phases in rad/deg for each frequency. ``dtype=np.float64``.
        """
        if deg:
            phases = self._phases * 180.0 / np.pi
        else:
            phases = self._phases.copy()
        return phases

    def set_phases(self, phases: ArrayLike, *, deg: bool = False) -> "SymmetricGroup":
        """Set the lock-in output phases.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Args:
            phases (float or array_like): phases in rad/deg. If less than available number of
                frequencies, set the rest to zero.
            deg: if :obj:`True`, set the phases in degrees; if :obj:`False` (default) radians.
        """
        phases = np.atleast_1d(phases).astype(np.float64)
        if len(phases) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(phases)}")

        if deg:
            phases = phases / 180.0 * np.pi

        self.lockin._apply_required_if = True
        self._phases.fill(0)
        self._phases[0 : len(phases)] = phases

        return self


class OutputGroup:
    """Settings of a lock-in output group.

    Used as return type by :meth:`Lockin.add_output_group`. Contains access functions for changing
    the settings of this output group.

    The lock-in output is divided into 16 groups. Each group is capable of driving tones at 12
    different frequencies, for a total of 192 frequencies. Each tone has a configurable frequency,
    phase and amplitude. Each group can be output on one or more output ports.

    Warning:
        Do not instantiate this class directly! Call :meth:`Lockin.add_output_group` to obtain a
        valid instance.
    """

    def __init__(self, ports: ArrayLike, nr_freq: int, lockin: Lockin):
        ports = np.atleast_1d(ports).astype(np.int64)
        if np.any(ports < 1) or np.any(ports > lockin.hardware.nr_ports):
            raise ValueError(f"ports must be in [1, {lockin.hardware.nr_ports}]")
        nr_freq = int(nr_freq)
        if nr_freq < 1 or nr_freq > NR_LCK_FREQ:
            raise ValueError(f"nr_freq must be in [1, {NR_LCK_FREQ}]")
        self.ports: NDArray[np.int64] = ports
        self.nr_freq: int = nr_freq
        self.lockin: Lockin = lockin
        self._output_frequencies: NDArray[np.float64] = np.zeros(nr_freq, np.float64)
        self._output_phases_i: NDArray[np.float64] = np.zeros(nr_freq, np.float64)
        self._output_phases_q: Optional[NDArray[np.float64]] = (
            None if lockin.dac_direct else np.zeros(nr_freq, np.float64)
        )
        self._output_scales: NDArray[np.float64] = np.zeros(nr_freq, np.float64)

    def get_frequencies(self) -> np.ndarray:
        """Get the lock-in output frequencies.

        Returns:
            :class:`~numpy.ndarray` of frequencies in Hz. ``dtype=np.float64``
        """
        # get every second frequency to keep same number as input frequencies
        return self._output_frequencies.copy()

    def set_frequencies(self, freqs: ArrayLike) -> "OutputGroup":
        """Set the lock-in output frequencies.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Args:
            freqs (float or array_like): frequency/ies in Hz. If less than available number of
                frequencies, the rest is set to zero.

        Notes:
            This function performs no tuning, make sure ``freqs`` are :meth:`tuned <.Lockin.tune>`
            to the user needs before calling this function.

        See also:
            :meth:`Lockin.set_df`
            :meth:`Lockin.tune`
        """
        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        if len(freqs) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(freqs)}")
        if np.any(freqs < 0):
            raise ValueError("freqs must be positive")
        max_freq = self.lockin.get_fs("dac") / 2
        if np.any(freqs >= max_freq):
            raise ValueError(f"freqs must be less than {max_freq/1e6} MHz")

        self.lockin._apply_required_if = True
        self._output_frequencies.fill(0)
        self._output_frequencies[0 : len(freqs)] = freqs

        return self

    def get_amplitudes(self) -> np.ndarray:
        """Get the lock-in output amplitudes.

        Returns:
            :class:`~numpy.ndarray` of amplitudes for each frequency with +/- 1.0 being full scale.
            ``dtype=np.float64``.
        """
        # get every second scale to keep same number as input frequencies
        return self._output_scales.copy()

    def set_amplitudes(self, amps: ArrayLike) -> "OutputGroup":
        """Set the lock-in output amplitudes.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Args:
            amps (float or array_like): amplitudes with +/- 1.0 being full scale. If less than
                available number of frequencies, set the rest to zero.
        """
        amps = np.atleast_1d(amps).astype(np.float64)
        if len(amps) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(amps)}")
        if np.any(np.abs(amps) > 1.0):
            raise ValueError("Max amplitude is 1.0")

        self.lockin._apply_required_if = True
        self._output_scales.fill(0)
        # set every second scale to keep same number as input frequencies
        self._output_scales[0 : len(amps)] = amps

        return self

    def get_phases(self, *, deg: bool = False):
        """Get the lock-in output phases.

        Args:
            deg: if :obj:`True`, get the phases in degrees in [-180.0, +180.0]; if :obj:`False`
                (default) radians in [-π, +π].

        Returns:
            :class:`~numpy.ndarray` of phases in rad/deg for each frequency. ``dtype=np.float64``.
        """
        if deg:
            phases = self._output_phases_i * 180.0 / np.pi
        else:
            phases = self._output_phases_i.copy()
        # get every second phase to keep same number as input frequencies
        return phases

    def set_phases(
        self, phases: ArrayLike, phases_q: Optional[ArrayLike] = None, *, deg: bool = False
    ) -> "OutputGroup":
        """Set the lock-in output phases.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Args:
            phases (float or array_like): phases in rad/deg. If less than available number of
                frequencies, set the rest to zero. When using the digital mixers (``dac_mode`` is
                one of :class:`DacMode.Mixedxx <.DacMode>`), sets the phase of the I port of the
                upconversion mixer.
            phases_q (float or array_like, optional): when using the digital mixers, sets the phase
                of the Q port of the upconversion mixer. In direct mode (``dac_mode`` is
                :class:`DacMode.Direct <.DacMode>`), setting ``phases_q`` throws a
                :class:`ValueError` exception.
            deg: if :obj:`True`, set the phases in degrees; if :obj:`False` (default) radians.

        Raises:
            ValueError: if ``phases_q`` is not ``None`` in direct mode
        """
        phases = np.atleast_1d(phases).astype(np.float64)
        if len(phases) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(phases)}")
        if self.lockin.dac_direct:
            if phases_q is not None:
                raise ValueError("setting phases_q is not allowed if dac_mode is DacDirect!")
        else:
            if phases_q is None:
                raise ValueError("must provide phases_q if dac_mode is not DacDirect!")
            phases_q = np.atleast_1d(phases_q).astype(np.float64)
            if phases_q.shape != phases.shape:
                raise ValueError("phases_q must have same shape as phases!")

        if deg:
            phases = phases / 180.0 * np.pi

        self.lockin._apply_required_if = True
        self._output_phases_i.fill(0)
        self._output_phases_i[0 : len(phases)] = phases

        if self.lockin.dac_direct:
            pass
        else:
            assert self._output_phases_q is not None
            assert phases_q is not None
            self._output_phases_q.fill(0)
            self._output_phases_q[0 : len(phases_q)] = phases_q

        return self


class InputGroup:
    """Settings of a lock-in input group.

    Used as return type by :meth:`Lockin.add_input_group`. Contains access functions for changing
    the settings of this input group.

    The lock-in input is divided into 16 groups. Each group is capable of demodulating 12 different
    quadratures, for a total of 192 demodulations (96 I/Q pairs). Each demodulator has a
    configurable frequency and phase. Each group can acquire data from a single (configurable)
    input port.

    Warning:
        Do not instantiate this class directly! Call :meth:`Lockin.add_input_group` to obtain a
        valid instance.
    """

    def __init__(self, port: int, nr_freq: int, lockin: Lockin):
        port = int(port)
        if port < 1 or port > lockin.hardware.nr_ports:
            raise ValueError(f"port must be in [1, {lockin.hardware.nr_ports}]")
        nr_freq = int(nr_freq)
        # TODO: fix check? we might already check when creating the instance from Lockin
        # if VARIANT == 7 and (nr_freq < 1 or nr_freq > NR_LCK_FREQ // 2):
        #     raise ValueError(f"nr_freq must be in [1, {NR_LCK_FREQ//2}]")
        # if VARIANT == 8 and (nr_freq < 1 or nr_freq > NR_LCK_FREQ):
        #     raise ValueError(f"nr_freq must be in [1, {NR_LCK_FREQ}]")
        self.port: int = port
        self.nr_freq: int = nr_freq
        self.lockin: Lockin = lockin
        self._input_frequencies: NDArray[np.float64] = np.zeros(nr_freq, np.float64)
        self._input_phases_i: NDArray[np.float64] = np.zeros(nr_freq, np.float64)

    def get_frequencies(self) -> np.ndarray:
        """Get the lock-in input frequencies.

        Returns:
            :class:`~numpy.ndarray` of frequencies in Hz. ``dtype=np.float64``
        """
        # get every second frequency to since every frequency is replicated for I and Q
        return self._input_frequencies.copy()

    def set_frequencies(self, freqs: ArrayLike) -> "InputGroup":
        """Set the lock-in input frequencies.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Args:
            freqs (float or array_like): frequency/ies in Hz. If less than available number of
                frequencies, the rest is set to zero.

        Notes:
            This function performs no tuning, make sure ``freqs`` are :meth:`tuned <.Lockin.tune>`
            to the user needs before calling this function.

        See also:
            :meth:`Lockin.set_df`
            :meth:`Lockin.tune`
        """
        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        if len(freqs) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(freqs)}")
        if np.any(freqs < 0):
            raise ValueError("freqs must be positive")
        max_freq = self.lockin.get_fs("adc") / 2
        if np.any(freqs >= max_freq):
            raise ValueError(f"freqs must be less than {max_freq/1e6} MHz")

        self.lockin._apply_required_if = True
        self._input_frequencies.fill(0)
        self._input_frequencies[: len(freqs)] = freqs

        return self

    def get_phases(self, *, deg: bool = False) -> np.ndarray:
        """Get the lock-in input phases.

        Args:
            deg: if :obj:`True`, get the phases in degrees in [-180.0, +180.0]; if :obj:`False`
                (default) radians in [-π, +π].

        Returns:
            :class:`~numpy.ndarray` of phases in rad/deg for each frequency. ``dtype=np.float64``.
        """
        if deg:
            phases = self._input_phases_i * 180.0 / np.pi
        else:
            phases = self._input_phases_i.copy()
        # get every second phase to keep same number as input frequencies
        return phases

    def set_phases(self, phases: ArrayLike, *, deg: bool = False) -> "InputGroup":
        """Set the lock-in input phases.

        **The new setting is not applied until** :meth:`Lockin.apply_settings` **is called!**

        Args:
            phases (float or array_like): phases in rad/deg. If less than available number of
                frequencies, set the rest to zero. When using the digital mixers (``adc_mode`` is
                :class:`AdcMode.Mixed <.AdcMode>`), sets the phase of both the I and the Q port of
                the downconversion mixer.
            deg: if :obj:`True`, set the phases in degrees; if :obj:`False` (default) radians.
        """
        phases = asarray(phases, np.float64)
        if len(phases) > self.nr_freq:
            raise ValueError(f"Group contains {self.nr_freq} tones, got {len(phases)}")

        if deg:
            phases *= np.pi / 180.0

        self.lockin._apply_required_if = True
        self._input_phases_i.fill(0)
        self._input_phases_i = phases

        return self


# where not obvious, changes from Lockin are marked with NOTE
class SymmetricLockin(Lockin):
    VARIANT = 8

    def __init__(
        self,
        *,
        ext_ref_clk: Union[None, bool, int, float] = False,
        force_reload: bool = False,
        dry_run: bool = False,
        address: Optional[str] = None,
        port: Optional[int] = None,
        adc_mode: Union[AdcMode, List[AdcMode]] = AdcMode.Mixed,
        adc_fsample: Optional[Union[AdcFSample, List[AdcFSample]]] = None,
        dac_mode: Union[DacMode, List[DacMode]] = DacMode.Mixed,
        dac_fsample: Optional[Union[DacFSample, List[DacFSample]]] = None,
        force_config: bool = False,
    ):
        r"""Special-purpose version of :class:`Lockin` with same frequencies on input and output
        ports (symmetric).

        The symmetric lock-in only supports :ref:`Mixed mode <converter modes>`. The digital mixers
        are configured for single-sideband upconversion and downconversion, using the upper
        sideband. The frequency of the output tones will therefore be the sum of the IF frequency
        set with :meth:`~.SymmetricGroup.set_frequencies` and of the LO frequency set with
        :meth:`hardware.configure_mixer <.Hardware.configure_mixer>`.

        Warnings:
            Create only one instance at a time. This class is designed to be instantiated with
            Python's :ref:`with statement <python:with>`, see Examples section.

        Args:
            ext_ref_clk: if :obj:`None` or :obj:`False` use internal reference clock; if
                :obj:`True` use external reference clock (10 MHz); if :class:`float` or
                :class:`int` use external reference clock at ``ext_ref_clk`` Hz
            force_reload: if :obj:`True` re-configure clock and reload firmware even if there's no
                change from the previous settings.
            dry_run: if :obj:`True` don't connect to hardware, for testing only.
            address: IP address or hostname of the hardware. If :obj:`None`, use factory default
                ``"192.168.42.50"``.
            port: port number of the server running on the hardware. If :obj:`None`, use factory
                default ``7878``.
            adc_mode (AdcMode or list): configure the inputs to use the digital mixers for
                downconversion. Direct mode is not supported.
            adc_fsample (AdcFSample or list): configure the inputs sampling rate. If :obj:`None`
                (default), choose optimal rate automatically. See Notes.
            dac_mode (DacMode or list): configure the outputs to use the digital mixers for
                upconversion. Direct mode is not supported. See Notes.
            dac_fsample (DacFSample or list): configure the outputs sampling rate. If :obj:`None`
                (default), choose optimal rate automatically. See Notes.
            force_config: if :obj:`True` skip checks on ``DacMode``\ s not recommended for high DAC
                sampling rates.

        Raises:
            ValueError: if ``adc_mode`` or ``dac_mode`` are not valid :ref:`converter modes`;
                if ``adc_fsample`` or ``dac_fsample`` are not valid :ref:`converter rates`.

        Notes:
            In all the Examples, it is assumed that the imports ``import numpy as np`` and
            ``from presto import lockin`` have been performed, and that this class has been
            instantiated in the form ``lck = lockin.SymmetricLockin()``, or, **much much better**,
            using the ``with lockin.SymmetricLockin() as lck`` construct as below.

            For an introduction to ``adc_mode`` and ``dac_mode``, see :doc:`../special/direct_mixed`.
            For valid values of ``adc_mode`` and ``dac_mode``, see :ref:`converter modes`. For
            valid values of ``adc_fsample`` and ``dac_fsample``, see :ref:`converter rates`. For
            advanced configuration, e.g. different converter rates on different ports, see
            :ref:`adv tile`.
        """
        modes = as_flat_list(adc_mode)
        modes.extend(as_flat_list(dac_mode))
        for mode in modes:
            if mode is AdcMode.Direct or mode is DacMode.Direct:
                raise ValueError("SymmetricLockin only works with ADCs and DACs in Mixed mode")
        super().__init__(
            ext_ref_clk=ext_ref_clk,
            force_reload=force_reload,
            dry_run=dry_run,
            address=address,
            port=port,
            adc_mode=adc_mode,
            adc_fsample=adc_fsample,
            dac_mode=dac_mode,
            dac_fsample=dac_fsample,
            force_config=force_config,
        )

    def check_current_consumption(self):
        # TODO
        pass

    def apply_settings(self, *, auto_sync: bool = True, only_if: bool = False):
        """Apply the settings to the hardware.

        Args:
            auto_sync: if ``True`` (default), trigger signal generation internally. Set to
                ``False`` to synchronize to an external source, e.g. a Metronomo unit.

        Note:
            Prior to a call to this function, any change of settings has no effect on the hardware.
        """
        if not only_if:
            self._apply_rf_settings(do_sync=auto_sync)

        if self._apply_required_if:
            self._clear_outputs()
            self._clear_inputs()

            for sg in self._output_groups:
                assert isinstance(sg, SymmetricGroup)
                self._add_output(
                    sg.output_ports, sg._frequencies, sg._output_scales, sg._phases, sg._phases
                )
            for sg in self._input_groups:
                assert isinstance(sg, SymmetricGroup)
                self._add_input(sg.input_port, sg._frequencies, sg._phases)

            self.check_current_consumption()

            if not self.dry_run:
                # disable outputs
                self.hardware.blank_output(range(1, self.hardware.nr_ports + 1), True)

                # correct for latencies within one group
                # (note that input_phases is also output_phases in SymmetricLockin)
                # choose phases so that output looks as you would expect
                # NOTE: we then undo this correction in get_pixels()
                idx_in_group = np.arange(len(self._input_phases_i)) % FREQ_PER_GROUP
                # actually revert the order in the group, because of poor life choices
                idx_in_group = FREQ_PER_GROUP - idx_in_group - 1
                correction = idx_in_group * self.CLK_T * 2 * np.pi * self._input_frequencies
                input_phases_i = self._input_phases_i - correction
                input_phases_q = self._input_phases_q - correction
                # send settings
                self.hardware._send_command(
                    cmd.Msg__LckSetInFreqPhase(
                        (  # pyright: ignore[reportArgumentType]
                            self._input_frequencies,
                            input_phases_i,
                            input_phases_q,
                        )
                    )
                )
                # NOTE: there's no output phases in SymmetricLockin
                # NOTE: scales and frequencies have reversed order in symmetric lockin
                self.hardware._send_command(cmd.Msg__LckSetScale(self._output_scales[::-1]))  # pyright: ignore[reportArgumentType]
                self.hardware._send_command(
                    cmd.Msg__LckSetDf(
                        (
                            self.get_df(),
                            self._reset_phase,
                            self._trigctrl,
                            self._trigstart,
                            self._trigstart + self._trigwidth,
                        )
                    )
                )

                for channel in range(self.hardware.nr_ports):
                    mask = self._output_mask[channel]
                    # NOTE: groups are also upside-down in symmetric lockin
                    mask = int(f"{mask:016b}"[::-1], 2)
                    self.hardware._send_command(cmd.Msg__LckGroupMask((channel, mask)))

                for i in range(NR_GROUPS):
                    self.hardware._send_command(
                        cmd.Msg__LckInputSelect((i, self._input_select[i]))
                    )

                # signal generation is started on a sysref edge
                if auto_sync:
                    # trigger sysref
                    self.hardware.sync()

                # enable outputs
                self.hardware.sleep(self.get_Tm(), False)
                self.hardware.blank_output(range(1, self.hardware.nr_ports + 1), False)

                self.hardware.assert_errors()
            self._apply_required_if = False

    def _add_input(self, port: int, freqs: ArrayLike, phases: ArrayLike):
        if port in [x[0] for x in self._input_map]:
            raise ValueError("Can only add an input once")

        freqs = np.atleast_1d(np.abs(freqs)).astype(np.float64)
        # NOTE: not doubling the frequencies
        phases = np.atleast_1d(phases).astype(np.float64)

        first = self._first_free_input()
        last = first + freqs.shape[0]

        if last > NR_LCK_FREQ:
            raise ValueError("Too many input frequencies used")

        self._input_frequencies[first:last] = freqs
        self._input_phases_i[first:last] = phases  # NOTE: not setting different phases on Q
        for i in set(np.arange(first, last, dtype=np.int64) // FREQ_PER_GROUP):
            self._input_select[i] = port - 1
        self._input_used[first:last] = True
        if len(self._input_map) == 0:
            self._input_map.append((port, first, last, first, last))
        else:
            tot_used = self._input_map[-1][4]
            self._input_map.append((port, first, last, tot_used, tot_used + (last - first)))

        self._resync_phases()

    def add_input_group(self, *args, **kwargs):  # pyright: ignore
        """"""  # hide in documentation
        raise NotImplementedError("use add_symmetric_group instead")

    def add_output_group(self, *args, **kwargs):  # pyright: ignore
        """"""  # hide in documentation
        raise NotImplementedError("use add_symmetric_group instead")

    def add_symmetric_group(
        self,
        input_port: int,
        output_ports: ArrayLike,
        nr_freq: int,
    ) -> SymmetricGroup:
        """Create and return a new :class:`symmetric group <SymmetricGroup>`.

        Args:
            input_port: which input port the group should sample data from
            output_ports (int or array_like): which output port(s) the group should output data to.
                If a :class:`list`, the output will be replicated on all ``ports``
            nr_freq: how many frequencies the input group should modulate/demodulate
        """
        g = SymmetricGroup(input_port, output_ports, nr_freq, self)
        self._input_groups.append(g)
        self._output_groups.append(g)
        self._add_input(input_port, np.zeros(nr_freq), np.zeros(nr_freq))
        self._add_output(
            output_ports,
            np.zeros(nr_freq),
            np.zeros(nr_freq),
            np.zeros(nr_freq),
            np.zeros(nr_freq),
        )
        return g

    def _resync_phases(self):
        # NOTE: no direct case
        self._input_phases_q = self._input_phases_i - np.pi / 2  # NOTE: add phase to Q for HSB

    def get_pixels(
        self,
        n: int,
        *,
        summed: bool = False,
        fir_coeffs: Optional[ArrayLike] = None,
        nsum: int = 250,
        quiet: bool = False,
        auto_sync: bool = True,
    ) -> dict:
        r"""Get lock-in packets (pixels) from the hardware.

        Args:
            n: the number of lock-in packets to measure. When ``summed=True``, ``n`` is the number
                of means and standard deviation acquired: the number of lock-in packets measured
                will be ``n*nsum``.
            summed: when ``True``, calculate on the hardware the mean and standard deviation of the
                acquired data in chunks of ``nsum`` lock-in packets.
            fir_coeffs (array_like of float): coefficients for FIR filter to be applied to measured
                data. 43 coefficients must be provided, or pass None (default) to disable the
                filter. Not available if ``summed=False``. See also *Notes* and *Examples* sections.
            nsum: Ignored if ``summed=False``. How many lock-in packets (at rate :meth:`get_df`\ )
                The resulting data rate will be ``df / nsum``.
            quiet: if True, don't check for inputs out of range
            auto_sync: if ``True`` (default), trigger signal acquisition internally. Set to
                ``False`` to synchronize to an external source, e.g. a Metronomo unit.

        Returns:
            a dictionary with key ``port`` (:class:`int`) and value depending on the argument
            ``summed``.

            The key is always:

              - ``port`` (:class:`int`): input port measured

            When ``summed=False`` (default), the value is a tuple of:

              - ``freqs`` (:class:`~numpy.ndarray`, ``dtype=np.float64``): frequencies at which the
                lockin measurement was done.
              - ``pixels`` (:class:`~numpy.ndarray`, ``dtype=np.complex64``): measured lock-in data
                in ratio of full-scale input. ``shape`` is ``(n, len(freqs))``.

            When ``summed=True``, the value is a tuple of:

              - ``freqs`` (:class:`~numpy.ndarray`, ``dtype=np.float64``): frequencies at which the
                lockin measurement was done.
              - ``mean`` (:class:`~numpy.ndarray`, ``dtype=np.complex64``): calculated mean of
                ``nsum`` consecutive lock-in packets. ``shape`` is ``(n, len(freqs))``.
              - ``std`` (:class:`~numpy.ndarray`, ``dtype=np.complex64``): calculated standard
                deviation of ``nsum`` consecutive lock-in packets. ``shape`` is ``(n, len(freqs))``.
                The standard deviation has a real and an imaginary part; ``abs(std)`` is the total
                standard deviation according to
                `Complex random variable <https://en.wikipedia.org/wiki/Complex_random_variable#Variance_and_pseudo-variance>`_.

        Raises:
            RuntimeError: if :meth:`apply_settings` was not called after changing some setting

        Notes:
            This method locks execution until at least ``n`` measured packets are available.

            Useful functions for computing the coefficients ``fir_coeffs`` for the FIR filter are
            :func:`~scipy.signal.remez` and :func:`~scipy.signal.firwin` in the
            :mod:`scipy.signal` module.

        Examples:
            Measure 1k lock-in packets, and low-pass filter the measured data:

            >>> from scipy.signal import firwin
            >>> coeffs = firwin(43, 80e3, fs=lck.get_df())  # low-pass filter with 80 kHz cutoff
            >>> data = lck.get_pixels(n=1000, fir_coeffs=coeffs)
            >>> freqs, pixels = data[input_port]
            >>> freqs.shape
            (32,)
            >>> pixels.shape
            (1000, 32)

            Measure 100k lock-in packets, and compute mean and standard deviation in chunks of 100
            packets:

            >>> data = lck.get_pixels(n=1000, summed=True, nsum=100)
            >>> freqs, mean, std = data[input_port]
            >>> freqs.shape
            (32,)
            >>> mean.shape
            (1000, 32)
            >>> std.shape
            (1000, 32)
        """
        # common to Lockin and SymmetricLockin
        num_pixels, num_demod, data = self._get_pixels_common(
            n=n,
            summed=summed,
            fir_coeffs=fir_coeffs,
            nsum=nsum,
            quiet=quiet,
            auto_sync=auto_sync,
            rpu_params=None,
        )
        # specific to SymmetricLockin
        return self._data_to_pixels(
            data=data,
            summed=summed,
            num_pixels=num_pixels,
            num_demod=num_demod,
        )

    def _data_to_pixels(
        self,
        *,
        data: npt.NDArray[np.float32],
        summed: bool,
        num_pixels: int,
        num_demod: int,
    ) -> dict:
        # NOTE: specific to SymmetricLockin

        if summed:
            # NOTE: no direct case
            mean_I = data[0::4]
            var_I = data[1::4]
            mean_Q = data[2::4]
            var_Q = data[3::4]
            # scale to account for SSB
            mean_I *= 2
            var_I *= 4
            mean_Q *= 2
            var_Q *= 4

            mean_I.shape = (num_pixels, num_demod)
            mean_Q.shape = (num_pixels, num_demod)
            var_I.shape = (num_pixels, num_demod)
            var_Q.shape = (num_pixels, num_demod)
            d = dict()
            for port, f1, l1, f2, l2 in self._input_map:
                # undo phase correction added in apply_settings()
                idx_in_group = np.arange(f1, l1) % FREQ_PER_GROUP
                idx_in_group = FREQ_PER_GROUP - idx_in_group - 1
                rotation_phases = (
                    -idx_in_group * self.CLK_T * 2 * np.pi * self._input_frequencies[f1:l1]
                )
                mean_C = (
                    mean_I[:, f2:l2] + 1j * mean_Q[:, f2:l2]
                )  # assume SSB, fine both HSB and LSB
                mean_C *= np.exp(1j * rotation_phases)
                varI = var_I[:, f2:l2]
                varQ = var_Q[:, f2:l2]
                std = np.sqrt(varI) + 1j * np.sqrt(varQ)
                d[port] = (self._input_frequencies[f1:l1], mean_C, std)
            return d

        else:
            # NOTE: no direct case
            data *= 2  # x2 to account for SSB
            data_C = np.frombuffer(data, dtype=np.complex64)
            # reshape
            data_C.shape = (num_pixels, num_demod)
            # group inputs
            d = dict()
            for port, f1, l1, f2, l2 in self._input_map:
                # undo phase correction added in apply_settings()
                idx_in_group = np.arange(f1, l1) % FREQ_PER_GROUP
                idx_in_group = FREQ_PER_GROUP - idx_in_group - 1
                rotation_phases = (
                    -idx_in_group * self.CLK_T * 2 * np.pi * self._input_frequencies[f1:l1]
                )
                data_group = data_C[:, f2:l2]
                data_group *= np.exp(1j * rotation_phases)
                d[port] = (
                    self._input_frequencies[f1:l1],
                    data_group,
                )
            return d


class LockinReceiver(StreamReceiver[dict]):
    """A receiver of lockin data running in the background.

    Used as return type by :meth:`Lockin.stream_pixels`.

    Warning:
        This class is *experimental* and the exposed API might change in future releases.

    Warning:
        Do not instantiate this class directly! Call :meth:`Lockin.stream_pixels` to obtain a
        valid instance.

    Examples:

        >>> with lockin.Lockin(
        >>>     address=PRESTOs_IP_ADDRESS,
        >>> ) as lck:
        >>>     lck.set_df(1e3)
        >>>
        >>>     og = lck.add_output_group(OUTPUT_PORT, 1)
        >>>     og.set_frequencies(240e6).set_amplitudes(0.7).set_phases(0.0)
        >>>
        >>>     ig = lck.add_input_group(INPUT_PORT, 1)
        >>>     ig.set_frequencies(240e6)
        >>>
        >>>     lck.apply_settings()
        >>>
        >>>     # receive pixels with get_pixels
        >>>     _, data0 = lck.get_pixels(1_000)[INPUT_PORT]
        >>>
        >>>     # receive pixels with a LockinReceiver
        >>>     with lck.stream_pixels() as recv:
        >>>         _, data1 = recv.get_last(1_000)[INPUT_PORT]

    """

    def __init__(
        self,
        *,
        lck: ReferenceType[Lockin],
        sock: socket.socket,
        summed: bool,
        bytes_per_meas: int,
        extra_bytes: int,
        buf_size: int = 1 << 30,
    ):
        self._lck = lck
        self._summed = summed

        super().__init__(
            sock=sock,
            bytes_per_meas=bytes_per_meas,
            extra_bytes=extra_bytes,
            buf_size=buf_size,
        )

    def _get_lck(self) -> Lockin:
        lck = self._lck()
        if lck is None:
            raise RuntimeError("the associated Lockin object has been destroyed!")
        else:
            return lck

    def _process_data(self, nr_meas: int, buf: bytearray):
        dtype = np.dtype(np.float32).newbyteorder("<")
        data = np.frombuffer(buf, dtype=dtype)

        lck = self._get_lck()
        return lck._data_to_pixels(
            data=data,
            summed=self._summed,
            num_pixels=nr_meas,
            num_demod=-2,
        )
