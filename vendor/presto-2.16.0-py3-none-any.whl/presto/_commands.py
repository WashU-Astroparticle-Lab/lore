# pyre-strict
from dataclasses import dataclass
import typing
from . import _serde_types as st
from . import _bincode as bincode


class Msg:
    VARIANTS = []  # type: typing.Sequence[typing.Type[Msg]]

    def bincode_serialize(self) -> bytes:
        return bincode.serialize(self, Msg)

    @staticmethod
    def bincode_deserialize(input: bytes) -> "Msg":
        v, buffer = bincode.deserialize(input, Msg)
        if buffer:
            raise st.DeserializationError("Some input bytes were not read")
        return v


@dataclass(frozen=True)
class Msg__Reset(Msg):
    INDEX = 0  # type: int
    pass


@dataclass(frozen=True)
class Msg__Version(Msg):
    INDEX = 1  # type: int
    pass


@dataclass(frozen=True)
class Msg__Quit(Msg):
    INDEX = 2  # type: int
    pass


@dataclass(frozen=True)
class Msg__ErrorList(Msg):
    INDEX = 3  # type: int
    pass


@dataclass(frozen=True)
class Msg__Echo(Msg):
    INDEX = 4  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__Sleep(Msg):
    INDEX = 5  # type: int
    value: st.float64


@dataclass(frozen=True)
class Msg__LoadFirmware(Msg):
    INDEX = 6  # type: int
    value: str


@dataclass(frozen=True)
class Msg__NrPorts(Msg):
    INDEX = 7  # type: int
    pass


@dataclass(frozen=True)
class Msg__WhichBoard(Msg):
    INDEX = 8  # type: int
    pass


@dataclass(frozen=True)
class Msg__ClockInit(Msg):
    INDEX = 9  # type: int
    value: st.uint32


@dataclass(frozen=True)
class Msg__ClockSync(Msg):
    INDEX = 10  # type: int
    pass


@dataclass(frozen=True)
class Msg__ClockSetLmx(Msg):
    INDEX = 11  # type: int
    value: typing.Tuple[st.uint64, st.uint64, st.uint32]


@dataclass(frozen=True)
class Msg__PrestoInit(Msg):
    INDEX = 12  # type: int
    pass


@dataclass(frozen=True)
class Msg__PrestoVarVer(Msg):
    INDEX = 13  # type: int
    pass


@dataclass(frozen=True)
class Msg__PrestoRpuVer(Msg):
    INDEX = 14  # type: int
    pass


@dataclass(frozen=True)
class Msg__PrestoRun(Msg):
    INDEX = 15  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__PrestoDmaStart(Msg):
    INDEX = 16  # type: int
    value: typing.Tuple[st.uint64, st.uint64, st.uint32, bool]


@dataclass(frozen=True)
class Msg__PrestoDmaWait(Msg):
    INDEX = 17  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__PrestoDmaStop(Msg):
    INDEX = 18  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__PrestoDmaGet(Msg):
    INDEX = 19  # type: int
    value: typing.Tuple[st.uint64, bool, bool]


@dataclass(frozen=True)
class Msg__PrestoDmaStatus(Msg):
    INDEX = 20  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__PrestoDmaClear(Msg):
    INDEX = 21  # type: int
    value: st.uint32


@dataclass(frozen=True)
class Msg__PrestoOcmError(Msg):
    INDEX = 22  # type: int
    pass


@dataclass(frozen=True)
class Msg__PrestoConvMode(Msg):
    INDEX = 23  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__PrestoDcBias(Msg):
    INDEX = 24  # type: int
    value: typing.Tuple[st.uint16, st.float64, st.uint8]


@dataclass(frozen=True)
class Msg__PrestoDcBiasRamp(Msg):
    INDEX = 25  # type: int
    value: typing.Tuple[st.uint16, st.float64, st.float64]


@dataclass(frozen=True)
class Msg__PrestoDcGetBias(Msg):
    INDEX = 26  # type: int
    value: st.uint8


@dataclass(frozen=True)
class Msg__PrestoDcRaw(Msg):
    INDEX = 27  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__PrestoDcReadback(Msg):
    INDEX = 28  # type: int
    pass


@dataclass(frozen=True)
class Msg__PrestoMarkerIn(Msg):
    INDEX = 29  # type: int
    pass


@dataclass(frozen=True)
class Msg__PrestoMarkerOut(Msg):
    INDEX = 30  # type: int
    value: st.uint8


@dataclass(frozen=True)
class Msg__PrestoIoeRaw(Msg):
    INDEX = 31  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__PrestoStreamDma(Msg):
    INDEX = 32  # type: int
    value: typing.Tuple[st.uint64, st.uint64, bool]


@dataclass(frozen=True)
class Msg__PrestoHistBuild(Msg):
    INDEX = 33  # type: int
    value: typing.Tuple[st.uint64, st.uint64, bool, st.uint32, st.uint16]


@dataclass(frozen=True)
class Msg__PrestoHistGet(Msg):
    INDEX = 34  # type: int
    pass


@dataclass(frozen=True)
class Msg__PrestoHist2DBuild(Msg):
    INDEX = 35  # type: int
    value: typing.Tuple[st.uint64, st.uint64, bool, st.uint32, st.uint16, st.uint16]


@dataclass(frozen=True)
class Msg__PrestoHist2DGet(Msg):
    INDEX = 36  # type: int
    pass


@dataclass(frozen=True)
class Msg__StreamAbort(Msg):
    INDEX = 37  # type: int
    pass


@dataclass(frozen=True)
class Msg__TestDither(Msg):
    INDEX = 38  # type: int
    value: typing.Tuple[st.uint64, bool]


@dataclass(frozen=True)
class Msg__TestFrequency(Msg):
    INDEX = 39  # type: int
    value: typing.Tuple[st.uint64, st.float64]


@dataclass(frozen=True)
class Msg__TestPhase(Msg):
    INDEX = 40  # type: int
    value: typing.Tuple[st.uint64, st.float64, st.float64]


@dataclass(frozen=True)
class Msg__TestScale(Msg):
    INDEX = 41  # type: int
    value: typing.Tuple[st.uint64, st.float64, st.float64]


@dataclass(frozen=True)
class Msg__TestBlank(Msg):
    INDEX = 42  # type: int
    value: typing.Tuple[st.uint64, bool]


@dataclass(frozen=True)
class Msg__TestDmaSrc(Msg):
    INDEX = 43  # type: int
    value: typing.Tuple[st.uint64, st.uint64]


@dataclass(frozen=True)
class Msg__PlsSeqCmd(Msg):
    INDEX = 44  # type: int
    value: typing.Tuple[st.uint64, st.uint64, "SeqCmd"]


@dataclass(frozen=True)
class Msg__PlsStoreMode(Msg):
    INDEX = 45  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__PlsScale(Msg):
    INDEX = 46  # type: int
    value: typing.Tuple[st.uint64, st.uint64, typing.Sequence[st.float64], st.uint32]


@dataclass(frozen=True)
class Msg__PlsMatchTmpl(Msg):
    INDEX = 47  # type: int
    value: typing.Tuple[st.uint64, st.uint64, typing.Sequence[st.float64]]


@dataclass(frozen=True)
class Msg__PlsOutTmpl(Msg):
    INDEX = 48  # type: int
    value: typing.Tuple[st.uint64, st.uint64, typing.Sequence[st.float64]]


@dataclass(frozen=True)
class Msg__PlsFreqLut(Msg):
    INDEX = 49  # type: int
    value: typing.Tuple[st.uint64, st.uint64, typing.Sequence[st.float64], st.uint32]


@dataclass(frozen=True)
class Msg__PlsPhaseLutIQ(Msg):
    INDEX = 50  # type: int
    value: typing.Tuple[
        st.uint64, st.uint64, typing.Sequence[st.float64], typing.Sequence[st.float64]
    ]


@dataclass(frozen=True)
class Msg__PlsEnvelope(Msg):
    INDEX = 51  # type: int
    value: typing.Tuple[st.uint64, st.uint64]


@dataclass(frozen=True)
class Msg__PlsNIter(Msg):
    INDEX = 52  # type: int
    value: typing.Tuple[st.uint64, st.uint64]


@dataclass(frozen=True)
class Msg__PlsMatchMux(Msg):
    INDEX = 53  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__PlsFbDefaultMask(Msg):
    INDEX = 54  # type: int
    value: typing.Sequence[st.uint64]


@dataclass(frozen=True)
class Msg__PlsFbConditionMask(Msg):
    INDEX = 55  # type: int
    value: typing.Sequence[st.uint64]


@dataclass(frozen=True)
class Msg__PlsFbUserMask(Msg):
    INDEX = 56  # type: int
    value: typing.Sequence[st.uint64]


@dataclass(frozen=True)
class Msg__PlsFbInvertCondition(Msg):
    INDEX = 57  # type: int
    value: typing.Sequence[st.uint64]


@dataclass(frozen=True)
class Msg__PlsFbCompareConstant(Msg):
    INDEX = 58  # type: int
    value: typing.Sequence[st.int64]


@dataclass(frozen=True)
class Msg__PlsFbCompareIQ(Msg):
    INDEX = 59  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__LckSetInFreqPhase(Msg):
    INDEX = 60  # type: int
    value: typing.Tuple[
        typing.Sequence[st.float64], typing.Sequence[st.float64], typing.Sequence[st.float64]
    ]


@dataclass(frozen=True)
class Msg__LckSetOutFreqPhase(Msg):
    INDEX = 61  # type: int
    value: typing.Tuple[
        typing.Sequence[st.float64], typing.Sequence[st.float64], typing.Sequence[st.float64]
    ]


@dataclass(frozen=True)
class Msg__LckSetScale(Msg):
    INDEX = 62  # type: int
    value: typing.Sequence[st.float64]


@dataclass(frozen=True)
class Msg__LckSetDf(Msg):
    INDEX = 63  # type: int
    value: typing.Tuple[st.float64, bool, st.uint8, st.uint32, st.uint32]


@dataclass(frozen=True)
class Msg__LckGet(Msg):
    INDEX = 64  # type: int
    value: typing.Tuple[
        bool, st.uint64, typing.Sequence[st.float64], st.uint16, typing.Sequence[st.uint64]
    ]


@dataclass(frozen=True)
class Msg__LckStream(Msg):
    INDEX = 65  # type: int
    value: typing.Tuple[
        bool,
        typing.Sequence[st.float64],
        st.uint16,
        typing.Sequence[st.uint64],
        typing.Optional[typing.Tuple[str, typing.Sequence[st.uint64], st.uint16]],
    ]


@dataclass(frozen=True)
class Msg__LckGroupMask(Msg):
    INDEX = 66  # type: int
    value: typing.Tuple[st.uint64, st.uint16]


@dataclass(frozen=True)
class Msg__LckInputSelect(Msg):
    INDEX = 67  # type: int
    value: typing.Tuple[st.uint64, st.uint64]


@dataclass(frozen=True)
class Msg__LckNcoSweep(Msg):
    INDEX = 68  # type: int
    value: typing.Tuple[
        st.uint64,
        typing.Sequence[st.float64],
        st.uint64,
        typing.Sequence[st.float64],
        st.uint64,
        typing.Sequence[st.uint64],
    ]


@dataclass(frozen=True)
class Msg__RfdcInit(Msg):
    INDEX = 69  # type: int
    pass


@dataclass(frozen=True)
class Msg__RfdcConfigure(Msg):
    INDEX = 70  # type: int
    value: typing.Tuple[st.uint64, st.uint64, st.uint32, st.uint32, st.float32, st.float32]


@dataclass(frozen=True)
class Msg__RfdcMts(Msg):
    INDEX = 71  # type: int
    value: typing.Tuple[st.int32, st.int32]


@dataclass(frozen=True)
class Msg__RfdcSetNCO(Msg):
    INDEX = 72  # type: int
    value: typing.Tuple[st.uint64, st.float64, st.float64]


@dataclass(frozen=True)
class Msg__RfdcDefaultConfig(Msg):
    INDEX = 73  # type: int
    pass


@dataclass(frozen=True)
class Msg__RfdcConfig(Msg):
    INDEX = 74  # type: int
    value: typing.Tuple[st.uint64, st.uint64, st.uint32, st.uint32, st.float32, st.float32]


@dataclass(frozen=True)
class Msg__RfdcNyquist(Msg):
    INDEX = 75  # type: int
    value: typing.Tuple[st.uint64, st.uint32]


@dataclass(frozen=True)
class Msg__RfdcSync(Msg):
    INDEX = 76  # type: int
    pass


@dataclass(frozen=True)
class Msg__RfdcCalFreeze(Msg):
    INDEX = 77  # type: int
    value: bool


@dataclass(frozen=True)
class Msg__RfdcCalSave(Msg):
    INDEX = 78  # type: int
    pass


@dataclass(frozen=True)
class Msg__RfdcCalRestore(Msg):
    INDEX = 79  # type: int
    pass


@dataclass(frozen=True)
class Msg__RfdcStoreFactoryAdcCal(Msg):
    INDEX = 80  # type: int
    pass


@dataclass(frozen=True)
class Msg__RfdcLoadFactoryAdcCal(Msg):
    INDEX = 81  # type: int
    pass


@dataclass(frozen=True)
class Msg__RfdcDisCoeffOverride(Msg):
    INDEX = 82  # type: int
    pass


@dataclass(frozen=True)
class Msg__RfdcGetInMultiBand(Msg):
    INDEX = 83  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__RfdcGetOutMultiBand(Msg):
    INDEX = 84  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__RfdcSetInMultiBand(Msg):
    INDEX = 85  # type: int
    value: typing.Tuple[st.uint64, st.uint32]


@dataclass(frozen=True)
class Msg__RfdcSetOutMultiBand(Msg):
    INDEX = 86  # type: int
    value: typing.Tuple[st.uint64, st.uint32]


@dataclass(frozen=True)
class Msg__RfdcSetInvSinc(Msg):
    INDEX = 87  # type: int
    value: typing.Tuple[st.uint64, st.uint16]


@dataclass(frozen=True)
class Msg__RfdcSetDacCurrent(Msg):
    INDEX = 88  # type: int
    value: typing.Tuple[st.uint64, st.uint32]


@dataclass(frozen=True)
class Msg__RfdcSetDSA(Msg):
    INDEX = 89  # type: int
    value: typing.Tuple[st.uint64, st.float32]


@dataclass(frozen=True)
class Msg__RfdcGetDelay(Msg):
    INDEX = 90  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__RfdcSetDelay(Msg):
    INDEX = 91  # type: int
    value: typing.Tuple[st.uint64, st.uint32]


@dataclass(frozen=True)
class Msg__RfdcDacLowNoise(Msg):
    INDEX = 92  # type: int
    value: typing.Tuple[st.uint64, bool]


@dataclass(frozen=True)
class Msg__RpuSetParam(Msg):
    INDEX = 93  # type: int
    value: typing.Tuple[st.uint64, st.uint64]


@dataclass(frozen=True)
class Msg__RpuGetParam(Msg):
    INDEX = 94  # type: int
    value: st.uint64


@dataclass(frozen=True)
class Msg__RpuUpload(Msg):
    INDEX = 95  # type: int
    value: typing.Tuple[str, typing.Sequence[st.uint8], typing.Optional[str]]


@dataclass(frozen=True)
class Msg__SpecTune(Msg):
    INDEX = 96  # type: int
    value: typing.Tuple[st.uint32, st.uint8]


@dataclass(frozen=True)
class Msg__SpecOutMux(Msg):
    INDEX = 97  # type: int
    value: typing.Sequence[st.uint8]


@dataclass(frozen=True)
class Msg__SpecOutDataRaw(Msg):
    INDEX = 98  # type: int
    value: typing.Tuple[typing.Sequence[st.int16], typing.Sequence[st.int16]]


@dataclass(frozen=True)
class Msg__SpecOutDataMultiCos(Msg):
    INDEX = 99  # type: int
    value: typing.Tuple[
        st.float64,
        typing.Sequence[typing.Tuple[st.float64, st.float64, st.float64]],
        typing.Sequence[typing.Tuple[st.float64, st.float64, st.float64]],
    ]


@dataclass(frozen=True)
class Msg__SpecInSetup(Msg):
    INDEX = 100  # type: int
    value: typing.Tuple[
        st.uint8,
        st.float64,
        st.uint8,
        typing.Sequence[st.uint8],
        st.uint32,
        typing.Sequence[st.uint32],
        typing.Tuple[st.float64, st.float64],
    ]


@dataclass(frozen=True)
class Msg__SpecPreDelay(Msg):
    INDEX = 101  # type: int
    value: st.float64


@dataclass(frozen=True)
class Msg__SpecRun(Msg):
    INDEX = 102  # type: int
    value: st.uint32


@dataclass(frozen=True)
class Msg__SpecGetData(Msg):
    INDEX = 103  # type: int
    value: st.uint32


@dataclass(frozen=True)
class Msg__SpecGetDataRaw(Msg):
    INDEX = 104  # type: int
    value: st.uint32


@dataclass(frozen=True)
class Msg__SpecStream(Msg):
    INDEX = 105  # type: int
    pass


@dataclass(frozen=True)
class Msg__SpecGetMap(Msg):
    INDEX = 106  # type: int
    pass


@dataclass(frozen=True)
class Msg__StopAll(Msg):
    INDEX = 107  # type: int
    pass


@dataclass(frozen=True)
class Msg__IntrStatus(Msg):
    INDEX = 108  # type: int
    pass


@dataclass(frozen=True)
class Msg__IntrClr(Msg):
    INDEX = 109  # type: int
    pass


@dataclass(frozen=True)
class Msg__TempFpga(Msg):
    INDEX = 110  # type: int
    pass


@dataclass(frozen=True)
class Msg__CurrVccInt(Msg):
    INDEX = 111  # type: int
    pass


Msg.VARIANTS = [
    Msg__Reset,
    Msg__Version,
    Msg__Quit,
    Msg__ErrorList,
    Msg__Echo,
    Msg__Sleep,
    Msg__LoadFirmware,
    Msg__NrPorts,
    Msg__WhichBoard,
    Msg__ClockInit,
    Msg__ClockSync,
    Msg__ClockSetLmx,
    Msg__PrestoInit,
    Msg__PrestoVarVer,
    Msg__PrestoRpuVer,
    Msg__PrestoRun,
    Msg__PrestoDmaStart,
    Msg__PrestoDmaWait,
    Msg__PrestoDmaStop,
    Msg__PrestoDmaGet,
    Msg__PrestoDmaStatus,
    Msg__PrestoDmaClear,
    Msg__PrestoOcmError,
    Msg__PrestoConvMode,
    Msg__PrestoDcBias,
    Msg__PrestoDcBiasRamp,
    Msg__PrestoDcGetBias,
    Msg__PrestoDcRaw,
    Msg__PrestoDcReadback,
    Msg__PrestoMarkerIn,
    Msg__PrestoMarkerOut,
    Msg__PrestoIoeRaw,
    Msg__PrestoStreamDma,
    Msg__PrestoHistBuild,
    Msg__PrestoHistGet,
    Msg__PrestoHist2DBuild,
    Msg__PrestoHist2DGet,
    Msg__StreamAbort,
    Msg__TestDither,
    Msg__TestFrequency,
    Msg__TestPhase,
    Msg__TestScale,
    Msg__TestBlank,
    Msg__TestDmaSrc,
    Msg__PlsSeqCmd,
    Msg__PlsStoreMode,
    Msg__PlsScale,
    Msg__PlsMatchTmpl,
    Msg__PlsOutTmpl,
    Msg__PlsFreqLut,
    Msg__PlsPhaseLutIQ,
    Msg__PlsEnvelope,
    Msg__PlsNIter,
    Msg__PlsMatchMux,
    Msg__PlsFbDefaultMask,
    Msg__PlsFbConditionMask,
    Msg__PlsFbUserMask,
    Msg__PlsFbInvertCondition,
    Msg__PlsFbCompareConstant,
    Msg__PlsFbCompareIQ,
    Msg__LckSetInFreqPhase,
    Msg__LckSetOutFreqPhase,
    Msg__LckSetScale,
    Msg__LckSetDf,
    Msg__LckGet,
    Msg__LckStream,
    Msg__LckGroupMask,
    Msg__LckInputSelect,
    Msg__LckNcoSweep,
    Msg__RfdcInit,
    Msg__RfdcConfigure,
    Msg__RfdcMts,
    Msg__RfdcSetNCO,
    Msg__RfdcDefaultConfig,
    Msg__RfdcConfig,
    Msg__RfdcNyquist,
    Msg__RfdcSync,
    Msg__RfdcCalFreeze,
    Msg__RfdcCalSave,
    Msg__RfdcCalRestore,
    Msg__RfdcStoreFactoryAdcCal,
    Msg__RfdcLoadFactoryAdcCal,
    Msg__RfdcDisCoeffOverride,
    Msg__RfdcGetInMultiBand,
    Msg__RfdcGetOutMultiBand,
    Msg__RfdcSetInMultiBand,
    Msg__RfdcSetOutMultiBand,
    Msg__RfdcSetInvSinc,
    Msg__RfdcSetDacCurrent,
    Msg__RfdcSetDSA,
    Msg__RfdcGetDelay,
    Msg__RfdcSetDelay,
    Msg__RfdcDacLowNoise,
    Msg__RpuSetParam,
    Msg__RpuGetParam,
    Msg__RpuUpload,
    Msg__SpecTune,
    Msg__SpecOutMux,
    Msg__SpecOutDataRaw,
    Msg__SpecOutDataMultiCos,
    Msg__SpecInSetup,
    Msg__SpecPreDelay,
    Msg__SpecRun,
    Msg__SpecGetData,
    Msg__SpecGetDataRaw,
    Msg__SpecStream,
    Msg__SpecGetMap,
    Msg__StopAll,
    Msg__IntrStatus,
    Msg__IntrClr,
    Msg__TempFpga,
    Msg__CurrVccInt,
]


class SeqCmd:
    VARIANTS = []  # type: typing.Sequence[typing.Type[SeqCmd]]

    def bincode_serialize(self) -> bytes:
        return bincode.serialize(self, SeqCmd)

    @staticmethod
    def bincode_deserialize(input: bytes) -> "SeqCmd":
        v, buffer = bincode.deserialize(input, SeqCmd)
        if buffer:
            raise st.DeserializationError("Some input bytes were not read")
        return v


@dataclass(frozen=True)
class SeqCmd__Dummy(SeqCmd):
    INDEX = 0  # type: int
    nr_periods: st.uint32


@dataclass(frozen=True)
class SeqCmd__Output(SeqCmd):
    INDEX = 1  # type: int
    trig_mask: st.uint8
    scale_idx: typing.Optional[st.uint16]
    freq_idx: typing.Optional[st.uint16]
    next_scale: bool
    next_freq: bool
    reset: bool


@dataclass(frozen=True)
class SeqCmd__Match(SeqCmd):
    INDEX = 2  # type: int
    match_mask: st.uint32


@dataclass(frozen=True)
class SeqCmd__Marker(SeqCmd):
    INDEX = 3  # type: int
    marker_word: st.uint32


@dataclass(frozen=True)
class SeqCmd__Store(SeqCmd):
    INDEX = 4  # type: int
    store_mask: st.uint16


SeqCmd.VARIANTS = [
    SeqCmd__Dummy,
    SeqCmd__Output,
    SeqCmd__Match,
    SeqCmd__Marker,
    SeqCmd__Store,
]
