# -*- coding: utf-8 -*-
# Copyright © 2018-2024 Intermodulation Products AB. All Rights Reserved.
"""
This is the Python public API for controlling the Vivace and Presto hardware platforms.

Detailed information is provided in the documentation for each module.

.. autosummary::
    :nosignatures:

    hardware
    lockin
    pulsed
    spectral
    utils
    version
"""

from __future__ import annotations

from .version import version_api as __version__

VERSION = __version__
