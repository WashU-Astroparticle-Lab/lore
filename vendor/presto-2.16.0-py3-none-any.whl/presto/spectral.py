# -*- coding: utf-8 -*-
# Copyright © 2018-2024 Intermodulation Products AB. All Rights Reserved.
"""
FFT-based measurements of spectral content.

Detailed information is provided in the documentation for each class.

.. autosummary::
    :nosignatures:

    Spectral
    SpecMode
    SpecResult
    SpecReceiver
"""

# TODO: math definitions in docstrings

from __future__ import annotations

import enum
import math
import socket
import time
from typing import Any, Generic, List, Literal, Optional, Tuple, TypeVar, Union, overload

import numpy as np
import numpy.typing as npt

from . import _commands as cmd
from .hardware import AdcFSample, AdcMode, DacFSample, DacMode, Hardware
from ._stream import StreamReceiver
from .utils import Spinner, asarray, eprint_error
from .version import version_fpga

VARIANT: int = 9

IntAny = Union[int, List[int], npt.NDArray[np.integer]]
FloatAny = Union[float, List[float], npt.NDArray[np.floating]]
ComplexAny = Union[complex, List[complex], npt.NDArray[np.complexfloating]]

IntList = Union[List[int], npt.NDArray[np.integer]]
FloatList = Union[List[float], npt.NDArray[np.floating]]
ComplexList = Union[List[complex], npt.NDArray[np.complexfloating]]

DataType = Union[np.float64, np.complex64, np.complex128]


class Spectral:
    def __init__(
        self,
        *,
        nr_inputs: int = 1,
        ext_ref_clk: Union[None, bool, int, float] = False,
        force_reload: bool = False,
        dry_run: bool = False,
        address: Optional[str] = None,
        port: Optional[int] = None,
        adc_mode: Union[AdcMode, List[AdcMode]] = AdcMode.Mixed,
        adc_fsample: Optional[Union[AdcFSample, List[AdcFSample]]] = None,
        dac_mode: Union[DacMode, List[DacMode]] = DacMode.Mixed,
        dac_fsample: Optional[Union[DacFSample, List[DacFSample]]] = None,
        force_config: bool = False,
    ):
        r"""Use the hardware in *spectral* mode.

        Warning:
            Create only one instance at a time. This class is designed to be instantiated with
            Python's :ref:`with statement <python:with>`, see Examples section.

        Args:
            nr_inputs: number of input ports that are active simultaneously. The spectral content
                (FFT or PSD) will be measured in parallel from this many ports.
            ext_ref_clk: if :obj:`None` or :obj:`False` use internal reference clock; if
                :obj:`True` use external reference clock (10 MHz); if :class:`float` or
                :class:`int` use external reference clock at ``ext_ref_clk`` Hz
            force_reload: if :obj:`True` re-configure clock and reload firmware even if there's no
                change from the previous settings.
            dry_run: if :obj:`True` don't connect to hardware, for testing only.
            address: IP address or hostname of the hardware. If :obj:`None`, use factory default
                ``"192.168.42.50"``.
            port: port number of the server running on the hardware. If :obj:`None`, use factory
                default ``7878``.
            adc_mode (AdcMode or list): must be ``AdcMode.Mixed`` (default), using the digital
                mixers for downconversion. ``Direct`` mode is not supported in *spectral* mode.
            adc_fsample (AdcFSample or list): configure the inputs sampling rate. If :obj:`None`
                (default), choose optimal rate automatically. See Notes.
            dac_mode (DacMode or list): must be ``DacMode.Mixed`` (default) or another of the
                *mixed* variants, using the digital mixers for upconversion. ``Direct`` mode is not
                supported in *spectral* mode. See Notes.
            dac_fsample (DacFSample or list): configure the outputs sampling rate. If :obj:`None`
                (default), choose optimal rate automatically. See Notes.
            force_config: if :obj:`True` skip checks on ``DacMode``\ s not recommended for high DAC
                sampling rates.

        Raises:
            ValueError: if ``adc_mode`` or ``dac_mode`` are not valid :ref:`converter modes`;
                if ``adc_fsample`` or ``dac_fsample`` are not valid :ref:`converter rates`.

        Notes:
            In all the Examples, it is assumed that the imports ``import numpy as np`` and
            ``from presto.spectral import Spectral, SpecMode`` have been performed, and that this
            class has been instantiated in the form ``spec = Spectral()``, or, **much much better**,
            using the ``with Spectral() as spec`` construct as below.

            For an introduction to ``adc_mode`` and ``dac_mode``, see :doc:`../special/direct_mixed`.
            For valid values of ``adc_mode`` and ``dac_mode``, see :ref:`converter modes`. For
            valid values of ``adc_fsample`` and ``dac_fsample``, see :ref:`converter rates`. For
            advanced configuration, e.g. different converter rates on different ports, see
            :ref:`adv tile`.

        Examples:

            Drive two continuous-wave signals from output port 1 and 2, and measure averaged FFT
            from input port 1. Plot the results.

            >>> import matplotlib.pyplot as plt
            >>> import numpy as np
            >>>
            >>> IN_PORT = 1
            >>> OUT_PORT_1 = 1
            >>> OUT_PORT_2 = 2
            >>>
            >>> with Spectral(address="192.168.20.10") as spec:
            >>>     # configure 1.5 GHz carrier for up- and down-conversion
            >>>     spec.hardware.configure_mixer(
            >>>         freq=1.5e9,
            >>>         in_ports=IN_PORT,
            >>>         out_ports=[OUT_PORT_1, OUT_PORT_2],
            >>>     )
            >>>
            >>>     # 1 MHz resolution in FFT
            >>>     period = spec.tune_period(1.0e-6)
            >>>
            >>>     # on the first output port,
            >>>     # drive two tones at 110 and 112 MHz from the carrier
            >>>     # with same phase but different amplitude
            >>>     # one below the carrier (lower sideband) and one above (upper sideband)
            >>>     f1 = [-110.0e6, +120.0e6]
            >>>     a1 = [0.1, 0.2]
            >>>     p1 = [0.0, 0.0]
            >>>     spec.output_multicos(OUT_PORT_1, period, f1, a1, p1)
            >>>
            >>>     # on the second output port,
            >>>     # drive one tone on port 2 at the carrier frequency
            >>>     f2 = 0.0
            >>>     a2 = 0.5
            >>>     p2 = 0.0
            >>>     spec.output_multicos(OUT_PORT_2, period, f2, a2, p2)
            >>>
            >>>     # measure FFT data, averaged 1000 times
            >>>     res = spec.measure(SpecMode.FftAvg, IN_PORT, 1000, period)
            >>>
            >>> # plot data
            >>>
            >>> # frequencies in MHz
            >>> x = np.fft.fftshift(res.freqs) / 1.0e6
            >>> # data in dBFS
            >>> y = np.fft.fftshift(res.to_db()[0])
            >>>
            >>> fig, ax = plt.subplots()
            >>> ax.plot(x, y)
            >>> ax.set_xlabel("Offset frequency [MHz]")
            >>> ax.set_ylabel("Amplitude [dBFS]")
            >>> ax.set_title("Center frequency 1.5 GHz")
            >>> ax.grid()
            >>> plt.show()

            Drive two random signals from output ports 1 and 2 into input ports 1 and 2,
            one delayed 100 ns from the other, and measure the correlation of the two.

            >>> import matplotlib.pyplot as plt
            >>> import numpy as np
            >>>
            >>> IN_PORTS = [1, 2]
            >>> OUT_PORTS = [1, 2]
            >>>
            >>> with Spectral(
            >>>     nr_inputs=len(IN_PORTS),
            >>>     address="192.168.20.10",
            >>> ) as spec:
            >>>     # configure 1.5 GHz carrier for up- and down-conversion
            >>>     spec.hardware.configure_mixer(1.5e9, in_ports=IN_PORTS, out_ports=OUT_PORTS)
            >>>
            >>>     # 1 MHz resolution in FFT
            >>>     period = spec.tune_period(1.0e-6)
            >>>
            >>>     # generate random data and output from first port
            >>>     def random_complex(ns):
            >>>         rng = np.random.default_rng()
            >>>         real = 2.0 * rng.random(ns) - 1.0
            >>>         imag = 2.0 * rng.random(ns) - 1.0
            >>>         return real + 1j * imag
            >>>
            >>>     duration = 10 * period
            >>>     nr_samples = int(round(duration * spec.get_fs("dac")))
            >>>     data1 = 0.1 * random_complex(nr_samples)
            >>>     spec.output_waveform(OUT_PORTS[0], data1)
            >>>
            >>>     # output same data on second port,
            >>>     # but delayed by 100 samples (100 ns)
            >>>     data2 = np.roll(data1, 100)
            >>>     spec.output_waveform(OUT_PORTS[1], data2)
            >>>
            >>>     # measure cross power spectral density (CPSD) data
            >>>     # averaged 10 times
            >>>     res = spec.measure(SpecMode.Cpsd, IN_PORTS, 10, period)
            >>>
            >>> # calculate correlation from measured CPSD
            >>> # and plot results
            >>>
            >>> x, y = res.to_correlation()
            >>> fig, ax = plt.subplots()
            >>> ax.plot(1e9 * x, np.real(y[0]))
            >>> ax.plot(1e9 * x, np.imag(y[0]))
            >>> ax.set_xlabel("Time lag [ns]")
            >>> ax.set_ylabel("Correlation [arb. units]")
            >>> ax.set_title("Center frequency 1.5 GHz")
            >>> ax.grid()
            >>> plt.show()
        """
        self.dry_run = bool(dry_run)

        self.hardware: Hardware = Hardware(address, port, dry_run)
        """interface to hardware features common to all modes of operation"""

        (adc_mode, adc_fsample, dac_mode, dac_fsample) = self.hardware.validate_config(
            adc_mode, adc_fsample, dac_mode, dac_fsample, force_config=force_config
        )
        if adc_mode[0] == AdcMode.Direct:
            raise ValueError("Spectral mode does not support adc_mode=AdcMode.Direct")
        if dac_mode[0] == DacMode.Direct:
            raise ValueError("Spectral mode does not support dac_mode=AdcMode.Direct")

        if nr_inputs not in [1, 2, 4]:
            raise ValueError(f"nr_inputs must be in {1, 2, 4}, got {nr_inputs}")
        self._readonly_nr_inputs = int(nr_inputs)

        # DAC is always 4 real samples (2 complex) at 500 MHz
        self.hardware.dac_bus_width = 4
        self.hardware.dac_fab_rate = 500.0
        # ADC depends on nr_inputs
        self.hardware.adc_fab_rate = 250.0
        self.hardware.adc_bus_width = 8 // self.nr_inputs

        try:
            if not self.dry_run:
                if force_reload:
                    self.hardware.reset()
                self.hardware.init_clock(ext_ref_clk)
                self.hardware.load_firmware(f"presto_{VARIANT:d}_{version_fpga:d}.bin")
                self.hardware.init_presto()
                self.hardware.init_rfdc()

                var, ver = self.hardware.get_var_ver()
                if var != VARIANT:
                    raise RuntimeError(
                        f"The loaded firmware variant {var} does not match the expected {VARIANT}."
                        " This should not happen, please contact Intermodulation Products for support."
                    )
                self.hardware._check_version_fw(ver)

            # always setup converters later in _setup(), whether or not we need dac_autoconfig
            # however, we need to make sure the mixer configure is always deferred
            self.hardware._defer_mixer_config = True

        except (Exception, KeyboardInterrupt):
            self.close()
            raise

        self._mode: SpecMode = SpecMode.FftAvg
        self._input_setup: Optional[_InputSetup] = None
        self._output_type: List[OutType] = [OutType.Nil] * 2
        self._ouput_data_1: Optional[Any] = None
        self._ouput_data_2: Optional[Any] = None
        self._output_mux: List[int] = [0] * self.hardware.nr_ports
        self._output_duration: Optional[float] = None
        self._pre_delay: float = 0.0
        self._start_delay: float = 0.0
        self._end_delay: float = 0.0

    def __enter__(self) -> Spectral:  # for use with 'with' statement
        return self

    def __exit__(self, *_):  # for use with 'with' statement
        self.close()

    def close(self):
        """Gracely disconnect from the hardware.

        Call this method if the class was instantiated without a
        :ref:`with statement <python:with>`. This method is called automatically when exiting a
        ``with`` block and before the object is destructed.
        """
        self.hardware.close()

    @property
    def nr_inputs(self):
        """The current number of interleaved input ports.

        This value is read only. To change it, create a new instance of the :class:`Spectral` class
        and pass the desired number of input ports as the `nr_inputs` parameter.
        """
        return self._readonly_nr_inputs

    def get_fs(self, which: str) -> float:
        """Get sampling frequency for ``which`` converter in Hz.

        Note:
            This is the sampling rate in the intermediate-frequency (IF) domain, and not the
            (higher) sampling rate in the radio-frequency (RF) domain.

        Args:
            which: ``"adc"`` for input and ``"dac"`` for output.

        Raises:
            ValueError: if ``which`` is unknown.
        """
        if which == "adc":
            fs_real = 1e6 * self.hardware.adc_fab_rate * self.hardware.adc_bus_width
        elif which == "dac":
            fs_real = 1e6 * self.hardware.dac_fab_rate * self.hardware.dac_bus_width
        else:
            raise ValueError(f'which can be "adc" or "dac", got {which}')

        # Mixed mode only
        return fs_real / 2.0

    def get_nr_ports(self) -> int:
        """The number of available input/output ports in the hardware."""
        return self.hardware.nr_ports

    def tune_period(
        self,
        period: float,
        *,
        strategy: Optional[TuningStrategy] = None,
    ) -> float:
        """Tune the provided measurement period to a value supported by the hardware.

        Only a limited number of measurement periods are supported by the hardware. The default
        :class:`tuning strategy <TuningStrategy>` will choose the available period that is closest
        to the user-requested value.

        Args:
            period: the desired FFT measurement period is seconds, equal to the inverse of the
                desired frequency resolution in hertz
            strategy: optional tuning strategy

        Returns:
            the tuned ``period``
        """
        if strategy is None:
            strategy = TuningStrategy.Closest

        len_user = period * self.get_fs("adc")
        sublen_user = len_user * self.nr_inputs / 4.0

        if strategy is TuningStrategy.Closest:
            sublen_tuned = min(_GOOD_SUBLEN, key=lambda x: abs(x - sublen_user))
        elif strategy is TuningStrategy.AtLeast:
            sublen_tuned = min(
                filter(lambda x: x >= sublen_user, _GOOD_SUBLEN),
                default=_GOOD_SUBLEN[-1],
            )
        elif strategy is TuningStrategy.AtMost:
            sublen_tuned = max(
                filter(lambda x: x <= sublen_user, _GOOD_SUBLEN),
                default=_GOOD_SUBLEN[0],
            )
        else:
            raise NotImplementedError

        len_tuned = (4 // self.nr_inputs) * sublen_tuned

        return len_tuned / self.get_fs("adc")

    def fftfreq(self, period: float) -> npt.NDArray[np.floating]:
        """Return the fast Fourier transform sample frequencies.

        The returned array contains the frequency bin centers in hertz (cycles second), with zero
        at the start. This methos is similar to :func:`numpy.fft.fftfreq`, but with different
        arguments.

        Args:
            period: the FFT measurement period, or window length, in seconds.

        Note:
            The `period` is assumed to be tuned. See :meth:`tune_period` for details.
        """
        period = self.tune_period(period)
        dt = 1.0 / self.get_fs("adc")
        nr_freqs = int(round(period / dt))
        freqs = np.fft.fftfreq(nr_freqs, dt)
        return freqs

    def _check(self):
        if self._input_setup is None:
            raise RuntimeError("input was not set up")

        if self._output_type[0] is OutType.Nil:
            raise RuntimeError("output was not set up")
        if self._output_type[1] is not OutType.Nil:
            if self._output_type[1] != self._output_type[0]:
                raise RuntimeError("the two output waveforms must be of the same type")

    def _setup(self, quiet: bool = False) -> Tuple[int, int]:
        # already checked in _check()
        assert self._input_setup is not None
        assert self._output_type[0] is not OutType.Nil

        # setup ADCs and DACs
        # always do it here, whether or not we need autoconfig
        if True:
            with Spinner("Configuring ADCs and DACs", quiet=quiet):
                # set user-requested configuration for the data converters
                self.hardware.setup_config(
                    do_sync=False
                )  # sync in _run() when we start the sequence
                self.hardware.assert_errors()
                self.hardware.intr_clr()
                _ = self.hardware.get_intr_status()  # the first after MTS is polluted
                self.hardware.check_adc_intr_status()

        with Spinner("Setting up", quiet=quiet):
            if self._output_type[0] is OutType.Raw:
                data1 = self._ouput_data_1
                if self._output_type[1] is OutType.Nil:
                    data2 = np.zeros_like(data1)
                else:
                    data2 = self._ouput_data_2
                self.hardware._send_command(cmd.Msg__SpecOutDataRaw((data1, data2)))  # pyright: ignore[reportArgumentType]
            elif self._output_type[0] is OutType.MultiCos:
                data1 = self._ouput_data_1
                if self._output_type[1] is OutType.Nil:
                    data2 = []
                else:
                    data2 = self._ouput_data_2
                duration = float(self._output_duration)  # pyright: ignore[reportArgumentType] -- crash if still None
                self.hardware._send_command(cmd.Msg__SpecOutDataMultiCos((duration, data1, data2)))  # pyright: ignore[reportArgumentType]
            self.hardware._send_command(cmd.Msg__SpecOutMux(self._output_mux))

            self.hardware._send_command(cmd.Msg__SpecPreDelay(self._pre_delay))

            self.hardware._send_command(
                cmd.Msg__SpecInSetup(
                    self._input_setup.to_tuple() + ((self._start_delay, self._end_delay),)
                )
            )
            reply = self.hardware._receive(8)
            val = int.from_bytes(reply, byteorder="little", signed=False)
            tot_bytes = val & 0xFFFF_FFFF
            tot_dma_bytes = (val >> 32) & 0xFFFF_FFFF

        return (tot_bytes, tot_dma_bytes)

    def _run(
        self,
        expected_bytes: int,
        expected_dma_bytes: int,
        auto_sync: bool,
        quiet: bool = False,
    ) -> bytearray:
        # already checked in _check()
        assert self._input_setup is not None

        self.hardware._send_command(cmd.Msg__SpecRun(expected_dma_bytes))
        # measurement is triggered by next SYSREF edge
        if auto_sync:
            # trigger immediately
            self.hardware.sync()

        # check for errors before waiting
        self.hardware.assert_errors()

        dma_done = False
        dma_err = False
        with Spinner("Measuring", quiet=quiet):
            while not (dma_done or dma_err):
                (dma_done, dma_err, dma_bytes) = self.hardware.get_dma_status(0)
                time.sleep(0.1)

        (_, _, dma_bytes) = self.hardware.get_dma_status(0)
        if dma_err or (dma_bytes != expected_dma_bytes):
            raise RuntimeError(
                "there was an internal error in the data transfer:\n"
                f"    {dma_done = }\n"
                f"    {dma_err = }\n"
                f"    {dma_bytes = }\n"
                f"    {expected_dma_bytes = }"
            )

        with Spinner("Downloading data", quiet=quiet):
            self.hardware._send_command(cmd.Msg__SpecGetDataRaw(expected_bytes))

            # receive confirmation the server is waiting for a connection
            reply = self.hardware._receive(8)
            assert 35 == int.from_bytes(reply, byteorder="little", signed=False)
            with self.hardware._new_connection() as sock:
                reply = self.hardware._receive_from(expected_bytes, sock)

        # check for errors after all is done
        self.hardware.assert_errors()
        self.hardware.check_adc_intr_status()

        return reply

    def _unpack_data(self, buf: bytearray, quiet: bool = False) -> SpecResult:
        # already checked in _check()
        assert self._input_setup is not None

        with Spinner("Processing data", quiet=quiet):
            # cast from u8 to proper result type
            dtype = np.dtype(self._mode.dtype()).newbyteorder("<")
            data_raw = np.frombuffer(buf, dtype)

            # get ordering of Fourier components (sub FFT only)
            map = self._get_fullmap()

            # calculate parameters for final ordering
            nr_cycles = self._input_setup.nr_cycles if self._mode is SpecMode.FftStream else 1
            nr_channels = self.nr_inputs
            if self._mode is SpecMode.Cpsd:
                nr_channels //= 2

            # re-order data
            data_raw.shape = (nr_cycles, -1)
            data = np.empty_like(data_raw)
            data.shape = (nr_cycles, nr_channels, -1)
            for ii in range(nr_cycles):
                for ch in range(nr_channels):
                    data[ii, ch, :] = data_raw[ii, map + ch]

            # reshape according to measurement mode
            if self._mode is SpecMode.Cpsd:
                data.shape = (self.nr_inputs // 2, -1)
            elif self._mode is SpecMode.FftStream:
                nr_cycles = self._input_setup.nr_cycles
                data.shape = (nr_cycles, self.nr_inputs, -1)
            else:
                data.shape = (self.nr_inputs, -1)

            scale = 32767.0 * data.shape[-1]
            if self._mode is SpecMode.Psd or self._mode is SpecMode.Cpsd:
                scale *= scale
                scale *= self._input_setup.nr_cycles
            elif self._mode is SpecMode.FftAvg:
                scale *= self._input_setup.nr_cycles
            else:
                pass
            data /= scale

            # other measurement parameters
            nr_freqs = data.shape[-1]
            dt = 1.0 / self.get_fs("adc")
            freqs = np.fft.fftfreq(nr_freqs, dt)
            ports = self._input_setup.ports()

            # check if data period is different than the period requested by the user
            data_period = nr_freqs * dt
            user_period = self._input_setup.period
            if not math.isclose(data_period, user_period):
                eprint_error(
                    "WARNING",
                    (
                        f"user requested FFT period {user_period:g} s, but got data with period "
                        f"{data_period:g} s. To avoid implicit tuning of the FFT period, explicitly "
                        "tune it using the method tune_period() before calling measure()."
                    ),
                    warn=True,
                    inline=True,
                )

            return SpecResult(mode=self._mode, freqs=freqs, data=data, input_ports=ports)

    def _do_it(self, auto_sync: bool = True, quiet: bool = False) -> SpecResult:
        self._check()
        if not self.dry_run:
            tot_bytes, tot_dma_bytes = self._setup(quiet=quiet)
            buf = self._run(tot_bytes, tot_dma_bytes, auto_sync, quiet=quiet)
            return self._unpack_data(buf, quiet=quiet)
        else:
            eprint_error(
                "WARNING",
                "No data available. This is a dry run!",
                warn=True,
                inline=True,
            )
            return SpecResult._dummy(self._mode)

    def clear_outputs(self):
        """Clear the waveforms set up on all output ports."""
        self._output_type = [OutType.Nil] * 2

    def _set_out_type(self, ports: npt.NDArray[np.int64], ty: OutType, data: Any):
        if self._output_type[0] is OutType.Nil:
            self._output_type[0] = ty
            self._ouput_data_1 = data
            mux = 1
        elif self._output_type[1] is OutType.Nil:
            self._output_type[1] = ty
            self._ouput_data_2 = data
            mux = 2
        else:
            raise RuntimeError(
                "no more slots available for output waveforms."
                " Use clear_outputs() to reset output waveforms."
            )

        for port in ports:
            channel = port - 1
            self._output_mux[channel] = mux

    def output_waveform(self, output_ports: IntAny, data: ComplexAny):
        """Set up an arbitrary waveform on one or more output ports.

        Args:
            output_ports (int or list): output port, can be a list of up to 4 ports
            data (list of complex): an array of complex-valued arbitrary data points

        Notes:
            The real part of ``data`` is fed to the I port of the digital up-conversion mixer,
            while the imaginary part of ``data`` is fed to the Q port.

        Raises:
            ValueError: if ``output_ports`` is not in [1, :meth:`get_nr_ports`]
            ValueError: if ``data`` is out of range: both real and imaginary parts must be in
                [-1.0, +1.0]
            RuntimeError: if there are no more output slots available

        See also:
            :meth:`output_multicos`
        """
        output_ports = asarray(output_ports, np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")

        data = asarray(data, np.complex128)
        if np.any(np.abs(data.real) > 1.0) or np.any(np.abs(data.imag) > 1.0):
            raise ValueError("both real and imaginary parts of data must be in [-1.0, +1.0]")

        # 1 x complex128 --> 2 x float64, twice the length
        data_real = np.frombuffer(data, np.float64)
        data_int = np.round(32767 * data_real).astype(np.int16)

        self._set_out_type(output_ports, OutType.Raw, data_int)

    def output_multicos(
        self,
        output_ports: IntAny,
        period: float,
        frequencies: FloatAny,
        amplitudes: FloatAny,
        phases: Optional[FloatAny] = None,
    ):
        """Set up a multi-tone waveform on one or more output ports.

        Args:
            output_ports (int or list): output port, can be a list of up to 4 ports
            period: the repetition period of the output waveform, in seconds
            frequencies (list of float): frequencies of the individual tones that comprise the
                waveform, in hertz
            amplitudes (list of float): amplitudes of the individual tones that comprise the
                waveform, in full-scale units between -1.0 and +1.0 FS
            phases (list of float, optional): phases of the individual tones that comprise the
                waveform, in radians. If :obj:`None` (default), all tones have zero phase

        Notes:
            Positive frequencies are up-coverted to the upper sideband (USB) by the digital
            up-conversion mixer, and negative frequencies are up-coverted to the lower sideband
            (LSB).

            If ``sum(abs(amplitudes))`` > 1.0, it is possible for the tones in the waveform to
            interfere constructively and cause an overflow (clipping), resulting in a
            heavily-distorted output waveform. To prevent this effect, ensure that
            ``sum(abs(amplitudes))`` <= 1.0, or adjust the ``phases`` of the tones to prevent
            isolated peaks in the resulting waveform.

        Raises:
            ValueError: if ``output_ports`` is not in [1, :meth:`get_nr_ports`]
            ValueError: if ``len(amplitudes) != len(frequencies)``
            ValueError: if ``len(phases) != len(frequencies)``
            ValueError: if any of ``abs(frequencies)`` >= Nyquist frequency, i.e. half of
                :meth:`get_fs("dac") <get_fs>`
            ValueError: if any of ``abs(amplitudes) > 1.0``
            RuntimeError: if there are no more output slots available

        See also:
            :meth:`output_waveform`
        """
        output_ports = asarray(output_ports, np.int64)
        if output_ports.min() < 1 or output_ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid output ports are 1-{self.hardware.nr_ports}")

        frequencies = asarray(frequencies, np.float64)
        amplitudes = asarray(amplitudes, np.float64)
        if phases is None:
            phases = np.zeros_like(frequencies)
        else:
            phases = asarray(phases, np.float64)

        if len(frequencies) != len(amplitudes):
            raise ValueError("the same number of frequencies and amplitudes must be provided")
        if len(frequencies) != len(phases):
            raise ValueError("the same number of frequencies and phases must be provided")

        if np.any(np.abs(amplitudes) > 1.0):
            raise ValueError("all amplitudes must be in [-1.0, +1.0]")

        fnyq = self.get_fs("dac") / 2.0
        if np.any(np.abs(frequencies) >= fnyq):
            mhz = round(fnyq / 1e6, 2)
            raise ValueError(f"all frequencies must be in (-{mhz}, +{mhz}) MHz")

        data = [x for x in zip(frequencies, amplitudes, phases)]

        self._set_out_type(output_ports, OutType.MultiCos, data)
        self._output_duration = period

    def _measure_any(
        self,
        mode: SpecMode,
        ports: npt.NDArray[np.int64],
        period: float,
        nr_cycles: int,
        components: IntList,
    ):
        ports = np.unique(ports)
        if ports.min() < 1 or ports.max() > self.hardware.nr_ports:
            raise ValueError(f"valid input ports are 1-{self.hardware.nr_ports}")
        channels = ports - 1
        nr_channels = len(channels)
        if nr_channels != self.nr_inputs:
            raise ValueError(
                f"expected a list of {self.nr_inputs} input port(s), got {nr_channels} port(s) "
                f"instead. See attribute nr_inputs for the expected number of input ports, or "
                f"create a new instance of the Spectral class and pass the desired number of "
                f"input ports as the parameter nr_inputs."
            )

        if mode is SpecMode.Cpsd:
            if nr_channels not in [2, 4]:
                raise ValueError(
                    f"can only measure cross power spectral density (CPSD) from 2 or 4 ports "
                    f"(1 or 2 pairs of ports) simultaneously, but got {nr_channels} ports in total"
                )

        if nr_channels == 1:
            c0 = channels[0]
            mux = [c0, c0, c0, c0]
        elif nr_channels == 2:
            c0 = channels[0]
            c1 = channels[1]
            mux = [c0, c1, c0, c1]
        elif nr_channels == 4:
            c0 = channels[0]
            c1 = channels[1]
            c2 = channels[2]
            c3 = channels[3]
            mux = [c0, c1, c2, c3]
        else:
            raise ValueError(
                "can only measure from 1, 2 or 4 ports simultaneously, "
                f"got a list of {nr_channels} ports"
            )

        self._mode = mode
        self._input_setup = _InputSetup(mode, period, nr_channels, mux, nr_cycles, components)

    def _get_submap(self) -> npt.NDArray[np.int64]:
        self.hardware._send_command(cmd.Msg__SpecGetMap())

        reply = self.hardware._receive(8)
        nr_bytes = int.from_bytes(reply, byteorder="little", signed=False)

        buf = self.hardware._receive(nr_bytes)
        # NOTE: indexes are actually usize (u64, np.uint64)
        # but we can safely assume all indexes are less than isize::MAX
        # and fit in a np.int64 without wrapping
        dtype = np.dtype(np.int64).newbyteorder("<")
        map = np.frombuffer(buf, dtype)

        return map

    def _get_fullmap(self) -> npt.NDArray[np.int64]:
        submap = self._get_submap()

        # calculate parameters for final ordering
        nr_channels = self.nr_inputs
        if self._mode is SpecMode.Cpsd:
            nr_channels //= 2
        stride = 4 // self.nr_inputs

        # data indexes for re-ordering
        fullmap = np.tile(submap, (stride, 1))
        fullmap *= stride
        for k in range(stride):
            fullmap[k, :] += k
        fullmap *= nr_channels
        fullmap.shape = (-1,)

        return fullmap

    @overload
    def measure(
        self,
        mode: Literal[SpecMode.FftAvg],
        input_ports: IntAny,
        nr_meas: int,
        period: float,
        auto_sync: bool = True,
        quiet: bool = False,
    ) -> SpecResult[np.complex128]: ...

    @overload
    def measure(
        self,
        mode: Literal[SpecMode.FftStream],
        input_ports: IntAny,
        nr_meas: int,
        period: float,
        auto_sync: bool = True,
        quiet: bool = False,
    ) -> SpecResult[np.complex64]: ...

    @overload
    def measure(
        self,
        mode: Literal[SpecMode.Psd],
        input_ports: IntAny,
        nr_meas: int,
        period: float,
        auto_sync: bool = True,
        quiet: bool = False,
    ) -> SpecResult[np.float64]: ...

    @overload
    def measure(
        self,
        mode: Literal[SpecMode.Cpsd],
        input_ports: IntAny,
        nr_meas: int,
        period: float,
        auto_sync: bool = True,
        quiet: bool = False,
    ) -> SpecResult[np.complex128]: ...

    def measure(
        self,
        mode: SpecMode,
        input_ports: IntAny,
        nr_meas: int,
        period: float,
        auto_sync: bool = True,
        quiet: bool = False,
    ) -> SpecResult:
        r"""Measure the spectral content of the signal at ``input_ports``.

        Depending on ``mode``, measure the averaged fast Fourier transform (FFT), multiple FFT
        windows, the power spectral density (PSD), or the cross PSD (CPSD).

        Args:
            mode: select measurement mode, see :class:`SpecMode` for details
            input_ports (int or list): input port, can be a list of up to 4 ports
            nr_meas: number of individual FFT/PSD windows to measure or to average, depending on ``mode``
            period: requested measurement period (integration time) for the FFT/PSD, corresponding
                to the inverse of the frequency resolution. See *Notes* section below for details
            auto_sync: if ``True`` (default), trigger signal generation and acquisition internally.
                Set to ``False`` to synchronize to an external source, e.g. a Metronomo unit.
            quiet: set to ``True`` to inhibit printing timing information

        Returns:
            ``res`` - a container for the measurement results, see :class:`SpecResult` for
            documentation

        Notes:
            The `period` is assumed to be tuned, see :meth:`tune_period` for details. If `period`
            is not tuned, the backend will choose the available period that is closest to the
            user-requested value.

            The shape and data type of the returned ``res.data`` depends on the measurement
            ``mode``, see :attr:`SpecResult.data` for documentation.

        Raises:
            ValueError: if ``input_ports`` is not in [1, :meth:`get_nr_ports`]
            ValueError: if ``len(input_ports)`` is not 1, 2 or 4
            RuntimeError: if any setup error is detected while setting up the measurement

        Examples:

            See documentation for the :class:`Spectral` class for examples.
        """
        input_ports = asarray(input_ports, np.int64)
        self._measure_any(mode, input_ports, period, nr_meas, [])
        return self._do_it(auto_sync=auto_sync, quiet=quiet)

    def stream(
        self,
        input_ports: IntAny,
        period: float,
        indexes: Optional[IntAny] = None,
        freqs: Optional[FloatAny] = None,
        auto_sync: bool = True,
        quiet: bool = False,
    ) -> SpecReceiver:
        r"""Measure continuously the spectral content of the signal at ``input_ports``.

        This will measure the fast Fourier transform (FFT) of the signal.

        Args:
            input_ports (int or list): input port, can be a list of up to 4 ports
            period: requested measurement period (integration time) for the FFT, corresponding to
                the inverse of the frequency resolution. See *Notes* section below for details
            indexes (list of int, optional): which FFT frequency components (bin indexes) should be
                measured. If :obj:`None` (default), all of them
            freqs (list of float, optional): which FFT frequency components (bin indexes) should be
                measured. If :obj:`None` (default), all of them
            auto_sync: if ``True`` (default), trigger signal generation and acquisition internally.
                Set to ``False`` to synchronize to an external source, e.g. a Metronomo unit.
            quiet: set to ``True`` to inhibit printing timing information

        Returns:
            ``recv`` - a handle to the spectral receiver, see :class:`SpecReceiver` for
            documentation

        Notes:
            The `period` is assumed to be tuned, see :meth:`tune_period` for details. If `period`
            is not tuned, the backend will choose the available period that is closest to the
            user-requested value.

            By default, all measured FFT frequencies will be streamed, see :meth:`fftfreq`.
            Optional arguments `indexes` and `freqs` can be used to stream only a subset of all the
            measured frequencies and therefore save bandwidth and memory.

            Use `freqs` to select components based on their value in hertz (Hz). If the requested
            value is not a valid FFT frequency, the closest valid value will be selected. Use
            `indexes` to select components based on their index in the array returned by
            :meth:`fftfreq`. It is an error to specify both `freqs` and `indexes`.

            Specifying frequency components with `indexes` or `freqs` will ensure that *at least*
            those components are streamed. The backend might stream more components than requested,
            see :attr:`recv.freqs <SpecReceiver.freqs>` for a list of all the frequencies that
            are being streamed.

        Raises:
            ValueError: if ``input_ports`` is not in [1, :meth:`get_nr_ports`]
            ValueError: if ``len(input_ports)`` is not 1, 2 or 4
            ValueError: if both `indexes` and `freqs` are not `None`
            RuntimeError: if any setup error is detected while setting up the measurement

        Examples:

            See documentation for the :class:`SpecReceiver` class for examples.
        """
        input_ports = asarray(input_ports, np.int64)
        if indexes is None:
            if freqs is None:
                # all of them!
                indexes = []
            else:
                freqs = asarray(freqs, np.float64)
                all_freqs = self.fftfreq(period)
                indexes = np.unique([np.abs(all_freqs - f).argmin() for f in freqs]).astype(
                    np.int64, copy=False
                )
        else:
            if freqs is None:
                indexes = np.unique(indexes).astype(np.int64, copy=False)
            else:
                raise ValueError("both indexes and freqs were specified, choose one!")

        self._measure_any(SpecMode.FftStream, input_ports, period, 0xFFFF_FFFF, indexes)

        self._check()
        assert self._input_setup is not None

        # TODO: check for dry_run
        cycle_bytes, cycle_dma_bytes = self._setup(quiet=quiet)
        fullmap = self._get_fullmap()
        self.hardware.assert_errors()

        self.hardware._send_command(cmd.Msg__SpecStream())
        # measurement is triggered by next SYSREF edge
        if auto_sync:
            # trigger immediately
            self.hardware.sync()

        # receive confirmation the server is waiting for a connection
        reply = self.hardware._receive(8)
        assert 35 == int.from_bytes(reply, byteorder="little", signed=False)

        # other measurement parameters
        nr_freqs = len(fullmap)
        dt = 1.0 / self.get_fs("adc")
        all_freqs = np.fft.fftfreq(nr_freqs, dt)
        ports = self._input_setup.ports()

        if len(indexes) > 0:
            # frequency bins wanted by the user
            wanted_bins = indexes
            # all measured bins, in frequency order
            all_bins = np.arange(len(fullmap))

            # NOTE: FftStream only!
            # - nr_channels should be half in Cpsd
            # - // 2 in components assumes single precision
            nr_channels = self.nr_inputs
            stride = 4 // nr_channels

            # components selected by the user
            # in each sub-FFT, including factor of 2 from single precision
            all_submap_idxs = (fullmap // nr_channels) // stride
            all_comp_idxs = all_submap_idxs // 2
            # this we set in FPGA
            wanted_comp_idxs = np.unique(all_comp_idxs[wanted_bins])

            # calculate back what bins we actually receive
            # all frequency bins we would get, in data order
            all_bins_do = np.argsort(fullmap)
            # reshape so that rows correspond to same component bit
            all_bins_do.shape = (-1, 8 // nr_channels)
            # filter on the selected component bits
            willget_bins_do = all_bins_do[wanted_comp_idxs]
            willget_bins_do.shape = (-1,)
            # frequencies we receive, in data order
            willget_freqs_do = all_freqs[willget_bins_do]
            # map from data order to FFT order
            willget_map = np.argsort(all_bins[willget_bins_do])

            stream_map = nr_channels * willget_map
            stream_freqs = willget_freqs_do[willget_map]
        else:
            # stream all the components
            stream_map = fullmap
            stream_freqs = all_freqs

        return SpecReceiver(
            sock=self.hardware._new_connection(),
            nr_inputs=self._input_setup.nr_inputs,
            bytes_per_meas=cycle_bytes,
            map=stream_map,
            freqs=stream_freqs,
            input_ports=ports,
        )

    def setup_delay(
        self,
        *,
        pre_delay: float = 0.0,
        start_delay: float = 0.0,
        end_delay: float = 0.0,
    ):
        """
        Configure FFT measurement delays.

        Args:
            pre_delay: delay in seconds before the first FFT window starts
            start_delay: delay in seconds before the first FFT window starts
            end_delay: delay in seconds before the first FFT window starts

        Notes:
            ``pre_delay`` adds a delay at the very beginning of the measurement sequence, between
            the start of the output waveform (DAC) and the first input window (ADC).
            ``start_delay`` and ``end_delay`` add some "dead time" within each input window. Data
            measured during this dead time is discarded and not included in the FFT calculation:

            .. image:: /images/spec_delays_dark.svg
                :class: only-dark
            .. image:: /images/spec_delays_light.svg
                :class: only-light
        """
        self._pre_delay = pre_delay
        self._start_delay = start_delay
        self._end_delay = end_delay


@enum.unique
class SpecMode(enum.Enum):
    """Specify the *spectral* measurement mode.

    Used as parameter to :meth:`Spectral.measure`.
    """

    FftAvg = 0
    """Measure the averaged fast Fourier transform (FFT).

    :meta hide-value:
    """

    FftStream = 1
    """Measure multiple (stacked) fast Fourier transform (FFT) windows.

    :meta hide-value:
    """

    Psd = 2
    """Measure the averaged power spectral density (PSD).

    :meta hide-value:
    """

    Cpsd = 3
    """Measure the cross power spectral density (CPSD).

    :meta hide-value:
    """

    def dtype(self) -> type[DataType]:
        if self is type(self).FftAvg:
            return np.complex128
        elif self is type(self).FftStream:
            return np.complex64
        elif self is type(self).Psd:
            return np.float64
        elif self is type(self).Cpsd:
            return np.complex128
        else:
            raise NotImplementedError


@enum.unique
class TuningStrategy(enum.Enum):
    """Specify an optional tuning strategy for the FFT period.

    Used as parameter to :meth:`Spectral.tune_period`.
    """

    Closest = 0
    """DEFAULT -- Choose the period supported by the hardware that is closest to the user-requested
    value. This is the default strategy.

    :meta hide-value:
    """

    AtLeast = 1
    """Choose the period supported by the hardware that is greater than or equal to the
    user-requested value. If the requested value is greater than the maximum-supported period,
    choose the latter.

    :meta hide-value:
    """

    AtMost = 2
    """Choose the period supported by the hardware that is less than or equal to the user-requested
    value. If the requested value is smaller than the minimum-supported period, choose the latter.

    :meta hide-value:
    """


class OutType(enum.Enum):
    Nil = enum.auto()
    Raw = enum.auto()
    MultiCos = enum.auto()


SR_T = TypeVar("SR_T", bound=DataType)


class SpecResult(Generic[SR_T]):
    """Container for measurement results in *spectral* mode.

    Used as return type by :meth:`Spectral.measure`.

    Warning:
        Do not instantiate this class directly! Call :meth:`Spectral.measure` to obtain a valid
        instance.
    """

    def __init__(
        self,
        *,
        mode: SpecMode,
        freqs: npt.NDArray[np.floating],
        data: npt.NDArray[SR_T],
        input_ports: List[int],
    ):
        self.mode: SpecMode = mode
        """Measurement mode."""

        self.freqs: npt.NDArray[np.floating] = freqs
        """Array of measured frequencies (the *x* axis)"""

        self.data: npt.NDArray[SR_T] = data
        """Array of measured spectral data (the *y* axis).

        The shape and data type depend on the parameters ``mode``, ``input_ports`` and ``nr_meas``
        to :meth:`Spectral.measure`:

        ======================  ================================= =====================================
        Mode                    Shape                               Type
        ======================  ================================= =====================================
        ``SpecMode.FftStream``  ``(nr_meas, nr_ports, nr_freqs)`` :attr:`complex64 <numpy.complex64>`
        ``SpecMode.FftAvg``     ``(nr_ports, nr_freqs)``          :attr:`complex128 <numpy.complex128>`
        ``SpecMode.Psd``        ``(nr_ports, nr_freqs)``          :attr:`float64 <numpy.float64>`
        ``SpecMode.Cpsd``       ``(nr_ports // 2, nr_freqs)``     :attr:`complex128 <numpy.complex128>`
        ======================  ================================= =====================================

        where ``nr_meas`` is the number of independent measurements,
        ``nr_ports = len(input_ports)`` is the number of measured input ports, and
        ``nr_freqs = len(freqs)`` is the number of measured frequency components.
        """

        self.input_ports: List[int] = input_ports
        """Input ports the data was measured from."""

    @classmethod
    def _dummy(cls, mode: SpecMode):
        return cls(mode=mode, freqs=np.array([]), data=np.array([]), input_ports=[])

    def to_db(self) -> npt.NDArray[np.floating]:
        """Convenience function to convert measured spectral :attr:`data` to decibel (dB) units.

        Returns:
            an array of measured data in decibel (dB)

        Notes:
            ``to_db(data)`` is equivalent to ``20.0 * np.log10(np.abs(data))`` in FFT mode,
            and to ``10.0 * np.log10(np.abs(data))`` in PSD and CPSD mode.
        """
        if self.mode is SpecMode.FftAvg:
            scale = 20.0
        elif self.mode is SpecMode.FftStream:
            scale = 20.0
        elif self.mode is SpecMode.Psd:
            scale = 10.0
        elif self.mode is SpecMode.Cpsd:
            scale = 10.0
        else:
            raise NotImplementedError

        return scale * np.log10(np.abs(self.data))

    def to_correlation(self) -> Tuple[npt.NDArray[np.float64], npt.NDArray[np.complex128]]:
        """Convenience function to convert measured PSD/CPSD :attr:`data` to auto/cross correlation.

        Returns:
            a tuple of ``(lags, corr)`` where
                - ``lags``: array of time lags of length ``data.shape[-1]``
                - ``corr``: array of auto/cross correlation with same shape as ``data``

        Raises:
            TypeError: if the measurement :attr:`mode` is not ``SpecMode.Psd`` or ``SpecMode.Cpsd``.
        """
        if self.mode is SpecMode.Psd or self.mode is SpecMode.Cpsd:
            n = len(self.freqs)
            df = self.freqs[1] - self.freqs[0]
            fs = n * df
            inv = np.fft.ifft(self.data, axis=-1)
            inv = np.fft.fftshift(inv, axes=-1)
            x = self._correlation_lags(n) / fs
            return x, inv
        else:
            raise TypeError("")

    def _correlation_lags(self, n: int) -> npt.NDArray[np.int64]:
        # scipy.signal.correlation_lags(in1_len=n, in2_len=n, mode="same")
        # from scipy v1.14.1
        # https://github.com/scipy/scipy/blob/v1.14.1/scipy/signal/_signaltools.py#L296-L390
        lags = np.arange(-n + 1, n)
        mid = lags.size // 2
        lag_bound = n // 2
        if n % 2 == 0:
            lags = lags[(mid - lag_bound) : (mid + lag_bound)]
        else:
            lags = lags[(mid - lag_bound) : (mid + lag_bound) + 1]
        return lags


class _InputSetup:
    def __init__(
        self,
        mode: SpecMode,
        period: float,
        nr_inputs: int,
        mux: List[int],
        nr_cycles: int,
        components: IntList,
    ) -> None:
        self.mode = mode
        self.period = period
        self.nr_inputs = nr_inputs
        self.mux = mux
        self.nr_cycles = nr_cycles
        self.components: List[int] = components  # pyright: ignore[reportAttributeAccessIssue]

    def to_tuple(self) -> Tuple[int, float, int, List[int], int, List[int]]:
        return (
            self.mode.value,
            self.period,
            self.nr_inputs,
            self.mux,
            self.nr_cycles,
            self.components,
        )

    def ports(self) -> List[int]:
        return [self.mux[x] + 1 for x in range(self.nr_inputs)]


class SpecReceiver(StreamReceiver[npt.NDArray[np.complex64]]):
    """A receiver of spectral data running in the background.

    Used as return type by :meth:`Spectral.stream`.

    Warning:
        Do not instantiate this class directly! Call :meth:`Spectral.stream` to obtain a valid
        instance.

    Examples:

        >>> with Spectral(
        >>>     address=PRESTOs_IP_ADDRESS,
        >>> ) as spec:
        >>>     # configure 1.5 GHz carrier for up- and down-conversion
        >>>     spec.hardware.configure_mixer(
        >>>         freq=1.5e9,
        >>>         in_ports=1,
        >>>         out_ports=1,
        >>>     )
        >>>
        >>>     # 1 MHz resolution in FFT
        >>>     period = spec.tune_period(1.0e-6)
        >>>
        >>>     # drive two tones at 110 and 112 MHz
        >>>     # with same phase but different amplitude
        >>>     # on output port 1
        >>>     freq = [110.0e6, 112.0e6]
        >>>     amp = [0.1, 0.2]
        >>>     phase = [0.0, 0.0]
        >>>     spec.output_multicos(1, period, freq, amp, phase)
        >>>
        >>>     # continuously receive FFT measurements
        >>>     # on input port 1
        >>>     # in chunks of 100 measurements
        >>>     with spec.stream(1, period) as recv:
        >>>         data = recv.get_last(100)
    """

    def __init__(
        self,
        *,
        sock: socket.socket,
        freqs: npt.NDArray[np.floating],
        input_ports: List[int],
        nr_inputs: int,
        bytes_per_meas: int,
        map: npt.NDArray[np.integer],
        buf_size: int = 1 << 30,
    ):
        self.freqs = freqs
        """Array of measured frequencies (the *x* axis)"""
        self.input_ports = input_ports

        self._readonly_nr_inputs = nr_inputs
        self._map = map

        super().__init__(
            sock=sock,
            bytes_per_meas=bytes_per_meas,
            extra_bytes=0,
            buf_size=buf_size,
        )

    @property
    def nr_inputs(self):
        """The number of interleaved input ports."""
        return self._readonly_nr_inputs

    def _process_data(self, nr_meas: int, buf: bytearray):
        dtype = np.dtype(np.complex64).newbyteorder("<")
        data_raw = np.frombuffer(buf, dtype=dtype)

        data_raw.shape = (nr_meas, -1)
        data = np.empty_like(data_raw)
        data.shape = (nr_meas, self.nr_inputs, -1)
        for ii in range(nr_meas):
            for ch in range(self.nr_inputs):
                data[ii, ch, :] = data_raw[ii, self._map + ch]

        data /= 32767.0 * data.shape[-1]

        return data


# fmt: off
# NOTE: keep in sync with FftPlan::GOOD in rustws/libs/fft/src/lib.rs
_GOOD_SUBLEN: list[int] = [
    1, 2, 3, 4, 5, 6, 8, 9, 10, 12, 15, 16, 18, 20, 24, 25, 27, 30, 32, 36, 40, 45, 48, 50, 54, 60,
    64, 72, 75, 80, 81, 90, 96, 100, 108, 120, 125, 128, 135, 144, 150, 160, 162, 180, 192, 200,
    216, 225, 240, 250, 256, 270, 288, 300, 320, 324, 360, 384, 400, 432, 450, 480, 486, 500, 512,
    540, 576, 600, 640, 648, 720, 750, 768, 800, 810, 864, 900, 960, 972, 1000, 1024, 1080, 1152,
    1200, 1250, 1280, 1296, 1350, 1440, 1458, 1500, 1536, 1600, 1620, 1728, 1800, 1920, 1944, 2000,
    2048, 2160, 2250, 2304, 2400, 2430, 2500, 2560, 2592, 2700, 2880, 2916, 3000, 3072, 3200, 3240,
    3456, 3600, 3750, 3840, 3888, 4000, 4050, 4096, 4320, 4374, 4500, 4608, 4800, 4860, 5000, 5120,
    5184, 5400, 5760, 5832, 6000, 6144, 6250, 6400, 6480, 6750, 6912, 7200, 7290, 7500, 7680, 7776,
    8000, 8100, 8192, 8640, 8748, 9000, 9216, 9600, 9720, 10000, 10240, 10368, 10800, 11250, 11520,
    11664, 12000, 12150, 12288, 12500, 12800, 12960, 13500, 13824, 14400, 14580, 15000, 15360,
    15552, 16000, 16200, 16384, 17280, 18000, 18432, 18750, 19200, 19440, 20000, 20250, 20480,
    20736, 21600, 22500, 23040, 24000, 24300, 24576, 25000, 25600, 25920, 27000, 27648, 28800,
    30000, 30720, 31250, 32000, 32400, 32768, 33750, 34560, 36000, 36864, 37500, 38400, 40000,
    40500, 40960, 43200, 45000, 46080, 48000, 49152, 50000, 51200, 54000, 56250, 57600, 60000,
    61440, 62500, 64000, 65536, 67500, 72000, 75000, 76800, 80000, 81920,
]
# fmt: on
