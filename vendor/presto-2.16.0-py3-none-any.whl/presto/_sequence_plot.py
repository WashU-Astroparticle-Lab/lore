# -*- coding: utf-8 -*-
# Copyright © 2018-2024 Intermodulation Products AB. All Rights Reserved.
from __future__ import annotations

import warnings

from cycler import cycler
from matplotlib.axes import Axes
from matplotlib.colors import to_rgb
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle, Patch
import matplotlib.pyplot as plt
from matplotlib.widgets import RadioButtons, RangeSlider, Slider
import numpy as np
from typing import Union, List, Optional

from presto import pulsed
from presto.pulsed import SMPLS_PER_CLK


def plot_sequence(
    pls: pulsed.Pulsed,
    period_secs: Optional[float] = None,
    repeat_count: Union[int, tuple] = 1,
    num_averages: int = 1,
) -> Figure:
    # docstring in utils module

    # inital ploting parameters
    plot_imag = False
    fs_dac = pls.get_fs("dac") / 1e9  # samples/ns
    total_repeat_count = int(np.prod(repeat_count))  # for multidim sweeps

    if period_secs is None:
        if len(pls.seq) > 0:
            seq = sorted(
                pls.seq,
                key=lambda x: (x[0],),
            )
            period = (
                seq[-1][0] + 100_000
            )  # start of last command + some margin in case it is a pulse
        else:
            print("Sequence has no commands")
            raise
    else:
        period = pls.time_to_clk(period_secs)

    try:
        pls._check(
            period,
            repeat_count,
            num_averages,
            False,
            False,
            False,
        )
    except Exception:
        print("Oops! Something seems to be off with the sequence...")
        raise

    direct_mode = pls.dac_direct
    if direct_mode and plot_imag:
        plot_imag = False
        warnings.warn("Templates are real in Direct mode. Overriding plot_imag")

    seq = sorted(
        pls.seq,
        key=lambda x: (
            x[1].channel if isinstance(x[1], pulsed.RawTemplate) else 10000,
            x[1].group if isinstance(x[1], pulsed.RawTemplate) else 10000,
            x[0],
        ),
    )
    repeat_count_shape = np.shape(repeat_count)
    if repeat_count_shape:
        repeat_count_dim = repeat_count_shape[0]
    else:
        repeat_count_dim = 1
    iteration_list = [0] * repeat_count_dim
    fig = plt.figure(constrained_layout=True)
    gs = fig.add_gridspec(13 + repeat_count_dim, 6)
    ax_out = fig.add_subplot(gs[0:6, 0:5])
    ax_store = fig.add_subplot(gs[6:8, 0:5])
    ax_match = fig.add_subplot(gs[8:12, 0:5])
    ax_slider = fig.add_subplot(gs[12, 0:5])
    ax_repeat_count = []
    for i in range(repeat_count_dim):
        ax_repeat_count.append(fig.add_subplot(gs[13 + i, 0:5]))

    # make pyright shut up
    assert isinstance(ax_out, Axes)
    assert isinstance(ax_store, Axes)
    assert isinstance(ax_match, Axes)

    ax_out.sharex(ax_match)
    ax_store.sharex(ax_match)
    ax_all = [ax_out, ax_store, ax_match]

    handles_out = []
    handles_match = []
    y_out_tick_pos = []
    y_out_tick_labels = []
    x_lim_first = None
    x_lim_last = None

    x_plot_unit = pls.get_clk_T() * 1e9  # ns

    next_base_out = -2 - 2j
    next_base_matches = 0.0 + 0j
    times = set()
    hlines = np.arange(1, -(2 * 16 - 1 - 2), -2, dtype=np.float64)
    pulses = dict()
    matches = dict()
    scales = dict()
    freqs = dict()
    color_cycle = cycler(
        "color",
        [
            "#1f77b4",
            "#ff7f0e",
            "#2ca02c",
            "#d62728",
            "#9467bd",
            "#8c564b",
            "#e377c2",
            "#7f7f7f",
            "#bcbd22",
            "#17becf",
        ],
    )

    color_cycle_im = cycler(
        "color",
        [
            "#1f77b4",
            "#ff7f0e",
            "#2ca02c",
            "#d62728",
            "#9467bd",
            "#8c564b",
            "#e377c2",
            "#7f7f7f",
            "#bcbd22",
            "#17becf",
        ],
    )
    cc_out = color_cycle()
    cc_out_im = color_cycle_im()
    cc_matches = color_cycle()
    cc_matches_im = color_cycle_im()

    for t, e in seq:
        start = t * x_plot_unit
        if isinstance(e, pulsed.RawTemplate):
            start += e.offset * x_plot_unit
            duration = e.duration * x_plot_unit
            end = start + duration
            key = (e.channel + 1, e.group)
            if direct_mode:
                x = np.linspace(start, end, e.duration * SMPLS_PER_CLK + 1)
                y = e.get_data()[4:]
            else:
                x = np.linspace(start, end, e.duration * SMPLS_PER_CLK // 2 + 1)
                y = e.get_data()[4::2] + 1j * e.get_data()[5::2]
            y = np.append(y, y[-1])
            if len(y) != len(x):
                y = np.resize(y, len(x))
            # inverted is None if pulse is not conditional, otherwise it's bool
            alpha = 0.5 if e.inverted is None else 0.2
            try:
                color, color_im = (
                    pulses[key]["color"],
                    pulses[key]["color_im"],
                )
                pulses[key]["x"].append(x)
                pulses[key]["y"].append(y)
                pulses[key]["y_temp"].append(y)
                pulses[key]["alpha"].append(alpha)
                pulses[key]["envelope"].append(e.envelope)
            except KeyError:
                color = cc_out.__next__()["color"]
                color_im = cc_out_im.__next__()["color"]
                pulses[key] = {
                    "color": color,
                    "color_im": color_im,
                    "base": 0.0 + 1j * 0.0,
                    "x": [x],
                    "y": [y],
                    "y_temp": [y],
                    "alpha": [alpha],
                    "envelope": [e.envelope],
                    "scales": [],
                    "freqs": [],
                    "lines_re": [],
                    "fills_re": [],
                    "lines_im": [],
                    "fills_im": [],
                }
            base = pulses[key]["base"]
            (line,) = ax_out.plot(x, np.real(y), ls="-" if alpha == 0.5 else ":", color=color)
            f = ax_out.fill_between(
                x, np.real(y), np.real(base), color=color, alpha=alpha, hatch="----"
            )
            pulses[key]["lines_re"].append(line)
            pulses[key]["fills_re"].append(f)
            (line,) = ax_out.plot(
                x, np.imag(y), ls="--" if alpha == 0.5 else "-.", color=color_im, visible=plot_imag
            )
            f = ax_out.fill_between(
                x,
                np.imag(y),
                np.imag(base),
                color=color_im,
                alpha=alpha,
                hatch="||||",
                visible=plot_imag,
            )
            pulses[key]["lines_im"].append(line)
            pulses[key]["fills_im"].append(f)
            times.add(start)
            times.add(end)
        elif isinstance(e, pulsed.Store):
            end = start + e.duration * x_plot_unit
            duration = end - start
            rect = Rectangle((start, 0), duration, 1, color="tab:gray")
            ax_store.add_patch(rect)
            times.add(start)
            times.add(end)
            if x_lim_first is None:
                x_lim_first = end
            elif x_lim_last is None:
                x_lim_last = end
            elif end > x_lim_last:
                x_lim_last = end
        elif isinstance(e, pulsed.RawMatch):
            key = (e.group, e.index)
            duration = e.duration * x_plot_unit
            end = start + duration
            templates = pls.match_templates
            alpha = 0.5
            if direct_mode:
                x = np.linspace(start, end, e.duration * SMPLS_PER_CLK + 1)
                y = templates[e.group][e.index][4:]  # type: ignore[reportOptionalSubscript]
            else:
                x = np.linspace(start, end, e.duration * SMPLS_PER_CLK // 2 + 1)
                y = templates[e.group][e.index][4::2] + 1j * templates[e.group][e.index][5::2]  # type: ignore[reportOptionalSubscript]
            y = np.append(y, y[-1])
            if len(y) != len(x):
                y = np.resize(y, len(x))
            try:
                color, color_im, base = (
                    matches[key]["color"],
                    matches[key]["color_im"],
                    matches[key]["base"],
                )
                matches[key]["x"].append(x)
                matches[key]["y"].append(y)
                matches[key]["y_temp"].append(y)
            except KeyError:
                color = cc_matches.__next__()["color"]
                color_im = cc_matches_im.__next__()["color"]
                base = next_base_matches
                next_base_matches -= 2 + 2j
                matches[key] = {
                    "color": color,
                    "color_im": color_im,
                    "base": base,
                    "x": [x],
                    "y": [y],
                    "y_temp": [y],
                    "alpha": [alpha],
                    "lines_re": [],
                    "fills_re": [],
                    "lines_im": [],
                    "fills_im": [],
                }
            if x_lim_first is None:
                x_lim_first = end
            elif x_lim_last is None:
                x_lim_last = end
            elif end > x_lim_last:
                x_lim_last = end
            (line,) = ax_match.plot(
                x,
                np.real(base + y),
                color=color,
            )
            f = ax_match.fill_between(
                x, np.real(base + y), np.real(base), color=color, alpha=alpha, hatch="----"
            )
            matches[key]["lines_re"].append(line)
            matches[key]["fills_re"].append(f)
            (line,) = ax_match.plot(x, np.imag(base + y), "--", color=color_im, visible=plot_imag)
            f = ax_match.fill_between(
                x,
                np.imag(base + y),
                np.imag(base),
                color=color_im,
                alpha=alpha,
                hatch="||||",
                visible=plot_imag,
            )
            matches[key]["lines_im"].append(line)
            matches[key]["fills_im"].append(f)
            times.add(start)
            times.add(end)
        elif isinstance(e, pulsed.NextScale):
            key = (e.channel + 1, e.group)
            try:
                scales[key]["start"].append(start)
                scales[key]["scale_ind"].append(-1)
                scales[key]["scale"].append(np.nan)
            except KeyError:
                scales[key] = {"start": [start], "scale_ind": [-1], "scale": [np.nan]}
        elif isinstance(e, pulsed.SelScale):
            scale = pls.scale_luts[e.channel][e.group][e.index]  # type: ignore[reportOptionalSubscript]
            key = (e.channel + 1, e.group)
            try:
                scales[key]["start"].append(start)
                scales[key]["scale_ind"].append(e.index)
                scales[key]["scale"].append(scale)
            except KeyError:
                scales[key] = {"start": [start], "scale_ind": [e.index], "scale": [scale]}
        elif isinstance(e, pulsed.NextFreq):
            key = (e.channel + 1, e.group)
            try:
                freqs[key]["start"].append(start)
                freqs[key]["freq_ind"].append(-1)
                freqs[key]["freq"].append(np.nan)
                freqs[key]["ph_i"].append(np.nan)
                freqs[key]["ph_q"].append(np.nan)
            except KeyError:
                freqs[key] = {
                    "start": [start],
                    "freq_ind": [-1],
                    "freq": [np.nan],
                    "ph_i": [np.nan],
                    "ph_q": [np.nan],
                }
        elif isinstance(e, pulsed.SelFreq):
            freq = pls.freq_luts[e.channel][e.group][e.index]  # type: ignore[reportOptionalSubscript]
            ph_i = pls.phase_i_luts[e.channel][e.group][e.index]  # type: ignore[reportOptionalSubscript]
            ph_q = 0 if direct_mode else pls.phase_q_luts[e.channel][e.group][e.index]  # type: ignore[reportOptionalSubscript]
            key = (e.channel + 1, e.group)
            try:
                freqs[key]["start"].append(start)
                freqs[key]["freq_ind"].append(e.index)
                freqs[key]["freq"].append(freq)
                freqs[key]["ph_i"].append(ph_i)
                freqs[key]["ph_q"].append(ph_q)
            except KeyError:
                freqs[key] = {
                    "start": [start],
                    "freq_ind": [e.index],
                    "freq": [freq],
                    "ph_i": [ph_i],
                    "ph_q": [ph_q],
                }
        elif isinstance(e, pulsed.ResetPhase):
            key = (e.channel + 1, e.group)
            try:
                freqs[key]["start"].append(start)
                freqs[key]["freq_ind"].append(-2)
                freqs[key]["freq"].append(np.nan)
                freqs[key]["ph_i"].append(np.nan)
                freqs[key]["ph_q"].append(np.nan)
            except KeyError:
                freqs[key] = {
                    "start": [start],
                    "freq_ind": [-2],
                    "freq": [np.nan],
                    "ph_i": [np.nan],
                    "ph_q": [np.nan],
                }

        else:
            print("Unknown event in sequence")
            print(f"    {e}")
            print(f"    {type(e)}")

    ########################################
    # apply scales to pulse sequence
    for key in pulses:
        axis = pls._scale_axis[key[0] - 1][key[1]]
        if key in scales:
            scales[key]["start"] = np.array(scales[key]["start"])
            scales[key]["scale_ind"] = np.array(scales[key]["scale_ind"])
            scales[key]["scale"] = np.array(scales[key]["scale"])

            # figure out the scales for each iteration
            if axis in [-1, repeat_count_dim - 1]:
                scales[key]["start"] = (
                    np.tile(scales[key]["start"], total_repeat_count)
                    + np.repeat(np.arange(total_repeat_count), len(scales[key]["start"]))
                    * period
                    * x_plot_unit
                )
                scales[key]["scale_ind"] = np.tile(scales[key]["scale_ind"], total_repeat_count)
                scales[key]["scale"] = np.tile(scales[key]["scale"], total_repeat_count)
            else:
                ind_next = np.where(scales[key]["scale_ind"] == -1)[0]
                ind_rest = np.where(scales[key]["scale_ind"] != -1)[0]
                partial_repeat_count = int(np.prod(repeat_count[: axis + 1])) + 1  # type:ignore

                start_next = (
                    np.tile(scales[key]["start"][ind_next], partial_repeat_count)
                    + np.repeat(
                        np.arange(partial_repeat_count), len(scales[key]["start"][ind_next])
                    )
                    * period
                    * x_plot_unit
                    * int(np.prod(repeat_count[axis + 1 :]))  # type:ignore
                    - period * x_plot_unit
                )[1:]
                scale_ind_next = np.tile(scales[key]["scale_ind"][ind_next], partial_repeat_count)[
                    1:
                ]
                scale_next = np.tile(scales[key]["scale"][ind_next], partial_repeat_count)[1:]

                start_rest = (
                    np.tile(scales[key]["start"][ind_rest], total_repeat_count)
                    + np.repeat(np.arange(total_repeat_count), len(scales[key]["start"][ind_rest]))
                    * period
                    * x_plot_unit
                )
                scale_ind_rest = np.tile(scales[key]["scale_ind"][ind_rest], total_repeat_count)
                scale_rest = np.tile(scales[key]["scale"][ind_rest], total_repeat_count)

                scales[key]["start"] = np.concatenate((start_next, start_rest))
                scales[key]["scale_ind"] = np.concatenate((scale_ind_next, scale_ind_rest))
                scales[key]["scale"] = np.concatenate((scale_next, scale_rest))

                sorted_ind = np.argsort(scales[key]["start"])
                scales[key]["start"] = np.array(scales[key]["start"])[sorted_ind]
                scales[key]["scale_ind"] = np.array(scales[key]["scale_ind"])[sorted_ind]
                scales[key]["scale"] = np.array(scales[key]["scale"])[sorted_ind]
        try:  # add scale at time T=0.0 if there were NextScale of SelScale for this key, but they were not called at T=0.0
            starts = scales[key]["start"]
            if not any([x == 0.0 for x in starts]):
                scale = pls.scale_luts[key[0] - 1][key[1]][0]
                scales[key]["start"] = np.insert(scales[key]["start"], 0, 0.0)
                scales[key]["scale_ind"] = np.insert(scales[key]["scale_ind"], 0, 0)
                scales[key]["scale"] = np.insert(scales[key]["scale"], 0, scale)
        except KeyError:
            # add scale at time 0.0 if there were no NextScale of SelScale for this key
            scale = pls.scale_luts[key[0] - 1][key[1]][0]
            scales[key] = {"start": [0.0], "scale_ind": [0], "scale": [scale]}

        # if there was a nextscale at T=0.0
        if scales[key]["scale_ind"][0] == -1:
            scales[key]["scale_ind"][0] = 0 if len(pls.scale_luts[key[0] - 1][key[1]]) == 1 else 1
            scales[key]["scale"][0] = pls.scale_luts[key[0] - 1][key[1]][
                scales[key]["scale_ind"][0]
            ]

        for i in range(1, len(scales[key]["start"])):
            # if there was a nextscale fix
            if scales[key]["scale_ind"][i] == -1:
                scale_ind = (
                    0
                    if scales[key]["scale_ind"][i - 1]
                    == len(pls.scale_luts[key[0] - 1][key[1]]) - 1
                    else scales[key]["scale_ind"][i - 1] + 1
                )
                scales[key]["scale_ind"][i] = scale_ind
                scales[key]["scale"][i] = pls.scale_luts[key[0] - 1][key[1]][scale_ind]
        # print(scales[key]["start"])
        # print(scales[key]["scale"])
        # print(scales[key]["scale_ind"])

    ########################################
    # apply IF frequencies to pulse sequence
    for key in pulses:
        axis = pls._freq_axis[key[0] - 1][key[1]]
        if key in freqs:
            freqs[key]["start"] = np.array(freqs[key]["start"])
            freqs[key]["freq_ind"] = np.array(freqs[key]["freq_ind"])
            freqs[key]["freq"] = np.array(freqs[key]["freq"])
            freqs[key]["ph_i"] = np.array(freqs[key]["ph_i"])
            freqs[key]["ph_q"] = np.array(freqs[key]["ph_q"])

            if axis in [-1, repeat_count_dim - 1]:
                freqs[key]["start"] = (
                    np.tile(freqs[key]["start"], total_repeat_count)
                    + np.repeat(np.arange(total_repeat_count), len(freqs[key]["start"]))
                    * period
                    * x_plot_unit
                )
                freqs[key]["freq_ind"] = np.tile(freqs[key]["freq_ind"], total_repeat_count)
                freqs[key]["freq"] = np.tile(freqs[key]["freq"], total_repeat_count)
                freqs[key]["ph_i"] = np.tile(freqs[key]["ph_i"], total_repeat_count)
                freqs[key]["ph_q"] = np.tile(freqs[key]["ph_q"], total_repeat_count)
            else:
                ind_next = np.where(freqs[key]["freq_ind"] == -1)[0]
                ind_rest = np.where(freqs[key]["freq_ind"] != -1)[0]
                partial_repeat_count = int(np.prod(repeat_count[: axis + 1])) + 1  # type:ignore

                start_next = (
                    np.tile(freqs[key]["start"][ind_next], partial_repeat_count)
                    + np.repeat(
                        np.arange(partial_repeat_count), len(freqs[key]["start"][ind_next])
                    )
                    * period
                    * x_plot_unit
                    * (int(np.prod(repeat_count[axis + 1 :])))  # type:ignore
                    - period * x_plot_unit
                )[1:]
                freq_ind_next = np.tile(freqs[key]["freq_ind"][ind_next], partial_repeat_count)[1:]
                freq_next = np.tile(freqs[key]["freq"][ind_next], partial_repeat_count)[1:]
                ph_i_next = np.tile(freqs[key]["ph_i"][ind_next], partial_repeat_count)[1:]
                ph_q_next = np.tile(freqs[key]["ph_q"][ind_next], partial_repeat_count)[1:]

                start_rest = (
                    np.tile(freqs[key]["start"][ind_rest], total_repeat_count)
                    + np.repeat(np.arange(total_repeat_count), len(freqs[key]["start"][ind_rest]))
                    * period
                    * x_plot_unit
                )
                freq_ind_rest = np.tile(freqs[key]["freq_ind"][ind_rest], total_repeat_count)
                freq_rest = np.tile(freqs[key]["freq"][ind_rest], total_repeat_count)
                ph_i_rest = np.tile(freqs[key]["ph_i"][ind_rest], total_repeat_count)
                ph_q_rest = np.tile(freqs[key]["ph_q"][ind_rest], total_repeat_count)

                freqs[key]["start"] = np.concatenate((start_next, start_rest))
                freqs[key]["freq_ind"] = np.concatenate((freq_ind_next, freq_ind_rest))
                freqs[key]["freq"] = np.concatenate((freq_next, freq_rest))
                freqs[key]["ph_i"] = np.concatenate((ph_i_next, ph_i_rest))
                freqs[key]["ph_q"] = np.concatenate((ph_q_next, ph_q_rest))

                sorted_ind = np.argsort(freqs[key]["start"])
                freqs[key]["start"] = np.array(freqs[key]["start"])[sorted_ind]
                freqs[key]["freq_ind"] = np.array(freqs[key]["freq_ind"])[sorted_ind]
                freqs[key]["freq"] = np.array(freqs[key]["freq"])[sorted_ind]
                freqs[key]["ph_i"] = np.array(freqs[key]["ph_i"])[sorted_ind]
                freqs[key]["ph_q"] = np.array(freqs[key]["ph_q"])[sorted_ind]

        try:  # add freq at T=0.0 if there were NextFreq, SelFreq or ResetPhase for this key and they were not called at T=0.0
            starts = freqs[key]["start"]
            freq = pls.freq_luts[key[0] - 1][key[1]]
            if freq is not None:
                if not any([x == 0.0 for x in starts]):
                    freqs[key]["start"] = np.insert(freqs[key]["start"], 0, 0.0)
                    freqs[key]["freq_ind"] = np.insert(freqs[key]["freq_ind"], 0, 0)
                    freqs[key]["freq"] = np.insert(
                        freqs[key]["freq"], 0, pls.freq_luts[key[0] - 1][key[1]][0]
                    )
                    freqs[key]["ph_i"] = np.insert(
                        freqs[key]["ph_i"], 0, pls.phase_i_luts[key[0] - 1][key[1]][0]
                    )
                    freqs[key]["ph_q"] = np.insert(
                        freqs[key]["ph_q"],
                        0,
                        0.0 if direct_mode else pls.phase_q_luts[key[0] - 1][key[1]][0],
                    )
            else:  # there are no envelope pulses for this key
                freqs[key] = {
                    "start": np.array([0.0]),
                    "freq_ind": np.array([0]),
                    "freq": np.array([0.0]),
                    "ph_i": np.array([0.0]),
                    "ph_q": np.array([0.0]),
                }

        except KeyError:
            # add freq at time 0.0 if there were no NextFreq, SelFreq or ResetPhase for this key
            freq = pls.freq_luts[key[0] - 1][key[1]]
            if freq is not None:
                freqs[key] = {
                    "start": np.array([0.0]),
                    "freq_ind": np.array([0]),
                    "freq": np.array([freq[0]]),
                    "ph_i": np.array([pls.phase_i_luts[key[0] - 1][key[1]][0]]),
                    "ph_q": np.array(
                        [0.0 if direct_mode else pls.phase_q_luts[key[0] - 1][key[1]][0]]
                    ),
                }
            else:  # there are no envelope pulses for this key
                freqs[key] = {
                    "start": np.array([0.0]),
                    "freq_ind": np.array([0]),
                    "freq": np.array([0.0]),
                    "ph_i": np.array([0.0]),
                    "ph_q": np.array([0.0]),
                }

        if freqs[key]["freq_ind"][0] == -1:  # if there was a nextfreq at T=0.0
            freqs[key]["freq_ind"][0] = 0 if len(pls.freq_luts[key[0] - 1][key[1]]) == 1 else 1
            freqs[key]["freq"][0] = pls.freq_luts[key[0] - 1][key[1]][freqs[key]["freq_ind"][0]]
            freqs[key]["ph_i"][0] = pls.phase_i_luts[key[0] - 1][key[1]][freqs[key]["freq_ind"][0]]
            freqs[key]["ph_q"][0] = (
                0
                if direct_mode
                else pls.phase_q_luts[key[0] - 1][key[1]][freqs[key]["freq_ind"][0]]
            )

        if freqs[key]["freq_ind"][0] == -2:  # if there was a ResetPhase at T=0.0
            freqs[key]["freq_ind"][0] = 0
            freqs[key]["freq"][0] = pls.freq_luts[key[0] - 1][key[1]][0]
            freqs[key]["ph_i"][0] = pls.phase_i_luts[key[0] - 1][key[1]][0]
            freqs[key]["ph_q"][0] = 0 if direct_mode else pls.phase_q_luts[key[0] - 1][key[1]][0]
        for i in range(1, len(freqs[key]["start"])):
            if freqs[key]["freq_ind"][i] == -1:  # NextFrequency
                freq_ind = (
                    0
                    if freqs[key]["freq_ind"][i - 1] == len(pls.freq_luts[key[0] - 1][key[1]]) - 1
                    else freqs[key]["freq_ind"][i - 1] + 1
                )
                freqs[key]["freq_ind"][i] = freq_ind
                freqs[key]["freq"][i] = pls.freq_luts[key[0] - 1][key[1]][freq_ind]
                freqs[key]["ph_i"][i] = pls.phase_i_luts[key[0] - 1][key[1]][freq_ind]
                freqs[key]["ph_q"][i] = pls.phase_q_luts[key[0] - 1][key[1]][freq_ind]
            if freqs[key]["freq_ind"][i] == -2:  # ResetPhase
                freq_ind = freqs[key]["freq_ind"][i - 1]
                freqs[key]["freq_ind"][i] = freq_ind
                freqs[key]["freq"][i] = pls.freq_luts[key[0] - 1][key[1]][freq_ind]
                freqs[key]["ph_i"][i] = pls.phase_i_luts[key[0] - 1][key[1]][freq_ind]
                freqs[key]["ph_q"][i] = pls.phase_q_luts[key[0] - 1][key[1]][freq_ind]

        # print(freqs[key]["start"])
        # print(freqs[key]["freq"])
        # print(freqs[key]["freq_ind"])

    # apply scales and frequencies to pulses depending on the iteration number
    _apply_scales(pulses, scales, iteration_list, repeat_count, period * x_plot_unit)
    _apply_freqs(pulses, freqs, iteration_list, repeat_count, period * x_plot_unit, fs_dac)

    for t in times:
        for ax_ in ax_all:
            ax_.axvline(t, c="tab:gray", alpha=0.1)
    for h in hlines:
        ax_out.axhline(h, c="tab:gray", alpha=0.1)

    ax_out.axhline(np.real(next_base_out) + 1, c="tab:gray", alpha=0.1)
    ax_all[-1].set_xlabel("Time [ns]")
    ax_out.set_ylabel("Output")
    ax_store.set_ylabel("Store")
    ax_match.set_ylabel("Match")

    handles_out_reim = []
    alpha = 0.5
    real_patch = Patch(
        facecolor=(*to_rgb("tab:gray"), alpha),
        hatch="----",
        edgecolor=(*to_rgb("tab:gray"), 1),
        linewidth=1.2,
        label="Real",
    )
    imag_patch = Patch(
        facecolor=(*to_rgb("tab:gray"), alpha),
        hatch="||||",
        linestyle="--",
        edgecolor=(*to_rgb("tab:gray"), 1),
        linewidth=1.2,
        label="Imag",
    )
    handles_out_reim.append(real_patch)
    if plot_imag:
        handles_out_reim.append(imag_patch)

    for key in pulses:
        pulses[key]["lines_re"][0].set_label("ch. " + str(key[0]) + ", gr. " + str(key[1]))
        handles_out.append(pulses[key]["lines_re"][0])
    for key in matches:
        matches[key]["lines_re"][0].set_label(
            "ch. " + str(key[0]) + ", in. " + str(key[1]),
        )
        handles_match.append(matches[key]["lines_re"][0])
    first_legend = ax_out.legend(handles=handles_out, loc="lower right")
    ax_out.add_artist(first_legend)
    ax_out.legend(handles=handles_out_reim, loc="upper right")
    ax_out.set_ylim(np.real(next_base_out) + 0.5, 1.5)
    ax_store.set_ylim(-0.5, 1.5)
    ax_match.legend(handles=handles_match, loc="lower right")
    ax_match.set_ylim(np.real(next_base_matches) + 0.5, 1.5)
    if x_lim_first is not None and x_lim_last is not None and x_lim_first > x_lim_last:
        t = x_lim_first
        x_lim_first = x_lim_last
        x_lim_last = t
    if x_lim_first is None:
        ax_out.set_xlim(-50, 50)
        x_lim_slider = (-50, 50)
    elif x_lim_last == x_lim_first:
        ax_out.set_xlim(-50, x_lim_first + 50)
        x_lim_slider = (-50, x_lim_first + 50)
    elif x_lim_last is not None and (x_lim_last - x_lim_first < 20_000):
        ax_out.set_xlim(-50, x_lim_last + 50)
        x_lim_slider = (-50, x_lim_last + 50)
    else:
        ax_out.set_xlim(-50, x_lim_first + 50)
        x_lim_slider = (-50, x_lim_first + 50)

    for ax_ in ax_all[1:]:
        ax_.set_yticks([])
    for ax_ in ax_all[:-1]:
        for tick in ax_.get_xticklabels():
            tick.set_visible(False)

    ax_out.set_yticks(y_out_tick_pos, y_out_tick_labels, rotation="vertical")

    def func_reim(label):
        hzdict = {"re": False, "re+im": True}
        plot_imag = hzdict[label]
        if direct_mode and plot_imag:
            plot_imag = False
            warnings.warn("Templates are real in Direct mode. Overriding plot_imag")
        if plot_imag:
            for p in pulses:
                for i in range(len(pulses[p]["x"])):
                    pulses[p]["lines_im"][i].set_visible(True)
                    pulses[p]["fills_im"][i].set_visible(True)
            for m in matches:
                for i in range(len(matches[m]["x"])):
                    matches[m]["lines_im"][i].set_visible(True)
                    matches[m]["fills_im"][i].set_visible(True)
            if len(handles_out_reim) < 2:
                handles_out_reim.append(imag_patch)
                ax_out.legend(handles=handles_out_reim, loc="upper right")
        else:
            for p in pulses:
                for i in range(len(pulses[p]["x"])):
                    pulses[p]["lines_im"][i].set_visible(False)
                    pulses[p]["fills_im"][i].set_visible(False)
            for m in matches:
                for i in range(len(matches[m]["x"])):
                    matches[m]["lines_im"][i].set_visible(False)
                    matches[m]["fills_im"][i].set_visible(False)
            if len(handles_out_reim) > 1:
                handles_out_reim.pop(1)
                ax_out.legend(handles=handles_out_reim, loc="upper right")

        fig.canvas.draw()

    def func_chgr(label):
        hzdict = {"ch+ gr+": 0, "ch+ gr-": 1, "ch- gr+": 2, "ch- gr-": 3}
        plot_chgr = hzdict[label]
        handles_out = []
        y_out_tick_pos = []
        y_out_tick_labels = []
        if plot_chgr == 0:
            next_base_out = -(2 + 2j)
            for p in pulses:
                old_base = pulses[p]["base"]
                pulses[p]["base"] = 0.0 + 1j * 0.0
                pulses[p]["lines_re"][0].set_label("ch. " + str(p[0]) + ", gr. " + str(p[1]))
                handles_out.append(pulses[p]["lines_re"][0])
                if old_base != pulses[p]["base"]:
                    for i in range(len(pulses[p]["x"])):
                        y = pulses[p]["base"] + pulses[p]["y"][i]
                        pulses[p]["lines_re"][i].set_ydata(np.real(y))
                        pulses[p]["lines_im"][i].set_ydata(np.imag(y))
                        pulses[p]["fills_re"][i]._paths[0].vertices[:, 1] += np.real(
                            pulses[p]["base"] - old_base
                        )
                        pulses[p]["fills_im"][i]._paths[0].vertices[:, 1] += np.imag(
                            pulses[p]["base"] - old_base
                        )

        elif plot_chgr == 1:
            # check if there are 2 groups
            two_groups = 0
            if len(pulses) > 0:
                temp_group = next(iter(pulses))[1]
                for p in pulses:
                    if p[1] != temp_group:
                        two_groups = 1
                        break

                next_base_out = (2 + 2 * two_groups) * (-1 - 1j)
                if two_groups:
                    y_out_tick_pos = [0, -2]
                    y_out_tick_labels = ["gr. 0", "gr. 1"]
                else:
                    y_out_tick_pos = [0]
                    y_out_tick_labels = ["gr. " + str(temp_group)]
                for p in pulses:
                    old_base = pulses[p]["base"]
                    pulses[p]["base"] = two_groups * p[1] * (-2 - 2j)
                    pulses[p]["lines_re"][0].set_label("ch. " + str(p[0]))
                    handles_out.append(pulses[p]["lines_re"][0])
                    if old_base != pulses[p]["base"]:
                        for i in range(len(pulses[p]["x"])):
                            y = pulses[p]["base"] + pulses[p]["y"][i]
                            pulses[p]["lines_re"][i].set_ydata(np.real(y))
                            pulses[p]["lines_im"][i].set_ydata(np.imag(y))
                            pulses[p]["fills_re"][i]._paths[0].vertices[:, 1] += np.real(
                                pulses[p]["base"] - old_base
                            )
                            pulses[p]["fills_im"][i]._paths[0].vertices[:, 1] += np.imag(
                                pulses[p]["base"] - old_base
                            )
            else:
                next_base_out = -(2 + 2j)

        elif plot_chgr == 2:
            if len(pulses) > 0:
                temp_ch = next(iter(pulses))[0]
                y_out_tick_pos.append(0)
                y_out_tick_labels.append("ch. " + str(temp_ch))

                next_base_out = 0.0 + 1j * 0.0
                for p in pulses:
                    old_base = pulses[p]["base"]
                    if temp_ch == p[0]:
                        pulses[p]["base"] = next_base_out
                    else:
                        next_base_out -= 2 + 2j
                        temp_ch = p[0]
                        pulses[p]["base"] = next_base_out
                        y_out_tick_pos.append(np.real(next_base_out))
                        y_out_tick_labels.append("ch. " + str(temp_ch))
                    pulses[p]["lines_re"][0].set_label("gr. " + str(p[1]))
                    handles_out.append(pulses[p]["lines_re"][0])
                    if old_base != pulses[p]["base"]:
                        for i in range(len(pulses[p]["x"])):
                            y = pulses[p]["base"] + pulses[p]["y"][i]
                            pulses[p]["lines_re"][i].set_ydata(np.real(y))
                            pulses[p]["lines_im"][i].set_ydata(np.imag(y))
                            pulses[p]["fills_re"][i]._paths[0].vertices[:, 1] += np.real(
                                pulses[p]["base"] - old_base
                            )
                            pulses[p]["fills_im"][i]._paths[0].vertices[:, 1] += np.imag(
                                pulses[p]["base"] - old_base
                            )
                next_base_out -= 2 + 2j
            else:
                next_base_out = -(2 + 2j)

        elif plot_chgr == 3:
            next_base_out = 0.0 + 1j * 0.0
            for p in pulses:
                old_base = pulses[p]["base"]
                pulses[p]["base"] = next_base_out
                y_out_tick_pos.append(np.real(next_base_out))
                y_out_tick_labels.append("ch. " + str(p[0]) + "\n gr. " + str(p[1]))
                next_base_out -= 2 + 2j
                if old_base != pulses[p]["base"]:
                    for i in range(len(pulses[p]["x"])):
                        y = pulses[p]["base"] + pulses[p]["y"][i]
                        pulses[p]["lines_re"][i].set_ydata(np.real(y))
                        pulses[p]["lines_im"][i].set_ydata(np.imag(y))
                        pulses[p]["fills_re"][i]._paths[0].vertices[:, 1] += np.real(
                            pulses[p]["base"] - old_base
                        )
                        pulses[p]["fills_im"][i]._paths[0].vertices[:, 1] += np.imag(
                            pulses[p]["base"] - old_base
                        )

        else:
            raise NotImplementedError

        ax_out.artists[0].remove()
        first_legend = ax_out.legend(handles=handles_out, loc="lower right")
        ax_out.add_artist(first_legend)
        ax_out.legend(handles=handles_out_reim, loc="upper right")
        ax_out.set_ylim(np.real(next_base_out) + 0.5, 1.5)
        ax_out.set_yticks(y_out_tick_pos, y_out_tick_labels, rotation="vertical")
        fig.canvas.draw()

    def func_scale_freq(label):
        # print("----------------------------")
        hzdict_scale = {"templ": 0, "scale": 1, "norm": 2}
        hzdict_freq = {"IF on": True, "IF off": False}
        plot_scale = hzdict_scale[fig._radio_scale.value_selected]  # type:ignore
        plot_freq = hzdict_freq[fig._radio_freq.value_selected]  # type:ignore
        if plot_scale == 0:
            for key in pulses:
                pulses[key]["y"] = [
                    np.real(a) * np.real(b) + 1j * np.imag(a) * np.imag(b) if plot_freq else a
                    for a, b in zip(pulses[key]["y_temp"], pulses[key]["freqs"])
                ]
            for key in matches:
                if any([any(x != y) for x, y in zip(matches[key]["y"], matches[key]["y_temp"])]):
                    matches[key]["y"] = matches[key]["y_temp"]
            update_plot_matches()
        elif plot_scale == 1:
            for key in pulses:
                pulses[key]["y"] = [
                    (np.real(a) * np.real(b) + 1j * np.imag(a) * np.imag(b)) * c
                    if plot_freq
                    else a * c
                    for a, b, c in zip(
                        pulses[key]["y_temp"], pulses[key]["freqs"], pulses[key]["scales"]
                    )
                ]
        elif plot_scale == 2:
            for key in pulses:
                max_real = [
                    max(np.abs(np.real(a))) if max(np.abs(np.real(a))) != 0 else 1
                    for a in pulses[key]["y_temp"]
                ]
                max_imag = [
                    max(np.abs(np.imag(a))) if max(np.abs(np.imag(a))) != 0 else 1
                    for a in pulses[key]["y_temp"]
                ]
                pulses[key]["y"] = [
                    np.real(a) * np.real(b) / c + 1j * np.imag(a) * np.imag(b) / d
                    if plot_freq
                    else np.real(a) / c + 1j * np.imag(a) / d
                    for a, b, c, d in zip(
                        pulses[key]["y_temp"], pulses[key]["freqs"], max_real, max_imag
                    )
                ]
            for key in matches:
                if any(
                    [
                        max(np.abs(np.real(x))) < 1 or max(np.abs(np.imag(x))) < 1
                        for x in matches[key]["y"]
                    ]
                ):
                    max_real = [
                        max(np.abs(np.real(a))) if max(np.abs(np.real(a))) != 0 else 1
                        for a in matches[key]["y_temp"]
                    ]
                    max_imag = [
                        max(np.abs(np.imag(a))) if max(np.abs(np.imag(a))) != 0 else 1
                        for a in matches[key]["y_temp"]
                    ]
                    matches[key]["y"] = [
                        np.real(a) / c + 1j * np.imag(a) / d
                        for a, c, d in zip(matches[key]["y_temp"], max_real, max_imag)
                    ]
            update_plot_matches()
        update_plot_pulses()

    def update_plot_pulses():
        for key in pulses:
            base = pulses[key]["base"]
            color = pulses[key]["color"]
            color_im = pulses[key]["color_im"]
            for i in range(len(pulses[key]["y_temp"])):
                y = pulses[key]["base"] + pulses[key]["y"][i]
                pulses[key]["lines_re"][i].set_ydata(np.real(y))
                pulses[key]["lines_im"][i].set_ydata(np.imag(y))
                alpha = pulses[key]["alpha"][i]
                x = pulses[key]["x"][i]
                re_fill = ax_out.fill_between(
                    x,
                    np.real(y),
                    np.real(base),
                    color=color,
                    alpha=alpha,
                    hatch="----",
                )
                im_fill = ax_out.fill_between(
                    x,
                    np.imag(y),
                    np.imag(base),
                    color=color_im,
                    alpha=alpha,
                    hatch="||||",
                )
                pulses[key]["fills_re"][i].get_paths()[0].vertices = re_fill.get_paths()[
                    0
                ].vertices
                pulses[key]["fills_im"][i].get_paths()[0].vertices = im_fill.get_paths()[
                    0
                ].vertices
                re_fill.remove()
                im_fill.remove()
        fig.canvas.draw()

    def update_plot_matches():
        for key in matches:
            base = matches[key]["base"]
            color = matches[key]["color"]
            color_im = matches[key]["color_im"]
            alpha = matches[key]["alpha"]
            for i in range(len(matches[key]["y_temp"])):
                y = matches[key]["base"] + matches[key]["y"][i]
                matches[key]["lines_re"][i].set_ydata(np.real(y))
                matches[key]["lines_im"][i].set_ydata(np.imag(y))
                x = matches[key]["x"][i]
                re_fill = ax_match.fill_between(
                    x,
                    np.real(y),
                    np.real(base),
                    color=color,
                    alpha=alpha,
                    hatch="----",
                )
                im_fill = ax_match.fill_between(
                    x,
                    np.imag(y),
                    np.imag(base),
                    color=color_im,
                    alpha=alpha,
                    hatch="||||",
                )
                matches[key]["fills_re"][i].get_paths()[0].vertices = re_fill.get_paths()[
                    0
                ].vertices
                matches[key]["fills_im"][i].get_paths()[0].vertices = im_fill.get_paths()[
                    0
                ].vertices
                re_fill.remove()
                im_fill.remove()
        fig.canvas.draw()

    def update_x_lim(val):
        ax_out.set_xlim(val)
        fig.canvas.draw()

    def update_itearion(val):
        for i in range(len(fig._slider_repeat_count_list)):  # pyright: ignore[reportAttributeAccessIssue]
            iteration_list[i] = fig._slider_repeat_count_list[i].val - 1  # pyright: ignore[reportAttributeAccessIssue]

        _apply_scales(pulses, scales, iteration_list, repeat_count, period * x_plot_unit)
        _apply_freqs(pulses, freqs, iteration_list, repeat_count, period * x_plot_unit, fs_dac)
        hzdict_scale = {"templ": 0, "scale": 1, "norm": 2}
        hzdict_freq = {"IF on": True, "IF off": False}
        plot_scale = hzdict_scale[fig._radio_scale.value_selected]  # type:ignore
        plot_freq = hzdict_freq[fig._radio_freq.value_selected]  # type:ignore
        if plot_scale == 1 or plot_freq:
            func_scale_freq("")

    ax_reim = fig.add_subplot(gs[0:2, 5])
    radio_reim = RadioButtons(ax_reim, ("re", "re+im"))
    radio_reim.on_clicked(func_reim)
    fig._radio_reim = radio_reim  # type:ignore

    ax_chgr = fig.add_subplot(gs[2:6, 5])
    radio_chgr = RadioButtons(ax_chgr, ("ch+ gr+", "ch+ gr-", "ch- gr+", "ch- gr-"))
    radio_chgr.on_clicked(func_chgr)
    fig._radio_chgr = radio_chgr  # type:ignore

    ax_scale = fig.add_subplot(gs[6:8, 5])
    radio_scale = RadioButtons(ax_scale, ("templ", "scale", "norm"))
    radio_scale.on_clicked(func_scale_freq)
    fig._radio_scale = radio_scale  # type:ignore

    ax_freq = fig.add_subplot(gs[8:10, 5])
    radio_freq = RadioButtons(ax_freq, ("IF on", "IF off"), active=1)
    radio_freq.on_clicked(func_scale_freq)
    fig._radio_freq = radio_freq  # type:ignore

    slider = RangeSlider(
        ax_slider, "x limits [ns]", -50, period * x_plot_unit, valinit=x_lim_slider
    )
    ax_slider.texts[0].set_position((0.02, 0.05))
    ax_slider.texts[0].set_verticalalignment("top")
    ax_slider.texts[0].set_horizontalalignment("left")
    ax_slider.texts[1].set_position((0.98, 0.05))
    ax_slider.texts[1].set_verticalalignment("top")
    ax_slider.texts[1].set_horizontalalignment("right")
    slider.on_changed(update_x_lim)

    slider_repeat_count_list = []
    for i in range(len(ax_repeat_count)):
        if isinstance(repeat_count, int):
            slider_repeat_count = Slider(
                ax_repeat_count[i],
                "axis " + str(i) + " [1," + str(repeat_count) + "]",
                1,
                repeat_count,
                valinit=1,
                valstep=1,
            )
        else:
            slider_repeat_count = Slider(
                ax_repeat_count[i],
                "axis " + str(i) + " [1," + str(repeat_count[i]) + "]",
                1,
                repeat_count[i],
                valinit=1,
                valstep=1,
            )
        ax_repeat_count[i].texts[0].set_position((0.02, 0.05))
        ax_repeat_count[i].texts[0].set_verticalalignment("top")
        ax_repeat_count[i].texts[0].set_horizontalalignment("left")
        ax_repeat_count[i].texts[1].set_position((0.98, 0.05))
        ax_repeat_count[i].texts[1].set_verticalalignment("top")
        ax_repeat_count[i].texts[1].set_horizontalalignment("right")

        slider_repeat_count.on_changed(update_itearion)
        slider_repeat_count_list.append(slider_repeat_count)

    fig._slider_repeat_count_list = slider_repeat_count_list  # type:ignore
    plt.show()
    return fig  # type:ignore


def _apply_scales(
    pulses: dict,
    scales: dict,
    iteration_list: List[int],
    repeat_count: Union[int, tuple],
    period: Union[int, float],
):
    # depending on the iteration number update the list of arrays pulses[key]["scales"]
    if isinstance(repeat_count, int):
        iteration = iteration_list[0]
    else:
        iteration = iteration_list[-1]
        for i in range(len(iteration_list) - 1):
            iteration += iteration_list[i] * np.prod(repeat_count[i + 1 :])
    for key in pulses:
        pulses[key]["scales"] = []
        for i in range(len(pulses[key]["x"])):
            # find in scales the scale in (one before or equal to the start, end)
            mask_less_end = scales[key]["start"] < pulses[key]["x"][i][-1] + iteration * period
            mask_less_start = scales[key]["start"] <= pulses[key]["x"][i][0] + iteration * period
            mask = mask_less_end != mask_less_start
            inds = np.unique(
                np.concatenate(([max(np.nonzero(mask_less_start)[0])], np.nonzero(mask)[0]))
            )
            # fix first scale
            ind = inds[0]
            scale_arr = np.ones_like(pulses[key]["x"][i]) * scales[key]["scale"][ind]
            for ind in inds[1:]:  # this is inside pulse time
                start_ind = np.where(
                    pulses[key]["x"][i] + iteration * period == scales[key]["start"][ind]
                )[0][0]
                scale_arr[start_ind:] = (
                    np.ones_like(scale_arr[start_ind:]) * scales[key]["scale"][ind]
                )
            pulses[key]["scales"].append(scale_arr)


def _apply_freqs(
    pulses: dict,
    freqs: dict,
    iteration_list: List[int],
    repeat_count: Union[int, tuple],
    period: Union[int, float],
    fs_dac: float,
):
    # depending on the iteration number update the list of arrays pulses[key]["freqs"]
    if isinstance(repeat_count, int):
        iteration = iteration_list[0]
    else:
        iteration = iteration_list[-1]
        for i in range(len(iteration_list) - 1):
            iteration += iteration_list[i] * np.prod(repeat_count[i + 1 :])
    for key in pulses:
        pulses[key]["freqs"] = []
        for i in range(len(pulses[key]["x"])):
            if pulses[key]["envelope"][i]:
                # find in freqs the freq in (one before or equal to the start, end)
                mask_less_end = freqs[key]["start"] < pulses[key]["x"][i][-1] + iteration * period
                mask_less_start = (
                    freqs[key]["start"] <= pulses[key]["x"][i][0] + iteration * period
                )
                mask = mask_less_end != mask_less_start
                inds = np.unique(
                    np.concatenate(([max(np.nonzero(mask_less_start)[0])], np.nonzero(mask)[0]))
                )

                # fix first frequency
                ind = inds[0]
                freq = freqs[key]["freq"][ind]
                ph_i = freqs[key]["ph_i"][ind]
                ph_q = freqs[key]["ph_q"][ind]
                t = (pulses[key]["x"][i] + iteration * period - freqs[key]["start"][ind]) * 1e-9
                freq_arr_i = np.cos(2 * np.pi * freq * t + ph_i)
                freq_arr_q = np.cos(2 * np.pi * freq * t + ph_q)
                for ind in inds[1:]:  # this is inside pulse time
                    freq = freqs[key]["freq"][ind]
                    ph_i = freqs[key]["ph_i"][ind]
                    ph_q = freqs[key]["ph_q"][ind]
                    start_ind = np.where(
                        pulses[key]["x"][i] + iteration * period == freqs[key]["start"][ind]
                    )[0][0]
                    t = (
                        pulses[key]["x"][i][start_ind:]
                        + iteration * period
                        - freqs[key]["start"][ind]
                    ) * 1e-9
                    freq_arr_i[start_ind:] = np.cos(2 * np.pi * freq * t + ph_i)
                    freq_arr_q[start_ind:] = np.cos(2 * np.pi * freq * t + ph_q)
                pulses[key]["freqs"].append(freq_arr_i + 1j * freq_arr_q)
            else:
                pulses[key]["freqs"].append(
                    np.ones_like(pulses[key]["x"][i]) + 1j * np.ones_like(pulses[key]["x"][i])
                )
