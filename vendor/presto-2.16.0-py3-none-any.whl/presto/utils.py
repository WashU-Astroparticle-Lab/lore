# -*- coding: utf-8 -*-
# Copyright © 2018-2024 Intermodulation Products AB. All Rights Reserved.
"""Collection of functions that might be useful, or might not."""

from __future__ import annotations

import itertools
from datetime import datetime, timedelta
import os
import shutil
import sys
import threading
import time
from typing import List, Literal, Optional, Tuple, TypeVar, Union, overload

import numpy as np
import numpy.typing as npt


def plot_sequence(
    pls,
    period: Optional[float] = None,
    repeat_count: Union[int, tuple] = 1,
    num_averages: int = 1,
):
    """Plots pulse sequence for interactive inspection.

    See :ref:`docs-plot-sequence` for more documentation.

    Args:
        pls (pulsed.Pulsed): Pulsed object that contains the pulse sequence to be plotted.
        period: Measurement time in seconds for one repetition. Must be a multiple of :meth:`get_clk_T`
        repeat_count (int or tuple of ints): Number of times to repeat the experiment and stack
            the acquired data (no averaging). For multi-dimensional parameter sweeps,
            ``repeat_count`` is a tuple where each element specifies the number of repetitions
            along that axis.
        num_averages: Number of times to repeat the whole sequence (including the repetitions
            due to ``repeat_count``) and average the acquired data.

    Returns:
        matplotlib.figure.Figure: The matplotlib Figure instance.

    Examples:

        >>> from presto import pulsed
        >>> from presto.utils import plot_sequence, sin2
        >>>
        >>> with pulsed.Pulsed(dry_run=True) as pls:
        >>>     # define the pulse and set parameters
        >>>     pulse = pls.setup_template(1, 0, 0.5 * sin2(100))
        >>>     pls.setup_scale_lut(1, 0, 0.707)
        >>>     pls.set_store_ports(1)
        >>>     pls.set_store_duration(100e-9)
        >>>
        >>>     # define the pulse sequence
        >>>     pls.store(0.0)
        >>>     pls.output_pulse(26e-9, pulse)
        >>>
        >>>     # plot the pulse sequence
        >>>     plot_sequence(pls)

    Raises:
        ImportError: if ``matplotlib`` is not installed.
    """
    from . import _sequence_plot

    _sequence_plot.plot_sequence(pls, period, repeat_count, num_averages)


def _ssh_connect(address: str, **kwargs):
    """Connect to the hardware using SSH.

    Args:
        address: IP address or hostname of the hardware.
        kwargs: Extra arguments are passed directly to :meth:`paramiko.client.SSHClient.connect`.

    Returns:
        paramiko.client.SSHClient: Handle to the connection.

    Note:
        Requires Python package `paramiko <https://www.paramiko.org/>`_ to be installed.

    Raises:
        ImportError: Python module ``paramiko`` not found.
    """
    import paramiko

    def derive_shorthand(host_string):
        # https://github.com/fabric/fabric/blob/58db222d403577b352b1d02d4edc5e4f8e8109a0/fabric/connection.py#L26-L46
        user_hostport = host_string.rsplit("@", 1)
        hostport = user_hostport.pop()
        user = user_hostport[0] if user_hostport and user_hostport[0] else None

        # IPv6: can't reliably tell where addr ends and port begins, so don't
        # try (and don't bother adding special syntax either, user should avoid
        # this situation by using port=).
        if hostport.count(":") > 1:
            host = hostport
            port = None
        # IPv4: can split on ':' reliably.
        else:
            host_port = hostport.rsplit(":", 1)
            host = host_port.pop(0) or None
            port = host_port[0] if host_port and host_port[0] else None

        if port is not None:
            port = int(port)

        return {"user": user, "host": host, "port": port}

    shorthand = derive_shorthand(address)
    username = shorthand["user"] if shorthand["user"] is not None else "alice"
    port = shorthand["port"] if shorthand["port"] is not None else 22
    hostname = shorthand["host"]

    client = paramiko.SSHClient()
    key_filename = os.path.join(os.path.dirname(__file__), "id_rsa_alice")
    pkey = paramiko.RSAKey.from_private_key_file(key_filename)
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy)

    arguments = {
        "hostname": hostname,
        "username": username,
        "port": port,
        "pkey": pkey,
        "look_for_keys": False,
        "allow_agent": False,
    }
    arguments.update(kwargs)
    client.connect(**arguments)

    return client


def ssh_execute(address: str, command: str):
    """Execute a command on the hardware.

    Args:
        address: IP address or hostname of the hardware.
        command: Bash command to be executed

    Note:
        Requires Python package `paramiko <https://www.paramiko.org/>`_ to be installed.

    Raises:
        ImportError: Python module ``paramiko`` not found.

    :meta private:
    """
    with _ssh_connect(address) as ssh:
        (_stdin, stdout, stderr) = ssh.exec_command(command)
        out = stdout.readlines()
        err = stderr.readlines()
    for line in out:
        print(line, end="", flush=True, file=sys.stdout)
    for line in err:
        print(line, end="", flush=True, file=sys.stderr)


def ssh_reboot(address: str):
    """Reboot the Linux system on the hardware.

    Establish an SSH connection to ``address`` and perform a full reboot the system, roughly
    equivalent to the command ``systemctl reboot``. The system should be back online after about
    one minute.

    To instead restart only the service running on the system, see :func:`ssh_restart`.

    Args:
        address: IP address or hostname of the hardware

    Note:
        Requires Python package `paramiko <https://www.paramiko.org/>`_ to be installed.

    Raises:
        ImportError: Python module ``paramiko`` not found.
    """
    # put `&` in the end to avoid getting the exception
    # `UnexpectedExit: Encountered a bad command exit code!`
    return ssh_execute(address, "sudo /bin/systemctl reboot || sudo /sbin/shutdown -r now &")


def ssh_restart(address: str):
    """Restart the service running on the hardware.

    Establish an SSH connection to ``address`` and perform a soft restart of the service, roughly
    equivalent to ``systemctl restart <service-name>``. The service should be back online
    immediately.

    To instead perform a full reboot of the Linux system, see :func:`ssh_reboot`.

    Args:
        address: IP address or hostname of the hardware

    Note:
        Requires Python package `paramiko <https://www.paramiko.org/>`_ to be installed.

    Raises:
        ImportError: Python module ``paramiko`` not found.
    """
    # put `&` in the end to avoid getting the exception
    # `UnexpectedExit: Encountered a bad command exit code!`
    return ssh_execute(address, "sudo /bin/systemctl restart conductord.service")


def ssh_upload(address: str, local_filename: str, remote_filename: Optional[str] = None):
    """Copy a file from the local computer to the hardware.

    Args:
        address: IP address or hostname of the hardware.
        local_filename: path to the local file
        remote_filename: path to the remote location, default to ``~/``

    Note:
        Requires Python package `paramiko <https://www.paramiko.org/>`_ to be installed.

    Raises:
        ImportError: Python module ``paramiko`` not found.

    :meta private:
    """
    if remote_filename is None:
        remote_filename = "~/"
    with _ssh_connect(address) as ssh:
        with ssh.open_sftp() as sftp:
            sftp.put(local_filename, remote_filename)


def ssh_download(address: str, remote_filename: str, local_filename: Optional[str] = None):
    """Copy a file from the hardware to the local computer.

    Args:
        address: IP address or hostname of the hardware.
        remote_filename: path to the remote file
        local_filename: path to the local location, default to ``./``

    Note:
        Requires Python package `paramiko <https://www.paramiko.org/>`_ to be installed.

    Raises:
        ImportError: Python module ``paramiko`` not found.

    :meta private:
    """
    if local_filename is None:
        local_filename = "./"
    with _ssh_connect(address) as ssh:
        with ssh.open_sftp() as sftp:
            sftp.get(remote_filename, local_filename)


def format_sec(s: Union[float, timedelta]) -> str:
    """Format a time interval in seconds into a more human-readable string.

    Args:
        s: time interval in seconds.

    Returns:
        time interval in the form "Xh Ym Z.zs".

    Examples:
        >>> format_sec(np.pi * 1e+8)
        '9y 348d 20h 27m 45.4s'
        >>> format_sec(np.exp(-10))
        '45.4us'
    """
    if isinstance(s, timedelta):
        s = s.total_seconds()

    if s < 0.0:
        sign = "-"
        s = -s
    else:
        sign = ""

    if s < 1e-24:
        ret = "{:.1e}".format(s)

    elif s < 1.0:
        if s < 1e-21:
            scale = 1e24
            unit = "ys"
        elif s < 1e-18:
            scale = 1e21
            unit = "zs"
        elif s < 1e-15:
            scale = 1e18
            unit = "as"
        elif s < 1e-12:
            scale = 1e15
            unit = "fs"
        elif s < 1e-9:
            scale = 1e12
            unit = "ps"
        elif s < 1e-6:
            scale = 1e9
            unit = "ns"
        elif s < 1e-3:
            scale = 1e6
            unit = "us"
        else:
            scale = 1e3
            unit = "ms"
        ret = "{:.1f}{:s}".format(s * scale, unit)

    else:
        y = int(s // 31_557_600)
        s -= y * 31_557_600.0

        d = int(s // 86_400)
        s -= d * 86_400.0

        h = int(s // 3_600)
        s -= h * 3_600.0

        m = int(s // 60)
        s -= m * 60.0

        if y:
            ret = "{:d}y {:d}d {:d}h {:d}m {:.1f}s".format(y, d, h, m, s)
        elif d:
            ret = "{:d}d {:d}h {:d}m {:.1f}s".format(d, h, m, s)
        elif h:
            ret = "{:d}h {:d}m {:.1f}s".format(h, m, s)
        elif m:
            ret = "{:d}m {:.1f}s".format(m, s)
        else:
            ret = "{:.1f}s".format(s)

    return sign + ret


def format_precision(n: float, s: float) -> str:
    """Format a value and uncertainty to the correct number of significant digits.

    Args:
        n: nominal value.
        s: uncertainty.

    Returns:
        a formatted string with numbers rounded to significant digits.

    Examples:
        >>> format_precision(36.91226461435421, 0.4060358649863922)
        '36.9 ± 0.4'
    """
    digits = -int(np.floor(np.log10(s)))
    n = round(n, digits)
    s = round(s, digits)
    return f"{n} ± {s}"


def si_prefix_scale(data) -> Tuple[str, float]:
    """Calculare the appropriate SI prefix for ``data``.

    Args:
        data: an integer, a float, a list or array of those, ...

    Returns:
        a tuple (prefix, scale)

    Examples:
        >>> si_prefix_scale(3.1415e-5)
        ('μ', 1000000)

        >>> value = 2.718e-7
        >>> (unit, scale) = si_prefix_scale(value)
        >>> print(f"The length is {scale * value} {unit}m")
        The length is 271.8 nm
    """
    data_max = np.nanmax(np.abs(data))
    unit = ""
    mult = 1.0

    si_exp_pre = [
        (-30, "q"),
        (-27, "r"),
        (-24, "y"),
        (-21, "z"),
        (-18, "a"),
        (-15, "f"),
        (-12, "p"),
        (-9, "n"),
        (-6, "μ"),
        (-3, "m"),
        (0, ""),
        (3, "k"),
        (6, "M"),
        (9, "G"),
        (12, "T"),
        (15, "P"),
        (18, "E"),
        (21, "Z"),
        (24, "Y"),
        (27, "R"),
        (30, "Q"),
    ]

    for exp, pre in reversed(si_exp_pre):
        if data_max >= 10**exp:
            unit = pre
            mult = 10 ** (-exp)
            break

    return unit, mult


def eprint(*objects):
    print(*objects, file=sys.stderr)


def _colored(aec: str, msg: str) -> str:
    return "{}{}{}".format(aec, msg, _AEC_RESET)


def eprint_error(title: str, body: str, warn: bool = False, inline: bool = False):
    aec = _AEC_YELLOW if warn else _AEC_RED
    if not title:
        eprint(_colored(aec, body))
    else:
        if inline:
            wide = f"{title}:"
            eprint("{} {}".format(_colored(aec, wide), body))
        else:
            wide = f" {title} "
            eprint(_colored(aec, f"{wide:-^80}"))
            eprint(body)
            eprint(_colored(aec, f"{'':-^80}"))


def get_sourcecode(script_filename: str) -> List[str]:
    """Open a file and return its content.

    Args:
        script_filename: path to the file.

    Returns:
        the lines of the file at ``script_filename``.
    """
    with open(script_filename, mode="rt", encoding="utf-8") as f:
        sourcecode = f.readlines()
    return sourcecode


def untwist_downconversion(
    I_port: np.ndarray, Q_port: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """Convert a measured IQ pair into a low/high sideband pair.

    Args:
        I_port: ``dtype=complex128``
        Q_port: ``dtype=complex128``

    Returns:
        a tuple (L_sideband, H_sideband) of NumPy arrays with ``dtype=complex128``.
    """
    L_sideband = np.zeros_like(I_port)
    H_sideband = np.zeros_like(Q_port)

    L_sideband.real += I_port.real + Q_port.imag
    L_sideband.imag += Q_port.real - I_port.imag
    H_sideband.real += I_port.real - Q_port.imag
    H_sideband.imag += Q_port.real + I_port.imag

    return L_sideband, H_sideband


def sin2(nr_samples: int, drag: float = 0.0) -> np.ndarray:
    r"""Create a :math:`\sin^2` envelope/template.

    Args:
        nr_samples
        drag: if nonzero, use DRAG with :math:`\lambda / \alpha` equal to ``drag``

    Returns:
        NumPy array for desired pulse with ``dtype=float64`` if ``drag=0.0``,
        or ``dtype=complex128`` otherwise.
    """
    x = np.linspace(0.0, 1.0, nr_samples, endpoint=False)
    if drag == 0.0:
        return np.sin(np.pi * x) ** 2
    else:
        ret = np.zeros_like(x, np.complex128)
        ret.real = np.sin(np.pi * x) ** 2
        # NOTE: assume 1 GS/s sampling rate
        ret.imag = drag * np.pi * np.sin(2 * np.pi * x) / (nr_samples * 1e-9)
        return ret


def sinP(P: float, nr_samples: int) -> np.ndarray:
    r"""Create a :math:`\sin^P` envelope/template.

    Args:
        P
        nr_samples

    Returns:
        NumPy array for desired pulse with ``dtype=float64``.
    """
    x = np.linspace(0.0, 1.0, nr_samples, endpoint=False)
    return np.sin(np.pi * x) ** P


def triangle(nr_samples: int) -> np.ndarray:
    """Create a triangular envelope/template.

    Args:
        nr_samples

    Returns:
        NumPy array for desired pulse with ``dtype=float64``.
    """
    t1 = np.linspace(0.0, 1.0, nr_samples // 2, endpoint=False)
    t2 = np.linspace(1.0, 0.0, nr_samples // 2, endpoint=False)
    return np.concatenate((t1, t2))


def _flatten(li):
    return sum(
        ([x] if not isinstance(x, (list, tuple, np.ndarray)) else _flatten(x) for x in li), []
    )  # type: ignore


def as_flat_list(x: object) -> list:
    """Return ``x`` as a flat unidimensional list.

    Args:
        x: An arbitrarily nested list, tuple, np.ndarray, or a mixture thereof.

    Returns:
        A flat, unidimensional list with all the objects of ``x``.
    """
    li = [x]
    return _flatten(li)


@overload
def rotate_opt(data: npt.NDArray[np.complex128]) -> npt.NDArray[np.complex128]: ...


@overload
def rotate_opt(
    data: npt.NDArray[np.complex128], return_x: Literal[False]
) -> npt.NDArray[np.complex128]: ...


@overload
def rotate_opt(
    data: npt.NDArray[np.complex128], return_x: Literal[True]
) -> Tuple[npt.NDArray[np.complex128], float]: ...


@overload
def rotate_opt(
    data: npt.NDArray[np.complex128], return_x: bool
) -> Union[npt.NDArray[np.complex128], Tuple[np.ndarray, float]]: ...


def rotate_opt(
    data: npt.NDArray[np.complex128], return_x: bool = False
) -> Union[npt.NDArray[np.complex128], Tuple[np.ndarray, float]]:
    """Rotates ``data`` so that all the signal is in the I quadrature (real part).

    Args:
        data: ``dtype`` should be ``complex128``.
        return_x: if :obj:`True`, return also the angle by which ``data`` was rotated.

    Returns:
        ``data * np.exp(1j * x)``, with ``x`` such that ``np.std(ret.imag)`` is minimum.
        ``dtype=complex128``.

        If ``return_x=True``, also return the angle ``x``.
    """
    # calculate the variance in steps of 1 deg
    N = 360
    _var = np.zeros(N)
    for ii in range(N):
        _data = data * np.exp(1j * 2 * np.pi / N * ii)
        _var[ii] = np.var(_data.imag)

    # the variance goes like cos(x)**2
    # FFT and find the phase at frequency "2"
    fft = np.fft.rfft(_var) / N
    # first solution
    x_fft1 = -np.angle(fft[2])  # compensate for measured phase
    x_fft1 -= np.pi  # we want to be at the minimum of cos(2x)
    x_fft1 /= 2  # move from frequency "2" to "1"
    # there's a second solution np.pi away (a minus sign)
    x_fft2 = x_fft1 + np.pi

    # convert to +/- interval
    x_fft1 = to_pm_pi(x_fft1)
    x_fft2 = to_pm_pi(x_fft2)
    # choose the closest to zero
    if np.abs(x_fft1) < np.abs(x_fft2):
        x_fft = x_fft1
    else:
        x_fft = x_fft2

    # rotate the data and return a copy
    data = data * np.exp(1j * x_fft)
    if return_x:
        return data, x_fft
    else:
        return data


def to_pm_pi(phase: float) -> float:
    """Converts a phase in radians into the [-π, +π) interval.

    Args:
        phase
    """
    return (phase + np.pi) % (2 * np.pi) - np.pi


def newman_phases(n: int) -> npt.NDArray[np.floating]:
    r"""Calculate phases for a frequency comb with low crest factor.

    Args:
        n: the number of tones/components in the frequency comb

    Returns:
        an array of phases in radians with length ``n``

    Notes:

        The individual tones/components of the comb are assumed to be equally spaced in frequency.

        The returned phases are computed using the method by [Newman1965]_ as reported by
        [Boyd1986]_: :math:`\phi_k = \pi k^2 / n` for :math:`k = 0, ..., n-1`.

    See also:
        :func:`newman_scale`

    References:

        .. [Newman1965] -- D. J. Newman, *"An L1 extremal problem for polynomials"*,
            Proceedings of the American Mathematical Society **16**\ (6), 1287-1290 (1965).
        .. [Boyd1986] -- S. Boyd, *"Multitone signals with low crest factor"*,
            IEEE Transactions on Circuits and Systems **33**\ (10), 1018-1022 (1986).

    Examples:

        Set up a frequency comb with 100 tones starting at 100 MHz and separated by 10 kHz, using
        Newman phases and maximum (full-scale) amplitude.

        Using :mod:`.lockin` mode:

        >>> import numpy as np
        >>>
        >>> from presto.lockin import Lockin
        >>> from presto.utils import newman_phases, newman_scale
        >>>
        >>> N = 100  # number of tones in frequency comb
        >>> AMP = 1.0  # full-scale amplitude
        >>> OFFSET = 100e6  # starting frequency of comb
        >>> DELTA = 10e3  # frequency separation inside comb
        >>> OUT_PORT = 1
        >>>
        >>> with Lockin() as lck:
        >>>     freqs = OFFSET + DELTA * np.arange(N)
        >>>     amps = np.full(N, AMP / newman_scale(N))
        >>>     phases = newman_phases(N)
        >>>
        >>>     lck.set_df(DELTA)
        >>>     og = lck.add_output_group(OUT_PORT, N)
        >>>     og.set_frequencies(freqs).set_phases(phases).set_amplitudes(amps)
        >>>     lck.apply_settings()

        Using :mod:`.spectral` mode:

        >>> import numpy as np
        >>>
        >>> from presto.spectral import Spectral
        >>> from presto.utils import newman_phases, newman_scale
        >>>
        >>> N = 100  # number of tones in frequency comb
        >>> AMP = 1.0  # full-scale amplitude
        >>> OFFSET = 100e6  # starting frequency of comb
        >>> DELTA = 10e3  # frequency separation inside comb
        >>> OUT_PORT = 1
        >>>
        >>> with Spectral() as spec:
        >>>     freqs = OFFSET + DELTA * np.arange(N)
        >>>     amps = np.full(N, AMP / newman_scale(N))
        >>>     phases = newman_phases(N)
        >>>
        >>>     period = 1.0 / DELTA
        >>>     spec.output_multicos(OUT_PORT, period, freqs, amps, phases)
        >>>     # ... measure here ...
    """
    k = np.arange(n)
    return np.pi * k**2 / n


def newman_scale(n: int) -> np.float64:
    """Global amplitude-scaling factor for a frequency comb using Newman phases.

    Divide the maximum amplitude of the comb by this factor to ensure that the output is not
    clipped due to the crest factor.

    Args:
        n: the number of tones/components in the frequency comb

    See also:
        :func:`newman_phases`
    """
    return np.sqrt(2.0 * n)


_ASARRAY_RET = TypeVar("_ASARRAY_RET", bound=Union[np.integer, np.floating, np.complexfloating])


def asarray(a, dtype: type[_ASARRAY_RET]) -> npt.NDArray[_ASARRAY_RET]:
    return np.ravel(a).astype(dtype, copy=False)


def compatible_dac_configs(freq_MHz: float):
    if freq_MHz < 0 or freq_MHz > 9_600:
        raise ValueError("frequency must be positive and at most 9.6 GHz")

    from .hardware import DacFSample, DacMode, _DacConfig

    dac_rates = [
        # DacFSample.G2,
        # DacFSample.G4,
        DacFSample.G6,
        DacFSample.G8,
        DacFSample.G10,
    ]
    configs: List[_DacConfig] = []
    for dac_fsample in dac_rates:
        # Mixed02
        if dac_fsample.MSps() <= 7_000:
            configs.append(_DacConfig(DacMode.Mixed02, dac_fsample))

        # Mixed04 + Mixed42
        if dac_fsample.MSps() > 7_000:
            configs.append(_DacConfig(DacMode.Mixed04, dac_fsample))
            configs.append(_DacConfig(DacMode.Mixed42, dac_fsample))

    def find_best_config(freq: float, configs: List[_DacConfig]) -> List[Tuple[_DacConfig, float]]:
        def spur_score(low: Optional[float], high: float) -> float:
            if low is None:
                return high - freq
            else:
                # calculate the "parallel" of the distances
                g_high = 1 / (high - freq)
                g_low = 1 / (freq - low)
                g_parallel = g_high + g_low
                return 1 / g_parallel

        all = []
        for config in configs:
            if not config.is_in_range(freq):
                continue
            (low, high) = config.spurs(freq)
            score = spur_score(low, high)
            all.append((config, score))

        all.sort(key=lambda x: x[1], reverse=True)

        return all

    all = find_best_config(freq_MHz, configs)
    return all


def recommended_dac_config(freq: float, *, print_all: bool = False, plot: bool = False):
    """Recommended DAC configuration.

    Args:
        freq: signal frequency in Hz
        print_all: set to ``True`` to print all valid DAC configurations for ``freq``, together
            with frequency of spurious tones and suggested reconstruction filters
        plot: set to ``True`` to show a ``matplotlib`` figure with DAC zones and frequencies of
            signal and spurious tones

    Returns:
        A tuple of ``(dac_mode, dac_fsample)`` where

        * ``dac_mode`` (:class:`.hardware.DacFSample`)
        * ``dac_fsample`` (:class:`.hardware.DacMode`)

        represent the most recommended DAC configuration.

    Raises:
        ValueError: if ``freq`` is negative or above 9.6 GHz.

    Examples:

        Print detailed information:

        >>> recommended_dac_config(5.2e9, print_all=True)
        Valid DAC configurations for signal at 5200.0 MHz:
          * Mixed42-G8 (score 1680):
              - low-frequency spur: 2800.0 MHz
              - high-frequency spur: 10800.0 MHz
              - compatible band-pass filters: ['VBFZ-5500-S+', 'ZBSS-6G-S+', 'ZVBP-5G-S+']
          * Mixed02-G6 (score 1173):
              - low-frequency spur: 800.0 MHz
              - high-frequency spur: 6800.0 MHz
              - compatible band-pass filters: ['ZVBP-5G-S+']

        Use suggested configuration directly:

        >>> dac_mode, dac_fsample = recommended_dac_config(5.2e9)
        >>> print(f"Best DacMode is {dac_mode.name}, DacFSample is {dac_fsample.name}")
        DacMode is Mixed42, DacFSample is G8
        >>> from presto import lockin, pulsed
        >>> lck = lockin.Lockin(dac_mode=dac_mode, dac_fsample=dac_fsample)
        >>> pls = pulsed.Pulsed(dac_mode=dac_mode, dac_fsample=dac_fsample)
    """
    freq_MHz = freq / 1e6
    if freq_MHz < 0 or freq_MHz > 9_600:
        raise ValueError("frequency must be positive and at most 9.6 GHz")

    from .hardware import DacFSample, DacMode, _DacConfig

    dac_rates = [
        # DacFSample.G2,
        # DacFSample.G4,
        DacFSample.G6,
        DacFSample.G8,
        DacFSample.G10,
    ]
    configs: List[_DacConfig] = []
    for dac_fsample in dac_rates:
        # Mixed02
        if dac_fsample.MSps() <= 7_000:
            configs.append(_DacConfig(DacMode.Mixed02, dac_fsample))

        # Mixed04 + Mixed42
        if dac_fsample.MSps() > 7_000:
            configs.append(_DacConfig(DacMode.Mixed04, dac_fsample))
            configs.append(_DacConfig(DacMode.Mixed42, dac_fsample))

    # plot all configs
    if plot:
        import matplotlib.pyplot as plt

        fig1, ax1 = plt.subplots(len(dac_rates), 1, sharex=True, sharey=True, tight_layout=True)

        for ax_, dac_fsample in zip(ax1, dac_rates):
            for f in range(21):
                ax_.axvline(f / 2, color="tab:gray", lw=1, alpha=0.25)
            ax_.set_ylabel(f"{dac_fsample.MSps() // 1_000} GS/s")

        for config in configs:
            ax_ = ax1[dac_rates.index(config.fsample)]
            if config.setup is DacMode.Mixed02:
                color = "tab:blue"
                ymin = 0.7
                ymax = 0.9
            elif config.setup is DacMode.Mixed04:
                color = "tab:orange"
                ymin = 0.4
                ymax = 0.6
            elif config.setup is DacMode.Mixed42:
                color = "tab:green"
                ymin = 0.1
                ymax = 0.3
            else:
                continue

            for x, y in config.recommended_range():
                ax_.axvspan(x / 1e3, y / 1e3, ymin=ymin, ymax=ymax, color=color)

            ax_.set_yticks([])
            ax_.axvline(freq_MHz / 1000, c="k")
            (low, high) = config.spurs(freq_MHz)  # type: ignore
            if low is not None:
                ax_.axvline(low / 1e3, c="r")
            ax_.axvline(high / 1e3, c="r")

        # dummy spans for legend
        ax1[0].axvspan(-1, -1, 0, 0, color="tab:blue", label="Mixed02")
        ax1[0].axvspan(-1, -1, 0, 0, color="tab:orange", label="Mixed04")
        ax1[0].axvspan(-1, -1, 0, 0, color="tab:green", label="Mixed42")
        ax1[0].legend(loc="lower right", title="DacMode", ncol=3)

        ax1[0].set_title("Recommended output-frequency range")
        ax1[-1].set_xlim(-0.5, 10.5)
        ax1[-1].set_xticks(range(0, 11, 1))
        # ax1[-1].set_xticks(range(1, 11, 2), minor=True)
        ax1[-1].set_xlabel("Frequency [GHz]")

        fig1.show()  # type: ignore

    # find best config
    def find_best_filter(freq, config):
        from ._filters_mc import bandpass, lowpass

        ret_lowpass = []
        ret_bandpass = []
        (low, high) = config.spurs(freq)

        if low is None:
            # check lowpass
            for filter in lowpass:
                model, f1, f2, f3 = filter
                if freq <= f1:
                    if high >= f2:
                        if high <= f3:
                            ret_lowpass.append(model)

            # for bandpass, set `low` to negative, so it's always in stopband
            low = -1

        for filter in bandpass:
            model, f1, f2, f3, f4, f5 = filter
            if f1 <= freq <= f2:
                if low <= f3:
                    if f4 <= high <= f5:
                        ret_bandpass.append(model)

        return (ret_lowpass, ret_bandpass)

    def find_best_config(freq: float, configs: List[_DacConfig]):
        def spur_score(low: Optional[float], high: float) -> float:
            if low is None:
                return high - freq
            else:
                # calculate the "parallel" of the distances
                g_high = 1 / (high - freq)
                g_low = 1 / (freq - low)
                g_parallel = g_high + g_low
                return 1 / g_parallel

        all = []
        for config in configs:
            if not config.is_in_range(freq):
                continue
            (low, high) = config.spurs(freq)
            score = spur_score(low, high)
            filters = find_best_filter(freq, config)
            all.append((config, low, high, score, filters))

        all.sort(key=lambda x: x[3], reverse=True)

        return all

    all = find_best_config(freq_MHz, configs)
    if print_all:
        print(f"Valid DAC configurations for signal at {freq_MHz:.1f} MHz:")
        for x in all:
            config, low, high, score, filters = x
            print(f"  * {config} (score {score:.0f}):")
            if low is not None:
                print(f"      - low-frequency spur: {low:.1f} MHz")
            else:
                print("      - low-frequency spur: None")
            print(f"      - high-frequency spur: {high:.1f} MHz")
            if filters[0]:
                print(f"      - compatible low-pass filters: {filters[0]}")
            if filters[1]:
                print(f"      - compatible band-pass filters: {filters[1]}")

    best_config = all[0][0]
    return (best_config.setup, best_config.fsample)


class ProgressBar:
    """Prints a progress bar to stderr, keeping track of remaining time.

    Args:
        size: how many \"units of work\" will be done
        update_time: limit the update of the progress bar to ``update_time`` seconds

    Example:
        >>> pb = ProgressBar(100)
        >>> pb.start()
        >>> for _ in range(100):
        >>>     time.sleep(0.1)  # <-- do work here!
        >>>     pb.increment()
        >>> pb.done()
    """

    def __init__(self, size: int, update_time: float = 1.0):
        self.size: int = size
        self.status: int = 0
        self.start_time: float = 0.0
        self.last_len: int = 0
        self.update_time: float = update_time
        self.last_time: float = 0.0
        self.bar_size = self._calculate_bar_size()

    def _calculate_bar_size(self) -> int:
        max_bar = shutil.get_terminal_size().columns
        # max_bar -= 2  # "[]"
        # max_bar -= 12 # " Remaining: "
        return max_bar // 2 - 2

    def start(self):
        """Start counting time."""
        self.start_time = time.perf_counter()

    def increment(self, inc: int = 1):
        """Increment the progress bar.

        Will not change the text on stderr if too little time has passed since last update.

        Args:
            inc: how many \"units of work\" have been done since last call
        """
        if self.status >= self.size:
            return
        if self.start_time == 0.0:
            self.start()

        now = time.perf_counter()
        self.status += inc

        if now - self.last_time > self.update_time:
            self.last_time = now
            elapsed = now - self.start_time
            remaining = elapsed / self.status * (self.size - self.status)
            self._update(remaining)

    def _make_bar(self) -> str:
        progress = self.status / self.size
        ticks = int(round(progress * self.bar_size))
        gaps = self.bar_size - ticks
        bar = ticks * "#" + gaps * "."
        return f"[{bar}]"

    def _update(self, remaining: Optional[float] = None):
        bar = self._make_bar()
        if remaining is None:
            msg = f"{bar}"
        else:
            msg = f"{bar} Remaining: {format_sec(remaining)}"
        msg_len = len(msg)
        if msg_len < self.last_len:
            msg = msg + (self.last_len - msg_len) * " "
        self.last_len = msg_len
        print(f"\r{msg}", end="\r", flush=True, file=sys.stderr)

    def done(self):
        """Terminate the progress bar and print total time."""
        now = time.perf_counter()
        elapsed = now - self.start_time
        msg = f"Done in {format_sec(elapsed)}"
        msg_len = len(msg)
        if msg_len < self.last_len:
            msg = msg + (self.last_len - msg_len) * " "
        print(f"{msg}", file=sys.stderr)


class Spinner:
    """Prints a spinner to stderr, while some work is being done.

    Args:
        msg: the header message of the spinner
        quiet: set to ``True`` to inhibit printing and thus disable the spinner

    Example:

        Using a context manager (``with`` block):

        >>> with Spinner("Doing lots of work")
        >>>     time.sleep(3.14)  # <-- do work here!

        Will print sequentially (all in one line)::

            Doing lots of work... -
            Doing lots of work... /
            Doing lots of work... |
            Doing lots of work... \\
            Doing lots of work... -
            Doing lots of work... /
            ...
            Doing lots of work: 3.2s
    """

    def __init__(self, msg: str, quiet: bool = False):
        self.spinner = itertools.cycle(["-", "/", "|", "\\"])
        self.t0 = datetime.fromtimestamp(0)
        self.thread = None
        self.done = False
        self.msg = msg
        self._quiet = quiet

    def __enter__(self) -> Spinner:  # for use with 'with' statement
        if not self._quiet:
            self.start()
        return self

    def __exit__(self, *_):  # for use with 'with' statement
        if not self._quiet:
            self.finish()

    def _worker(self, msg: str):
        while not self.done:
            print(f"{msg:s}... {next(self.spinner)}", end="\r", flush=True, file=sys.stderr)
            time.sleep(0.1)

    def start(self):
        self.t0 = datetime.now()
        self.done = False
        self.thread = threading.Thread(name="spinner", target=self._worker, args=(self.msg,))
        self.thread.start()

    def finish(self):
        if self.thread is not None:
            self.done = True
            self.thread.join()
            t1 = datetime.now()
            print(f"{self.msg:s}: {format_sec(t1-self.t0):s}", file=sys.stderr)


_AEC_YELLOW = "\x1b[1;33m"
_AEC_RED = "\x1b[1;31m"
_AEC_RESET = "\x1b[0m"
