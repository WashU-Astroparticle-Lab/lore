from abc import ABC, abstractmethod
import math
import socket
from threading import Thread
import time
from typing import Generic, TypeVar

SR_T = TypeVar("SR_T")


class StreamReceiver(ABC, Generic[SR_T]):
    def __init__(
        self,
        *,
        sock: socket.socket,
        bytes_per_meas: int,
        extra_bytes: int = 0,
        buf_size: int = 1 << 30,
    ) -> None:
        self._sock = sock
        self._bytes_per_meas = bytes_per_meas

        buf_size = int(round(buf_size / bytes_per_meas)) * bytes_per_meas
        self._buf = bytearray(buf_size)
        self._received = 0
        self._next_meas_idx = 0

        # throw away initial extra_bytes
        self._receive(extra_bytes)

        # start receiver thread
        self._running = True  # set to False by close() before joining the thread
        self._terminated = False  # set to True by the thread when it terminates
        self._thread = Thread(target=self._receive_thread)
        self._thread.start()

    def __enter__(self):  # for use with 'with' statement
        return self

    def __exit__(self, exc_type, exc_value, traceback):  # pyright: ignore
        self.close()

    def close(self):
        """Gracely terminate the stream receiver.

        Call this method if the class was instantiated without a
        :ref:`with statement <python:with>`. This method is called automatically when exiting a
        ``with`` block and before the object is destructed.
        """
        self._running = False
        self._thread.join()
        self._sock.close()

    def nr_meas_received(self) -> int:
        """The number of measurements received so far from the stream.

        Note that not all the received measurements might be available in the internal buffer.
        """
        return self._received // self._bytes_per_meas

    @abstractmethod
    def _process_data(self, nr_meas: int, buf: bytearray) -> SR_T: ...

    def _get_meas(self, start: int, end: int) -> SR_T:
        nr_meas = end - start
        idx_start = (start * self._bytes_per_meas) % len(self._buf)
        idx_end = (end * self._bytes_per_meas) % len(self._buf)

        if idx_start > idx_end:
            # wrapping!
            buf = self._buf[idx_start:] + self._buf[:idx_end]
        else:
            buf = self._buf[idx_start:idx_end]

        return self._process_data(nr_meas, buf)

    def _validate_nr_meas(self, n: int):
        max_bytes = len(self._buf) * 0.8
        max_meas = math.floor(max_bytes / self._bytes_per_meas)
        if n > max_meas:
            raise ValueError(f"requesting {n} measurements at once, but maximum is {max_meas}")

    def _wait(self, until: int):
        while not self._terminated and self.nr_meas_received() < until:
            time.sleep(0.01)
        if self._terminated:
            raise RuntimeError("measurement stream stopped unexpectedly")

    def _receive(self, expected: int):
        buf = bytearray(expected)
        view = memoryview(buf)
        received = 0
        while received < expected:
            remaining = expected - received
            nb = self._sock.recv_into(view[received:expected], remaining)
            if nb == 0:
                raise RuntimeError(f"connection closed, got {received} bytes out of {expected}")
            received += nb
        return buf

    def _receive_thread(self):
        view = memoryview(self._buf)
        buf_len = len(view)
        try:
            while self._running:
                start = self._received % buf_len
                max_rcv = buf_len - start
                nb = self._sock.recv_into(view[start:buf_len], max_rcv)
                if nb == 0:
                    print(f"stream connection closed, got a total of {self._received} bytes")
                    break
                self._received += nb
        finally:
            self._terminated = True

    def get(self, n: int) -> SR_T:
        """Return ``n`` measurements received since the last call to this method.

        This method might block the current thread until ``n`` new measurements are available.

        Notes:
            This method keeps track of what measurements have already been returned, and always
            returns contiguous measurements (without gaps). If the requested measurements are
            available in the local buffer, they are returned immediately. Otherwise, the thread
            will block until all the requested measurements have been received.

            That means that calling ``get(n)`` twice results in the same data as calling
            ``get(2 * n)`` once. It also means that the data returned might have been already
            buffered locally and not be the latest received from the hardware.

            See *See also* section below for getter methods with different semantics.

        See also:
            - :meth:`get_new`: always receive new data from the hardware
            - :meth:`get_last`: return latest data from local buffer
        """
        self._validate_nr_meas(n)
        start = self._next_meas_idx
        end = start + n
        self._wait(end)
        ret = self._get_meas(start, end)
        self._next_meas_idx = end
        return ret

    def get_new(self, n: int) -> SR_T:
        """Receive ``n`` new measurements.

        This method blocks the current thread until ``n`` new measurements are received.

        Notes:
            This method always waits for ``n`` new measurements to be received from the hardware,
            without regard for what measurements have already been received in the background but
            not yet returned to the user.

            That means that calling ``get_new(n)`` twice is *not* equivalent to calling
            ``get_new(2 * n)`` once: in the former case an arbitrary time gap might be present
            between the two data sets. Nevertheless, the two data sets will be distinct and non
            overlapping.

            See *See also* section below for getter methods with different semantics.

        See also:
            - :meth:`get`: keep track of previously returned data
            - :meth:`get_last`: return latest data from local buffer
        """
        self._validate_nr_meas(n)
        start = self.nr_meas_received()
        end = start + n
        self._wait(end)
        return self._get_meas(start, end)

    def get_last(self, n: int) -> SR_T:
        """Return the last ``n`` measurements available in the local buffer.

        This method might block the current thread, if fewer than ``n`` measurements are available
        in the local buffer.

        Notes:
            This method returns the most up-to-date data available in the local buffer, regardless
            of whether this data has already been returned to the user.

            That means that calling ``get_last(n)`` twice is *not* equivalent to calling
            ``get_last(2 * n)`` once: in the former case, the two data sets might overlap.

            See *See also* section below for getter methods with different semantics.

        See also:
            - :meth:`get`: keep track of previously returned data
            - :meth:`get_new`: always receive new data from the hardware
        """
        self._validate_nr_meas(n)
        self._wait(n)

        end = self.nr_meas_received()
        start = end - n
        return self._get_meas(start, end)
