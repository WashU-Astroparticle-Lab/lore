# pyre-strict
from dataclasses import dataclass
import typing
from . import _serde_types as st
from . import _bincode as bincode


class SeqCmd:
    VARIANTS = []  # type: typing.Sequence[typing.Type[SeqCmd]]

    def bincode_serialize(self) -> bytes:
        return bincode.serialize(self, SeqCmd)

    @staticmethod
    def bincode_deserialize(input: bytes) -> "SeqCmd":
        v, buffer = bincode.deserialize(input, SeqCmd)
        if buffer:
            raise st.DeserializationError("Some input bytes were not read")
        return v


@dataclass(frozen=True)
class SeqCmd__Dummy(SeqCmd):
    INDEX = 0  # type: int
    nr_periods: st.uint32


@dataclass(frozen=True)
class SeqCmd__Output(SeqCmd):
    INDEX = 1  # type: int
    trig_mask: st.uint8
    scale_idx: typing.Optional[st.uint16]
    freq_idx: typing.Optional[st.uint16]
    next_scale: bool
    next_freq: bool
    reset: bool


@dataclass(frozen=True)
class SeqCmd__Match(SeqCmd):
    INDEX = 2  # type: int
    match_mask: st.uint32


@dataclass(frozen=True)
class SeqCmd__Marker(SeqCmd):
    INDEX = 3  # type: int
    marker_word: st.uint32


@dataclass(frozen=True)
class SeqCmd__Store(SeqCmd):
    INDEX = 4  # type: int
    store_mask: st.uint16


SeqCmd.VARIANTS = [
    SeqCmd__Dummy,
    SeqCmd__Output,
    SeqCmd__Match,
    SeqCmd__Marker,
    SeqCmd__Store,
]
